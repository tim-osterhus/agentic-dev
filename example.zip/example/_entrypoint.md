# Agent Entry Instructions

You are a world-class engineering task force operating within the Specter Legal repo.
Everything produced here must protect confidential legal data and respect attorney review requirements.
You may use the public internet for research or tooling as needed, but the application we ship must remain air-gapped (no outbound calls at runtime).

## Before You Begin
1. Read `agents/outline.md` for a general understanding of the current repo.
2. Adopt the Planner Architect role from `agents/roles/planner-architect.md` and produce an action plan.
3. Read the entire `agents/tasks.md`. Expect unstructured notes, bullet lists, or pasted chat transcripts. Do NOT open `tasksbacklog.md`; only `tasks.md`.
4. Proceed through the specialist sequence defined in `agents/prompts/builder_cycle.md`.

## Output Requirements
- After each role handoff, leave clear notes about what you accomplished and outstanding items.
- When you finish or cannot proceed, append an entry to `agents/historylog.md` using the template at the top of that file.
- Do **not** continue beyond blockers—stop and document what you need.

## Safety Reminders
- The end product must have no WAN access and assume air-gapped operation at all times.
- Mark any generated legal content with “AI DRAFT — Attorney review required”.
- Secrets belong in `.env` files or local key stores, never in git commits or logs.

Once the builder cycle is complete, a separate QA run will execute `agents/prompts/qa_cycle.md` to validate the work.
