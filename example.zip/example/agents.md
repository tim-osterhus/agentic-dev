# Specter Legal — Agents Hub

**Purpose.** Give every coding agent the minimum context, safety rules, and handoffs to ship work quickly and safely. This fulfills Phase-0’s “Base coding agent folder” with agent-specific instructions, a link back to the overall roadmap, and a focused team-roles model.

---

## 1) What every agent MUST know (non-negotiables)

- **Lawyer-in-the-loop.** Treat the model as a drafting/research tool; a human attorney reviews and owns final outputs. Never auto-send or e-file. Add “AI DRAFT — Attorney review required” on generated content. Log reviewer name & timestamp.
- **Confidentiality posture.** No WAN calls. Keep models/embeddings local; encrypt at rest/in-transit. 
- **“Sources required.”** Legal assertions must be backed by retrieved sources. If no source meets threshold → return “needs research” with a task list.   
- **Security basics in dev.** Respect TLS on LAN, MFA, audit logging, and air-gapped update flow when touching infra code. 

> After each run, **append a short summary** of what changed to `historylog.md` (see §6). This is how new agents get instant context.

---

## 2) Roles & how work flows

We use focused specialist agents to reduce scope creep. See **`roles.yaml`** for precise responsibilities, inputs, outputs, and acceptance checks.

**Default flow for a task:**

1) **Intake.** Convert the ask into a **Task Card** (use `task-templates.md`).  
2) **Pre-flight.** Confirm you won’t break security norms (WAN calls, secrets, logs). 
3) **Plan.** List subtasks; select tools/models; note evals you’ll run.  
4) **Build.** Small PRs, clear commits.  
5) **Evaluate.** Run RAG checks (precision@k, citation overlap) and smoke tests. (See `task-templates.md`.)  
6) **Document.** Update `historylog.md` with: what changed, why, files touched, follow-ups.  
7) **Handoff.** Tag the next role (e.g., RAG Engineer → Evaluations Agent).

---

## 3) Directory map (this folder)

- `agents.md` (you are here) — the master entry point.  
- `roles.yaml` — the team roles with deliverables and gates.  
- `historylog.md` — rolling change log for agents (human-readable, high level).  
- `task-templates.md` — copy-ready templates for tasks, PRs, and eval notes.  
- `safeguards.md` — copy-ready safety prompts and checklists (citations, injection, logging).  
- `claude.md` — master instructions for the Claude-based agent.  
- `gemini.md` — master instructions for the Gemini-based agent.

> Link to the main roadmap for cross-checking stage gates and priorities: **Quick Specter Legal Feature Roadmap** (Phase 0, 1, 2, …).

---

## 4) Task acceptance (what “done” means)

Each agent must show:

- **Security conformance:** LAN-TLS respected, no internet egress, secrets untouched, audit events preserved. 
- **Model governance:** answers with sources; max length + confidence surfaced; use constrained legal formats where relevant. 
- **Reproducibility:** commands, env vars, and any migrations are documented in your Task Card.  
- **`historylog.md` updated:** the single source of truth for “what changed”.

---

## 5) Agent etiquette (quick rules)

- Prefer **small PRs** with clear commit subjects (`feat:`, `fix:`, `docs:`).  
- Avoid “big-bang” refactors unless a **Product Architect** signs off (see `roles.yaml`).  
- Never write secrets to code or logs; don’t add WAN libraries.  
- If a claim lacks a source, **don’t** include it—return a research checklist instead. 

---

## 6) History log protocol (must follow)

After every run, append an entry to **`historylog.md`**:
[YYYY-MM-DD] AgentName • Task Title

- Summary: 1–3 sentences of what changed and why.
- Files touched: list
- Decisions: bullets (tradeoffs/constraints)
- Follow-ups: bullets (who + what)
- Prompt reference: include the numbered prompt filename if one guided the work.
Tip: Also echo this summary in your PR description.

---

## 7) Per-model master guides

- **Claude agents →** see [`claude.md`](./claude.md) 
- **Gemini agents →** see [`gemini.md`](./gemini.md) 

---

## 8) Why these constraints exist (for agents)

- Lawyer-in-the-loop and confidentiality are ethics requirements; LAN-only + encryption are “reasonable efforts.” 
- “Sources required” and constrained legal answer formats reduce hallucination risk. 
- LAN TLS, MFA, audit logging, SBOM & signed images are the baseline for an air-gapped legal tool. 
