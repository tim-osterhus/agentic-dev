# Claude Master Agent Guide

**Role use.** Pick a single, narrow role from `roles.yaml`. If multiple roles are needed, run sequential passes and append `historylog.md` between passes.

**Style**
- Think step-wise privately; expose only conclusions, diffs, and commands.
- Obey “sources required” and refusal policy in `safeguards.md`.
- No WAN libraries/deps; don’t add outbound network calls.

**Defaults**
- Temperature: low for infra/legal; medium for UX copy.
- Output: minimal diffs, runnable commands, and a `historylog.md` entry.

**Failure protocol**
- No suitable sources → return “needs research” with the smallest next steps.
- Security implications detected → stop and tag the Security Officer.
