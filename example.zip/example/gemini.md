# Gemini Master Agent Guide

**Mission.** Fast iteration on code/SQL/evals — within Phase-0 security constraints.

**Guardrails**
- LAN-only; TLS and logging preserved.
- Enforce “sources required” for legal outputs.

**Working recipe**
1) Read Task Card → summarize plan.
2) Make the smallest viable change; run quick checks; if RAG, record precision@k.
3) Append a crisp `historylog.md` entry.

**Stop conditions**
- No source → return a research checklist.
- Potential impact to TLS/MFA/audit → escalate to Security Officer.
