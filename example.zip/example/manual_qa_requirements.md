# Manual QA Requirements: LAN DNS Service

**Task:** LAN DNS Service for specter.local (Prompt 003)
**QA Status:** Automated validation PASSED (syntax only) - Docker/LAN testing required
**Date:** 2025-11-19
**Environment Limitations:** No Docker daemon, no LAN client devices, no router access

---

## ✅ Automated Tests PASSED (Environment Constraints)

These tests were executed successfully in the QA environment:

### 1. YAML Syntax Validation
```bash
python3 -c "import yaml; yaml.safe_load(open('infra/compose/docker-compose.dns.yml'))"
```
**Status:** ✓ PASSED - YAML syntax is valid

### 2. Corefile Structure Validation
```bash
python3 validation script (checks for required blocks)
```
**Status:** ✓ PASSED
- ✓ specter.local zone block present
- ✓ Catch-all zone block (.:53) present
- ✓ Hosts plugin configuration present
- ✓ Forward plugin configuration present
- ✓ Health endpoint configured (:8080)

### 3. File Existence Verification
**Status:** ✓ PASSED
- ✓ infra/compose/docker-compose.dns.yml exists
- ✓ infra/dns/Corefile exists
- ✓ .env.example updated with DNS variables (lines 27-32)
- ✓ docs/HTTPS_LAN_SETUP.md updated with Part 1.5 (DNS Service Setup)
- ✓ docs/STT_DICTATION.md updated with DNS service references
- ✓ README.md updated with DNS service section

### 4. Documentation Completeness
**Status:** ✓ PASSED
- ✓ Inline documentation in docker-compose.dns.yml (comprehensive)
- ✓ Inline documentation in Corefile (clear variable references)
- ✓ Troubleshooting guide in compose file (systemd-resolved conflicts, etc.)
- ✓ Router DHCP configuration instructions in HTTPS_LAN_SETUP.md
- ✓ Teardown instructions documented

---

## ⚠️ Manual QA Required (Docker + LAN Environment)

**CRITICAL:** The following tests CANNOT be performed in the current QA environment due to lack of Docker daemon and LAN infrastructure. These tests MUST be executed by a local CLI agent or human operator with Docker-enabled host and LAN access.

### PHASE 1: Container Deployment Tests

Execute these tests on a Docker-enabled host:

#### Test 1.1: Container Startup
```bash
# Deploy DNS service
docker compose -f infra/compose/docker-compose.dns.yml up -d

# Verify container is running
docker ps | grep specter-dns
```

**Expected Result:**
```
CONTAINER ID   IMAGE                  STATUS                 NAMES
xxxxx          coredns/coredns:1.11.1 Up X seconds (healthy) specter-dns
```

**Validation Criteria:**
- ✓ Container name: specter-dns
- ✓ Status: Up (not Restarting or Exited)
- ✓ Health: healthy (may take up to 10s for first health check)
- ✓ Network mode: host

#### Test 1.2: Health Check Verification
```bash
# Check health status detail
docker inspect specter-dns --format='{{json .State.Health}}' | python3 -m json.tool

# Test health endpoint directly
curl -s http://localhost:8080/health
```

**Expected Result:**
```json
{
    "Status": "healthy",
    "FailingStreak": 0,
    "Log": [
        {
            "ExitCode": 0,
            "Output": "..."
        }
    ]
}
```

**Health endpoint:** Should return 200 OK with health status

**Validation Criteria:**
- ✓ Health.Status = "healthy"
- ✓ FailingStreak = 0
- ✓ No error logs in Health.Log entries

#### Test 1.3: Container Logs
```bash
# Check startup logs
docker logs specter-dns | head -30
```

**Expected Result:**
```
.:53
CoreDNS-1.11.1
linux/amd64, go1.20.x, xxxxxxx
```

**Validation Criteria:**
- ✓ CoreDNS version logged (1.11.1)
- ✓ No ERROR or FATAL messages
- ✓ Plugin chain loaded successfully
- ✓ Health plugin listening on :8080
- ✓ DNS server listening on :53

#### Test 1.4: Port Conflict Detection
```bash
# Check if port 53 is available before startup
sudo netstat -tulpn | grep :53

# On Ubuntu with systemd-resolved
systemctl status systemd-resolved
```

**Expected Scenarios:**
1. **No conflicts:** Port 53 free → CoreDNS binds successfully
2. **systemd-resolved conflict:** Port 53 occupied → Container may fail or systemd-resolved needs disabling

**Resolution for Conflict:**
```bash
# Disable systemd-resolved (Ubuntu/Debian)
sudo systemctl stop systemd-resolved
sudo systemctl disable systemd-resolved

# Restart DNS service
docker compose -f infra/compose/docker-compose.dns.yml restart
```

**Validation Criteria:**
- ✓ Document whether port conflict exists
- ✓ Document resolution steps taken
- ✓ Verify CoreDNS binds to port 53 after resolution

---

### PHASE 2: DNS Resolution Tests (Host)

Execute these tests from the Docker host (same machine running CoreDNS):

#### Test 2.1: Local DNS Query (dig)
```bash
# Query specter.local using dig
dig @localhost specter.local +short

# Query with full output
dig @localhost specter.local
```

**Expected Result:**
```
21.0.0.174
```

**Validation Criteria:**
- ✓ Returns exactly the IP configured in Corefile (21.0.0.174 by default)
- ✓ Query time < 50ms
- ✓ NOERROR status
- ✓ ANSWER section contains A record

#### Test 2.2: Local DNS Query (nslookup)
```bash
nslookup specter.local localhost
```

**Expected Result:**
```
Server:    127.0.0.1
Address:   127.0.0.1#53

Name:      specter.local
Address:   21.0.0.174
```

**Validation Criteria:**
- ✓ Name resolves to configured IP
- ✓ Server shows localhost/127.0.0.1

#### Test 2.3: Wildcard Subdomain Query
```bash
dig @localhost www.specter.local +short
```

**Expected Result:**
```
21.0.0.174
```

**Validation Criteria:**
- ✓ www.specter.local resolves to same IP as specter.local

#### Test 2.4: Upstream DNS Forwarding
```bash
# Test forwarding to Google DNS
dig @localhost google.com +short
dig @localhost github.com +short
```

**Expected Result:**
```
<Valid Google IP addresses>
<Valid GitHub IP addresses>
```

**Validation Criteria:**
- ✓ External domain queries return valid IP addresses
- ✓ Queries forwarded to upstream DNS (8.8.8.8, 8.8.4.4)
- ✓ Internet resolution still works

#### Test 2.5: Negative Test (Non-Existent Domain)
```bash
dig @localhost nonexistent.invalid +short
```

**Expected Result:**
```
(empty output or NXDOMAIN)
```

**Validation Criteria:**
- ✓ Query completes (DNS server responding)
- ✓ No false positive resolution

#### Test 2.6: Query Logging
```bash
# Tail logs while making queries
docker logs -f specter-dns &

# Make test queries
dig @localhost specter.local
dig @localhost google.com

# Check logs
docker logs specter-dns | tail -20
```

**Expected Result:**
```
[INFO] <IP>:port - query: specter.local A
[INFO] <IP>:port - query: google.com A
```

**Validation Criteria:**
- ✓ Queries logged (if log plugin enabled)
- ✓ Error-class logging active (errors would be visible)

---

### PHASE 3: LAN Client Tests (Critical for UX Validation)

Execute these tests from LAN client devices (laptops, tablets, phones):

**Prerequisites:**
- Client device on same LAN as Docker host
- Know Docker host's LAN IP (e.g., 21.0.0.174)
- Temporary DNS configuration on client

#### Test 3.1: LAN DNS Resolution (Windows Laptop)

**Step 1: Configure DNS**
```
1. Control Panel → Network and Sharing Center
2. Change adapter settings → Right-click Wi-Fi/Ethernet → Properties
3. IPv4 Properties → Use the following DNS server addresses:
   - Preferred: 21.0.0.174 (Docker host IP)
   - Alternate: 8.8.8.8
4. OK → Close
```

**Step 2: Flush DNS Cache**
```cmd
ipconfig /flushdns
```

**Step 3: Test Resolution**
```cmd
nslookup specter.local
ping specter.local
```

**Expected Result:**
```
Server:  specter-dns
Address: 21.0.0.174

Name:    specter.local
Address: 21.0.0.174
```

**Validation Criteria:**
- ✓ specter.local resolves to configured IP
- ✓ DNS server shows as Docker host IP
- ✓ No timeout or "can't find server" errors

#### Test 3.2: LAN DNS Resolution (macOS Laptop)

**Step 1: Configure DNS**
```
1. System Preferences → Network
2. Select active connection (Wi-Fi/Ethernet) → Advanced
3. DNS tab → + button
4. Add: 21.0.0.174 (Docker host IP)
5. Move to top of list (drag and drop)
6. OK → Apply
```

**Step 2: Flush DNS Cache**
```bash
sudo dscacheutil -flushcache
sudo killall -HUP mDNSResponder
```

**Step 3: Test Resolution**
```bash
scutil --dns | grep nameserver
nslookup specter.local
dig specter.local +short
```

**Expected Result:**
```
nameserver[0] : 21.0.0.174
...
21.0.0.174
```

**Validation Criteria:**
- ✓ specter.local resolves correctly
- ✓ Primary nameserver is Docker host IP

#### Test 3.3: LAN DNS Resolution (Linux Laptop)

**Step 1: Configure DNS (NetworkManager)**
```bash
# GUI: Network settings → Wired/Wi-Fi → IPv4 → DNS
# Add: 21.0.0.174

# OR manual /etc/resolv.conf (temporary)
echo "nameserver 21.0.0.174" | sudo tee /etc/resolv.conf.tmp
sudo mv /etc/resolv.conf.tmp /etc/resolv.conf
```

**Step 2: Test Resolution**
```bash
cat /etc/resolv.conf
nslookup specter.local
dig specter.local +short
```

**Expected Result:**
```
nameserver 21.0.0.174
...
21.0.0.174
```

**Validation Criteria:**
- ✓ resolv.conf shows Docker host as nameserver
- ✓ specter.local resolves correctly

#### Test 3.4: Browser Access Test (All Platforms)

**Prerequisites:**
- Client DNS configured to use Docker host IP
- nginx and LibreChat stack running on Docker host
- Valid HTTPS certificate installed

**Test Steps:**
1. Open browser (Chrome, Firefox, Safari, Edge)
2. Navigate to: `https://specter.local`
3. Verify page loads

**Expected Result:**
- ✓ Site loads without "can't resolve" error
- ✓ Green padlock (HTTPS certificate valid and trusted)
- ✓ LibreChat interface displays
- ✓ No certificate warnings (if properly installed)

**Validation Criteria:**
- ✓ DNS resolution works in browser context
- ✓ No hostname resolution errors
- ✓ HTTPS context established (necessary for microphone access)

#### Test 3.5: Microphone Access Test (Mission-Critical)

**Prerequisites:**
- Browser access test passed (HTTPS context required)
- Microphone hardware present on test device
- Whisper STT service running on Docker host

**Test Steps:**
1. Navigate to: `https://specter.local`
2. Log in to LibreChat
3. Click microphone icon in chat input area
4. Observe browser permission prompt

**Expected Result:**
- ✓ Browser prompts: "Allow specter.local to use your microphone?"
- ✓ No error: "Microphone access denied due to insecure context"
- ✓ After granting permission, microphone activates (visual indicator)
- ✓ Recording works (dictation transcribed)

**Validation Criteria:**
- ✓ Secure context achieved (HTTPS + trusted cert)
- ✓ Microphone API accessible
- ✓ User grants permission without technical barriers
- ✓ Whisper transcription returns text

**Target User:** Non-technical attorney
**UX Goal:** Zero manual hosts file editing required

#### Test 3.6: Mobile Device Tests (iOS)

**Step 1: Configure DNS**
```
1. Settings → Wi-Fi
2. Tap (i) icon next to connected network
3. Configure DNS → Manual
4. Add Server: 21.0.0.174 (Docker host IP)
5. Remove other DNS servers or move to bottom
6. Save
```

**Step 2: Test Resolution**
```
1. Safari → https://specter.local
2. Verify site loads
```

**Validation Criteria:**
- ✓ DNS resolution works on iOS
- ✓ Safari loads LibreChat over HTTPS
- ✓ Microphone prompt appears when tapping mic icon

#### Test 3.7: Mobile Device Tests (Android)

**Step 1: Configure DNS**
```
1. Settings → Wi-Fi
2. Long-press connected network → Modify network
3. Advanced options → IP settings: Static
4. DNS 1: 21.0.0.174 (Docker host IP)
5. DNS 2: 8.8.8.8 (fallback)
6. Save
```

**Step 2: Test Resolution**
```
1. Chrome → https://specter.local
2. Verify site loads
```

**Validation Criteria:**
- ✓ DNS resolution works on Android
- ✓ Chrome loads LibreChat over HTTPS
- ✓ Microphone prompt appears when tapping mic icon

---

### PHASE 4: Router DHCP Configuration (Production Deployment)

**CRITICAL:** This is the recommended production deployment method for automatic client configuration.

**Prerequisites:**
- Router admin access
- Docker host has static IP or DHCP reservation
- Know router admin URL (typically 192.168.1.1, 192.168.0.1, or 10.0.0.1)

#### Test 4.1: Router DHCP DNS Configuration

**Step 1: Log in to Router**
```
1. Browser → http://192.168.1.1 (or router IP)
2. Log in with admin credentials
3. Navigate to DHCP settings (may be under LAN, Network, or Advanced)
```

**Step 2: Configure DNS Servers**
```
1. Find "Primary DNS Server" or "DNS Server 1"
2. Set to Docker host IP: 21.0.0.174
3. Find "Secondary DNS Server" or "DNS Server 2"
4. Set to fallback: 8.8.8.8 (or leave as router default)
5. Save settings
6. Reboot router if prompted
```

**Step 3: Renew DHCP on Test Client**
```bash
# Windows
ipconfig /release
ipconfig /renew

# macOS
sudo ipconfig set en0 DHCP  # en0 is Wi-Fi interface

# Linux
sudo dhclient -r
sudo dhclient
```

**Step 4: Verify Client DNS Configuration**
```bash
# Windows
ipconfig /all | findstr "DNS Servers"

# macOS
scutil --dns | grep nameserver

# Linux
cat /etc/resolv.conf
```

**Expected Result:**
```
DNS Servers: 21.0.0.174
             8.8.8.8
```

**Validation Criteria:**
- ✓ All DHCP clients receive Docker host IP as primary DNS
- ✓ No manual per-device configuration required
- ✓ New devices joining network automatically get correct DNS

#### Test 4.2: Multi-Device Automatic Configuration Test

**Test Matrix:**
- ✓ Windows laptop (auto DHCP)
- ✓ macOS laptop (auto DHCP)
- ✓ Linux laptop (auto DHCP)
- ✓ iOS phone/tablet (auto DHCP)
- ✓ Android phone/tablet (auto DHCP)

**For Each Device:**
1. Connect to Wi-Fi (no manual DNS config)
2. Verify DNS servers via system settings
3. Navigate to https://specter.local in browser
4. Verify site loads correctly

**Expected Result:**
- ✓ All devices resolve specter.local automatically
- ✓ Zero manual hosts file editing
- ✓ Zero manual DNS configuration per device

**UX Validation:**
- ✓ Non-technical attorney can access LibreChat from any device
- ✓ Microphone access works without "secure context" errors
- ✓ True plug-and-play experience achieved

---

### PHASE 5: Failure Mode and Recovery Tests

#### Test 5.1: DNS Service Down
```bash
# Stop DNS service
docker compose -f infra/compose/docker-compose.dns.yml down

# From client, test resolution
nslookup specter.local
```

**Expected Result:**
- ✗ Resolution fails (can't find specter.local)
- ✓ If hosts file fallback exists, resolution still works
- ✓ Internet access still works (router or upstream DNS handles other queries)

**Recovery Test:**
```bash
# Restart DNS service
docker compose -f infra/compose/docker-compose.dns.yml up -d

# Wait 15 seconds for health check
sleep 15

# From client, test resolution
nslookup specter.local
```

**Expected Result:**
- ✓ Resolution works again
- ✓ No manual intervention required on clients

#### Test 5.2: Upstream DNS Failure Simulation
```bash
# Edit Corefile to use invalid upstream DNS
sed -i 's/8.8.8.8 8.8.4.4/1.2.3.4 5.6.7.8/' infra/dns/Corefile

# Restart DNS service
docker compose -f infra/compose/docker-compose.dns.yml restart

# Test specter.local (should work)
dig @localhost specter.local +short

# Test external domain (should fail)
dig @localhost google.com +short
```

**Expected Result:**
- ✓ specter.local still resolves (local zone not affected)
- ✗ External domain queries timeout or fail

**Validation Criteria:**
- ✓ Local DNS service operates independently
- ✓ Failure isolated to upstream forwarding

**Recovery:**
```bash
# Restore correct upstream DNS
git checkout infra/dns/Corefile
docker compose -f infra/compose/docker-compose.dns.yml restart
```

#### Test 5.3: Port Conflict Recovery
```bash
# Start systemd-resolved (to conflict with port 53)
sudo systemctl start systemd-resolved

# Check DNS container status
docker ps | grep specter-dns
docker logs specter-dns
```

**Expected Result:**
- ✗ Container may show unhealthy or error logs
- ✓ Error message indicates port 53 bind failure

**Resolution:**
```bash
# Stop conflicting service
sudo systemctl stop systemd-resolved
sudo systemctl disable systemd-resolved

# Restart DNS container
docker compose -f infra/compose/docker-compose.dns.yml restart

# Verify health
docker ps | grep specter-dns
```

**Validation Criteria:**
- ✓ Troubleshooting guide documents this scenario
- ✓ Recovery steps clear and actionable

---

### PHASE 6: Documentation Validation

#### Test 6.1: Follow HTTPS_LAN_SETUP.md Part 1.5
**Tester:** Fresh user (or user simulation)
**Objective:** Validate documentation completeness

**Steps:**
1. Read Part 1.5 from start to finish
2. Follow each instruction exactly as written
3. Note any ambiguities, missing steps, or unclear commands
4. Verify all referenced files exist
5. Verify all commands execute successfully

**Expected Result:**
- ✓ DNS service deploys successfully by following docs alone
- ✓ No missing steps
- ✓ No unclear terminology
- ✓ Router DHCP instructions match actual router UI (or close enough)

**Validation Criteria:**
- ✓ Non-technical user can complete setup with docs only
- ✓ No external research required
- ✓ Troubleshooting section addresses actual issues encountered

#### Test 6.2: Teardown Instructions
```bash
# Follow documented teardown steps
docker compose -f infra/compose/docker-compose.dns.yml down

# Verify container removed
docker ps -a | grep specter-dns

# Revert router DHCP settings (manual step)
# Verify clients no longer resolve specter.local
```

**Expected Result:**
- ✓ Service cleanly removed
- ✓ No orphaned containers or volumes
- ✓ Documentation provides router revert instructions
- ✓ Clients return to normal DNS behavior

---

## Summary: Test Execution Requirements

### Can Be Tested Remotely (QA Agent)
- ✅ YAML syntax validation
- ✅ Corefile structure validation
- ✅ File existence checks
- ✅ Documentation review

### Requires Docker-Enabled Host
- ⚠️ Container deployment (Phase 1)
- ⚠️ Host DNS resolution tests (Phase 2)
- ⚠️ Failure mode testing (Phase 5)

### Requires Physical LAN Access
- ⚠️ LAN client DNS resolution (Phase 3.1-3.7)
- ⚠️ Browser access validation (Phase 3.4)
- ⚠️ Microphone access validation (Phase 3.5)
- ⚠️ Router DHCP configuration (Phase 4)

### Requires Multiple Device Types
- ⚠️ Windows laptop test
- ⚠️ macOS laptop test
- ⚠️ Linux laptop test
- ⚠️ iOS mobile test
- ⚠️ Android mobile test

---

## Test Execution Checklist

**For Local CLI Agent or Human Operator:**

```markdown
### Phase 1: Container Tests
- [ ] 1.1 Container startup successful
- [ ] 1.2 Health check passing
- [ ] 1.3 Logs clean (no errors)
- [ ] 1.4 Port conflict detection/resolution

### Phase 2: Host DNS Tests
- [ ] 2.1 dig @localhost specter.local → correct IP
- [ ] 2.2 nslookup specter.local → correct IP
- [ ] 2.3 www.specter.local resolves
- [ ] 2.4 Upstream forwarding works (google.com)
- [ ] 2.5 Negative test (nonexistent.invalid)
- [ ] 2.6 Query logging verified

### Phase 3: LAN Client Tests
- [ ] 3.1 Windows laptop DNS resolution
- [ ] 3.2 macOS laptop DNS resolution
- [ ] 3.3 Linux laptop DNS resolution
- [ ] 3.4 Browser access (https://specter.local)
- [ ] 3.5 Microphone access works (CRITICAL)
- [ ] 3.6 iOS mobile DNS resolution
- [ ] 3.7 Android mobile DNS resolution

### Phase 4: Router DHCP Tests
- [ ] 4.1 Router DHCP DNS configured
- [ ] 4.2 Multi-device auto-configuration

### Phase 5: Failure Mode Tests
- [ ] 5.1 DNS service down/up recovery
- [ ] 5.2 Upstream DNS failure isolation
- [ ] 5.3 Port conflict recovery

### Phase 6: Documentation Tests
- [ ] 6.1 HTTPS_LAN_SETUP.md Part 1.5 walkthrough
- [ ] 6.2 Teardown instructions validated
```

---

## Evidence Collection

**Document the following for QA verification:**

1. **Terminal Output:**
   - `docker ps | grep specter-dns`
   - `docker logs specter-dns | head -30`
   - `dig @localhost specter.local`
   - `dig @<HOST_IP> specter.local` (from LAN client)

2. **Screenshots:**
   - Browser loading https://specter.local (green padlock)
   - Client device DNS settings showing DNS server IP
   - Microphone permission prompt in LibreChat
   - Router DHCP settings page

3. **Test Results:**
   - Checklist with ✓/✗ for each test
   - Notes on any failures or unexpected behavior
   - Platform-specific quirks discovered

4. **Performance Metrics:**
   - DNS query latency (avg of 10 queries)
   - Container memory usage
   - Time to healthy status

---

## Known Blockers for Automated QA

1. **Docker daemon not available in QA environment**
   - Cannot test container deployment
   - Cannot test health checks
   - Cannot test actual DNS resolution

2. **No LAN client devices**
   - Cannot test multi-device resolution
   - Cannot test browser/microphone access
   - Cannot validate target user experience

3. **No router admin access**
   - Cannot test DHCP configuration
   - Cannot validate automatic client setup

4. **No mobile devices**
   - Cannot test iOS DNS configuration
   - Cannot test Android DNS configuration

**Recommendation:** Execute Phases 1-6 on local Docker-enabled host with LAN access before marking task as fully complete.
