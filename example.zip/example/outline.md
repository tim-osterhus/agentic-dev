# Specter Legal — Comprehensive Repository Outline

**Last Updated:** 2025-11-19
**Purpose:** Quick codebase reference for agents. Read this once to understand the entire project.

---

## Executive Summary

Specter Legal is a **privacy-first, offline Retrieval Augmented Generation (RAG) environment** designed for air-gapped legal research. It combines a FastAPI RAG service with LibreChat UI, Postgres+pgvector database, and Ollama for local LLM/embedding inference. The entire stack runs in Docker with no outbound network access at runtime.

**Key Principles:**
- Air-gapped (no WAN calls in production)
- Tenant-isolated document collections
- Attorney-reviewed legal workflows
- GPU acceleration support (optional)
- Local model inference (Ollama)

---

## Repository Structure Overview

```
specter-legal/
├── rag_api/              # FastAPI service (main backend)
├── librechat/            # LibreChat UI configuration & customization
├── infra/                # Docker Compose & database initialization (core stack + optional DNS/Whisper/nginx helpers)
├── agents/               # Agentic framework & task management
├── tests/                # Integration test suite (pytest)
├── docs/                 # Deployment & customization guides
├── scripts/              # Operational scripts & test helpers
├── data/                 # Runtime storage (documents, uploads)
├── apps/                 # Legacy application code (reference only)
├── archived/             # Legacy PrivateGPT assets (deprecated)
└── .github/              # CI/CD workflows & issue templates
```

---

## Core Technology Stack

### Backend Services
- **FastAPI** — Async REST API for RAG operations
- **LangChain** — RAG orchestration & chain management
- **Postgres 15+** — Document & metadata storage
- **pgvector** — Vector similarity search with HNSW indexing
- **Ollama** — Local LLM & embedding model inference
- **Docker Compose** — Multi-service orchestration

### Frontend
- **LibreChat** (v0.7.6) — Open-source chat UI (custom branch `specter-customizations`)
- **React** — Client framework
- **Vite** — Build tool
- **MongoDB** — Session/conversation persistence (within LibreChat)

### Models (via Ollama)
- **Chat LLM:** Primary: `granite4:tiny-h` | Alternatives: `qwen3:8b`, `qwen2.5:3b`, `qwen3:4b`
- **Embeddings:** `nomic-embed-text` (768-dim vectors)

### Infrastructure
- **nginx** — Reverse proxy (optional)
- **Whisper** — Speech-to-text (optional)
- **GPU Support:** NVIDIA CUDA containers with `nvidia-container-toolkit`

---

## Directory Deep Dive

### `rag_api/` — FastAPI Backend Service

**Purpose:** Core RAG business logic, document ingestion, query processing, embeddings.

**Key Files:**
```
rag_api/
├── main.py              # FastAPI app definition, route handlers, startup/shutdown
├── config.py            # Settings/environment loading (embedding provider, LLM, DB URL, etc.)
├── database.py          # SQLAlchemy engine setup, session management, init_db()
├── models.py            # Pydantic request/response models (QueryRequest, IngestRequest, etc.)
├── backfill_embeddings.py # Utility to regenerate missing vectors
├── requirements.txt     # Python dependencies
├── Dockerfile           # Container build specification
├── .env.rag             # Environment variables (secrets, API keys, credentials)
├── services/            # Business logic modules
│   ├── query.py         # Query service (search, reranking, merging results)
│   ├── ingest.py        # Document ingestion (parsing, chunking, storing)
│   └── embedding.py     # Embedding provider abstraction (Ollama, OpenAI, HuggingFace)
└── static/              # Policy placeholders
    ├── privacy-placeholder.html
    └── terms-placeholder.html
```

**Main API Endpoints:**
- `GET /health` — Service healthcheck
- `POST /query` — Execute RAG query (merges global + tenant collections, optionally reranks)
- `POST /embed` — One-shot embedding for testing/debugging
- `POST /ingest` — Upload & index documents with tenant isolation
- `GET /privacy` — Privacy policy placeholder
- `GET /terms` — Terms of service placeholder

**Startup Behavior:**
- Connects to Postgres, creates/migrates schema
- Loads embedding model config
- Runs `backfill_embeddings.py` auto-backfill for any collections missing vectors
- Logs configured providers (embeddings, LLM) and database connection

**Key Models/Requests:**
- `QueryRequest` — `tenant_id`, `query`, `top_k`, `filters`, `merge_global`, `rerank`
- `IngestRequest` — Document metadata, content, tenant association
- `QueryResponse` — Ranked answers with citations, latency metrics

### `librechat/` — UI Configuration & Customization

**Purpose:** LibreChat frontend customization and environment setup.

**Key Files:**
```
librechat/
├── librechat.yaml       # LibreChat configuration (endpoints, models, UI settings)
├── .env.librechat       # Environment variables (API keys, URLs, registration settings)
├── Dockerfile.librechat # Custom build (based on official LibreChat)
├── LibreChat/           # Git submodule (upstream LibreChat source, branch: specter-customizations)
│   ├── client/          # React frontend code
│   ├── api/             # Express/Node backend (handles auth, convos, file uploads)
│   ├── packages/        # Shared utilities
│   └── ...
└── ...
```

**LibreChat Configuration (`librechat.yaml` v1.3.1):**
- **Endpoints:** Only custom "specter-ollama" enabled (Ollama on `http://ollama:11434/v1`)
- **Models:** `qwen3:8b`, `granite4:tiny-h` (chat), `nomic-embed-text` (embedding) - auto-fetched on startup
- **Agent Capabilities:** `execute_code`, `file_search`, `actions`, `tools` (artifacts disabled)
- **File Config:** Server limit 100 MB, avatar limit 2 MB
- **Interface Settings:**
  - `contextMonitor`: enabled, 24k token default, warn @ 25%, alert @ 10%
  - Privacy/ToS links point to RAG API (`http://localhost:8001/privacy|terms`)
  - Web search, run code, agents menu disabled
  - Model select & parameter tuning enabled

**Environment Variables (`.env.librechat`):**
- `MONGO_URI` — MongoDB connection for sessions
- `ALLOW_REGISTRATION` — Boolean for user signup (set `false` after admin creation)
- `OPENAI_API_KEY` — Dummy value (Ollama doesn't require)
- `OPENAI_API_BASE_URL` — Points to Ollama
- `JWT_SECRET`, `SESSION_SECRET` — LocalStorage/auth encryption

**Recent Customization:**
- Context monitor implementation (token budget display in composer)
- Slim badge rendering (replaces card, takes minimal vertical space)
- Token speed indicator (average tokens/second per message)
- LibreChat source patched to support these features

### `infra/` — Docker Compose & Database Setup

**Purpose:** Infrastructure orchestration, database schema initialization, supporting services.

**Structure:**
```
infra/
├── compose/
│   ├── docker-compose.pgvector.yml     # Postgres + pgvector service
│   ├── docker-compose.mongo.yml        # MongoDB for LibreChat sessions
│   ├── docker-compose.ollama.yml       # Ollama container (GPU-enabled)
│   ├── docker-compose.rag.yml          # RAG API service
│   ├── docker-compose.librechat.yml    # LibreChat UI service
│   ├── docker-compose.nginx.yml        # nginx reverse proxy (optional HTTPS/mic)
│   ├── docker-compose.whisper.yml      # Whisper STT service (optional dictation)
│   └── docker-compose.dns.yml          # CoreDNS helper for `specter.local` (optional)
├── initdb/
│   ├── 001_pgvector.sql       # Create pgvector extension
│   └── 002_rag_schema.sql     # Full schema (collections, documents, vectors, audit)
├── nginx/                      # nginx configuration templates
├── scripts/                    # Utility scripts for DB operations
└── Dockerfile.api             # Alternative/legacy API Dockerfile
```

**Launch Command (Full Stack):**
```bash
docker compose \
  -f infra/compose/docker-compose.pgvector.yml \
  -f infra/compose/docker-compose.mongo.yml \
  -f infra/compose/docker-compose.ollama.yml \
  -f infra/compose/docker-compose.rag.yml \
  -f infra/compose/docker-compose.librechat.yml \
  up -d --build
```

**Database Schema (002_rag_schema.sql):**
- `collections` — Document collection metadata (name, embedding_provider, created_at)
- `documents` — Full document records (title, content, tenant_id, tags, metadata)
- `document_chunks` — Chunked document text
- `document_embeddings` — Vector storage (pgvector `vector(768)` for nomic-embed-text)
- `audit_logs` — Query/ingest activity (tenant_id, action, query_text, results_count, latency_ms)
- Helper functions for tenant isolation, chunking, vector search

**Services Exposed:**
- `specter-pgvector` → Postgres on `localhost:5432`
- `specter-ollama` → Ollama on `localhost:11434` (not exposed externally)
- `specter-rag-api` → RAG API on `localhost:8001`
- `specter-librechat` → UI on `http://localhost:3080`
- `specter-mongo` → MongoDB on `localhost:27017` (internal only)

### `agents/` — Agentic Framework & Task Management

**Purpose:** Structured agent coordination, specialist roles, task tracking, history logging.

**Directory Layout:**
```
agents/
├── _entrypoint.md           # Entry point instructions for agents
├── README.md                # Agent loop guide & philosophy
├── tasks.md                 # Current task inbox (one active task)
├── tasksbacklog.md          # Backlog of future tasks
├── tasksbacklogtemp.md      # Temporary task scratch
├── expectations.md          # QA-written ideal end state
├── quickfix.md              # Gap remediation from QA
├── historylog.md            # Chronological record of agent runs (large file)
├── context.txt              # Session context dump (temporary)
├── thinkingtemp.md          # Temporary thinking notes
├── roadmap.md               # Long-term feature roadmap
├── roadmapchecklist.md      # Roadmap progress tracking
├── agents.md                # Agent safeguards & protocols
├── claude.md                # Claude-specific role guidelines
├── gemini.md                # Gemini-specific role guidelines
├── roles/                   # Agent role definitions
│   ├── planner-architect.md
│   ├── backend-systems-engineer.md
│   ├── frontend-integrator.md
│   ├── fullstack-glue-specialist.md
│   ├── infra-devops-engineer.md
│   ├── qa-test-engineer.md
│   ├── security-engineer.md
│   └── documentation-writer.md
├── prompts/                 # Specialist execution playbooks
│   ├── builder_cycle.md     # Main builder workflow
│   ├── qa_cycle.md          # QA validation workflow
│   └── quickfix.md          # Quick remediation workflow
├── runbooks/                # Human-facing coordination guides
│   ├── builder_runbook.md
│   ├── qa_runbook.md
│   └── historylog_guidance.md
├── temp/                    # Temporary work area (per-session)
│   ├── ignore/              # Subfolder for truly temporary items
│   └── ragplus.md           # Temp research notes
└── sessions/                # (empty .gitkeep) Optional per-run scratch
```

**Workflow:**
1. **Human** updates `agents/tasks.md` with incoming work
2. **Agent** reads `_entrypoint.md` → adopts **Planner Architect** role
3. **Planner** produces action plan based on `tasks.md`
4. **Agent** cycles through specialist roles per `builder_cycle.md`:
   - Backend Systems Engineer
   - Frontend Integrator
   - Infra/DevOps Engineer
   - Fullstack Glue Specialist
   - Security Engineer
5. **Agent** updates `historylog.md` with progress, blockers, decisions
6. **QA Agent** runs `qa_cycle.md` to validate; writes `expectations.md`, identifies gaps
7. If gaps remain → `quickfix.md` created for next iteration

**Key Files Explained:**
- `tasks.md` — **Single, current task** (raw format ok). Delete example after adding real work.
- `historylog.md` — Running log of all agent operations with timestamps, outcomes, and decisions. Used for context carryover.
- `expectations.md` — Written by QA; describes ideal end state (functional, nonfunctional, validation criteria).
- `quickfix.md` — Generated by QA for remaining work (gaps, bugs, test failures).

### `tests/` — Integration Test Suite

**Purpose:** Validate RAG API, database, and chat endpoints.

**Structure:**
```
tests/
├── conftest.py                      # pytest fixtures & database setup
├── requirements.txt                 # Test dependencies (pytest, httpx, etc.)
├── test_database.py                 # Database schema & migrations
├── test_rag_api.py                  # RAG endpoints (query, ingest, embed)
├── test_chat_endpoint.py            # LibreChat chat endpoint (host-based)
├── test_chat_endpoint_container.py  # LibreChat chat endpoint (container-based)
├── apps/                            # (Legacy app tests)
└── fixtures/                        # Shared test data & factory functions
```

**Key Tests:**
- **test_database.py:** Schema validation, extension checks, sample data creation
- **test_rag_api.py:** Query/embed/ingest happy paths, error handling, tenant isolation
- **test_chat_endpoint.py:** Chat completion flow with context, message history
- **test_chat_endpoint_container.py:** Container-based chat testing

**Running Tests:**
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r tests/requirements.txt
pytest tests/test_database.py tests/test_rag_api.py -v
```

### `docs/` — Deployment & Customization Guides

**Key Documentation:**
```
docs/
├── README_LIBRECHAT_INVESTIGATION.md        # LibreChat integration deep-dive
├── CONTEXT_MONITOR_IMPLEMENTATION_GUIDE.md  # Context meter feature details
├── LIBRECHAT_CUSTOMIZATION.md               # How to init/update LibreChat submodule
├── LIBRECHAT_CUSTOMIZATION_ANALYSIS.md      # Analysis of changes needed
├── INVESTIGATION_SUMMARY.md                 # Summary of investigations
├── AIRGAP_DEPLOYMENT.md                     # Air-gap specific guidance
├── INTEGRATION_LIBRECHAT.md                 # LibreChat + RAG API integration
├── LOGGING_AUDIT.md                         # Audit logging setup
├── OIDC_SETUP.md                            # OIDC authentication (optional)
├── STT_DICTATION.md                         # Speech-to-text integration
└── dev/
    ├── auth.md                              # Authentication internals
    └── dictation.md                         # STT internals
```

**Most Relevant for Agent Work:**
- `LIBRECHAT_CUSTOMIZATION.md` — Submodule workflow
- `CONTEXT_MONITOR_IMPLEMENTATION_GUIDE.md` — Current UI work
- `AIRGAP_DEPLOYMENT.md` — Production deployment checklist

### `scripts/` — Operational Helpers

```
scripts/
├── SMOKE_TEST_CHECKLIST.md   # Manual QA checklist
├── run_cycle.sh              # Run a specialist cycle
├── run_reviewer.sh           # Run QA review
├── run_role.sh               # Run a single role
└── test_chat_formats.sh      # Test chat message formats
```

---

## Data Flow & Architecture

### Document Ingestion
```
Document Upload
    ↓
RAG API /ingest endpoint
    ↓
LangChain document loader/parser
    ↓
Chunk documents (overlap strategy)
    ↓
Send chunks to Ollama embedding service (nomic-embed-text)
    ↓
Store in Postgres:
  - documents table (title, content, tenant_id, metadata)
  - document_chunks table (text snippets)
  - document_embeddings table (pgvector)
    ↓
Audit log entry
```

### Query Execution
```
LibreChat user query
    ↓
RAG API /query endpoint (with tenant_id)
    ↓
Embed query using Ollama (nomic-embed-text)
    ↓
Vector similarity search in pgvector:
  - Query global_law collection (if merge_global=true)
  - Query tenant_<id> collection
    ↓
Rerank results (if enabled) using cross-encoder
    ↓
Merge & sort by score
    ↓
Generate LLM context from top-k results
    ↓
Return JSON response with answers + citations + latency
    ↓
LibreChat renders chat message with references
```

### Database Collections
- **`global_law`** — Read-only corpus (Minnesota estate planning statutes, pre-seeded)
- **`tenant_<id>`** — Per-user/per-matter custom documents (created on first ingest)
- **`default`** — System collection (optional)

---

## Configuration & Environment Variables

### `.env.rag` (RAG API)
```
# Database
DB_URL=postgresql://specter:specter@specter-pgvector:5432/specter_legal

# Embedding Provider (options: ollama, openai, huggingface)
EMBEDDINGS_PROVIDER=ollama
OLLAMA_BASE_URL=http://ollama:11434
OLLAMA_EMBED_MODEL=nomic-embed-text
OPENAI_API_KEY=<if using OpenAI>

# LLM Provider
LLM_PROVIDER=ollama
OLLAMA_LLM_MODEL=qwen3:8b

# Reranking (cross-encoder)
RERANK_ENABLED=false
RERANK_MODEL=ms-marco-MiniLM-L-12-v2

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=text (or json)

# Ingest settings
MAX_CHUNK_SIZE=1000
CHUNK_OVERLAP=200

# API
API_KEY=your-secret-key
ADMIN_API_KEY=admin-secret
```

### `.env.librechat` (LibreChat UI)
```
# MongoDB
MONGO_URI=mongodb://specter-mongo:27017/librechat

# Ollama
OPENAI_API_KEY=dummy (not used)
OPENAI_API_BASE_URL=http://ollama:11434/v1

# Secrets
JWT_SECRET=<random-string>
SESSION_SECRET=<random-string>

# Registration
ALLOW_REGISTRATION=true (set false after first user)

# Logging
DEBUG=librechat:*

# File upload
FILE_UPLOAD_SIZE_MAX=100000000 (100 MB)

# Features
ENABLE_FILE_UPLOAD=true
ENABLE_CODE_EXECUTION=true
```

---

## Recent Development Focus (As of Nov 2025)

**Context Monitor & Dictation Enhancements:**
- LibreChat context monitor + token speed badge landed; Whisper STT service + HTTPS nginx proxy shipping for LAN mic access.
- Optional CoreDNS helper (`docker-compose.dns.yml`) lets LAN clients resolve `specter.local` without editing hosts file.

**Backend Guardrails & Retrieval Upgrades (in progress):**
- Citation guardrails now live in `rag_api/main.py`, but smoke-test seed data, HyDE telemetry, hybrid retrieval (`pg_trgm`), and ingest auth are still being hardened via quickfix tasks.
- GPU-aware reranker scaffolding exists; HyDE-lite + hybrid lexical routines are on deck pending quickfix completion.

**Hybrid DNS & Infrastructure:**
- Hybrid CoreDNS + Avahi stack (`agents/mDNS/plan.md`) under active development; Avahi image must be vendored for offline deployments.
- Production hardening tasks (registration lock-down, Docker cleanup, log audits) follow once current backend fixes land.

**Active Task Cards (see `agents/tasksbacklog.md`):**
1. Reseed global/tenant documents to unblock smoke tests.
2. Implement HyDE telemetry + fallback handling.
3. Enable `pg_trgm` and hybrid lexical+dense retrieval.
4. Vendor the Avahi image for hybrid DNS deployment.
5. Fix `/ingest` unauthorized handling (403).
6. Run the production hardening sweep (registration, disk, logs) after the above ship.
7. Expand `/query` test coverage for the new retrieval toggles.

---

## Common Operations

### Rebuild RAG API Container
```bash
docker compose \
  -f infra/compose/docker-compose.pgvector.yml \
  -f infra/compose/docker-compose.mongo.yml \
  -f infra/compose/docker-compose.ollama.yml \
  -f infra/compose/docker-compose.rag.yml \
  -f infra/compose/docker-compose.librechat.yml \
  build --no-cache rag-api

docker compose ... up -d --force-recreate
```

### Rebuild LibreChat Container
```bash
DOCKER_BUILDKIT=1 docker compose ... build librechat
docker compose ... up -d librechat
```

### Regenerate Embeddings
```bash
docker exec -it specter-rag-api python backfill_embeddings.py --batch-size 100 --collection tenant_firm_example
```

### Check Logs
```bash
docker logs specter-rag-api -f
docker logs specter-librechat -f
docker exec specter-ollama ollama list  # Available models
```

### Access Database
```bash
docker exec -it specter-pgvector psql -U specter -d specter_legal
\dt  # List tables
SELECT COUNT(*) FROM documents;
```

---

## Agent Roles & Specializations

Each role has a detailed `.md` file in `agents/roles/`:

1. **Planner Architect** — Strategy, roadmap, architectural decisions, risk assessment
2. **Backend Systems Engineer** — RAG API, database, query logic, services, data models
3. **Frontend Integrator** — React components, LibreChat customization, client state
4. **Fullstack Glue Specialist** — Cross-layer integration, API contracts, E2E workflows
5. **Infra/DevOps Engineer** — Docker, compose files, deployments, scaling, monitoring
6. **QA Test Engineer** — Test planning, validation, expectations, issue discovery
7. **Security Engineer** — Threat modeling, secrets, RBAC, audit trails, air-gap validation
8. **Documentation Writer** — Runbooks, guides, comments, README updates

---

## Key Constraints & Requirements

- **Air-Gapped:** No outbound network calls at runtime (research only via WAN)
- **Tenant Isolation:** Documents/queries strictly isolated by tenant_id
- **Attorney Review:** Generated legal content must be marked "AI DRAFT — Attorney review required"
- **Secrets:** Never commit `.env` files or API keys; use git-ignored local files
- **No WAN Libraries:** Don't add dependencies that require external API calls
- **GPU Optional:** Full CPU fallback for Ollama if GPU unavailable
- **Offline-First:** All models, embeddings, and LLM inference local
- **Audit Trail:** All queries/ingestions logged to `audit_logs` table

---

## Testing & QA Protocol

**Builder Cycle** (`prompts/builder_cycle.md`):
- Role-based task execution
- Document blockers clearly
- Don't guess; stop if missing context

**QA Cycle** (`prompts/qa_cycle.md`):
- Write `expectations.md` *before* inspection
- Compare actual vs. expected
- Generate `quickfix.md` for gaps
- Verify console/test evidence

**Smoke Test** (`scripts/SMOKE_TEST_CHECKLIST.md`):
- Manual checklist for full-stack validation
- UI responsiveness, RAG accuracy, container health

---

## Git Workflow

**Current Branch:** `ui/librechat-ragapi-integration` (as of Nov 2025)
**Main Branch:** `main` (for PRs)

**Recent Commits:**
- `d927d43` — Refactor: Update LibreChat to slim badge context monitor
- `8874376` — feat: Update LibreChat submodule with context monitor implementation
- `65b627b` — chore: checkpoint before context monitor implementation
- `430d012` — feat: LibreChat + RAG API integration with embedding model migration fixes

**Submodule:**
- Path: `librechat/LibreChat`
- URL: `https://github.com/danny-avila/LibreChat.git`
- Branch: `specter-customizations`

---

## Useful File Locations for Quick Reference

| What | Where |
|------|-------|
| Current task | `agents/tasks.md` |
| Agent instructions | `agents/_entrypoint.md` |
| Change history | `agents/historylog.md` |
| RAG API code | `rag_api/main.py`, `rag_api/services/*.py` |
| LibreChat config | `librechat/librechat.yaml` |
| Database schema | `infra/initdb/002_rag_schema.sql` |
| Docker commands | `infra/compose/docker-compose.*.yml` |
| Agent roles | `agents/roles/*.md` |
| API tests | `tests/test_rag_api.py` |
| Deploy guide | `docs/AIRGAP_DEPLOYMENT.md` |
| Env defaults | `rag_api/.env.rag`, `librechat/.env.librechat` |

---

## Quick Glossary

- **RAG** — Retrieval Augmented Generation (search documents + feed to LLM)
- **pgvector** — Postgres extension for vector similarity search
- **HNSW** — Hierarchical Navigable Small World (fast nearest-neighbor indexing)
- **Tenant** — Isolated document collection per user/matter
- **Global Law** — Shared read-only corpus (Minnesota statutes)
- **Reranking** — Re-order search results using cross-encoder for better quality
- **Backfill** — Regenerate missing vector embeddings (batch operation)
- **Context Monitor** — Token budget display in LibreChat composer
- **Air-Gap** — Network isolation (no WAN calls)
- **Ollama** — Local LLM runtime (runs models without cloud)

---

## How to Use This Outline

**For New Tasks:**
1. Skim this document (2–5 minutes) to orient yourself
2. Jump to relevant section (RAG API? LibreChat? Infrastructure?)
3. Read specific source files (README.md, config.yaml, main.py)
4. Check `agents/tasks.md` and `agents/historylog.md` for context

**For Code Review:**
- Backend changes → Check `rag_api/services/` + `tests/test_rag_api.py`
- UI changes → Check `librechat/LibreChat/client/src/` + `docs/LIBRECHAT_CUSTOMIZATION.md`
- Infra changes → Check `infra/compose/` + `infra/initdb/`
- Database schema → Check `infra/initdb/002_rag_schema.sql`

**For Troubleshooting:**
- Service won't start → Check `README.md` "Troubleshooting" section
- DB issues → Check `infra/initdb/` and `tests/test_database.py`
- UI integration → Check `docs/INTEGRATION_LIBRECHAT.md`
- Vector search issues → Check `rag_api/services/query.py`

---

**End of Outline**

This document is meant to be read once by an agent to understand the full codebase context. Update this file whenever the architecture or major components change significantly.
