<prompt id="001-dictation-hardware-docs" branch="claude/follow-create-prompt-01C2kGvgTnKCF5Qy1FNn6YGf" task="Document dictation hardware requirements">
  <objective>
    Create comprehensive hardware and software prerequisite documentation for the Whisper-medium-en dictation pipeline so attorneys and operators understand GPU, driver, CUDA, and browser TLS requirements before deploying the STT feature. This documentation ensures smooth deployment and prevents confusion about why dictation requires specific hardware or why browsers block microphone access without HTTPS.
  </objective>

  <context>
    - Phase 2 roadmap calls for upgrading dictation to Whisper-medium-en running on GPU (agents/roadmap.md line 15)
    - Current system has local Whisper STT integrated but likely using smaller model (agents/historylog.md 2025-11-03 entry)
    - Browser microphone permissions require HTTPS or LAN TLS, not just HTTP (agents/roadmap.md line 15)
    - System is air-gapped for legal/confidential use, so all STT must run locally (no cloud APIs)
    - Target hardware: 24 GB 4090 build or M4 Pro Mac mini per Phase 3 plans (agents/roadmap.md line 27-28)
    - Existing documentation at docs/STT_DICTATION.md may need updates
    - README.md should surface hardware requirements prominently for operators
  </context>

  <requirements>
    - **Research Whisper-medium-en specifications:**
      - Minimum GPU VRAM (likely 4-6 GB for medium-en model)
      - Recommended GPU VRAM for smooth performance
      - CPU fallback performance characteristics (if GPU unavailable)
      - Model file size for offline download planning
      - Inference speed/latency expectations on target hardware

    - **Document GPU/CUDA requirements:**
      - NVIDIA CUDA version requirements
      - NVIDIA driver minimum version (for CUDA compatibility)
      - AMD ROCm requirements (if supporting AMD GPUs)
      - Apple Metal requirements (for M4 Pro Mac mini path)
      - Docker GPU passthrough requirements (nvidia-container-toolkit)

    - **Document browser TLS requirements:**
      - Why browsers block mic access over HTTP (security policy)
      - HTTPS certificate generation for LAN deployment
      - Self-signed cert implications and browser trust setup
      - Alternative: mDNS/Bonjour .local domains (some browsers allow mic access)
      - nginx TLS configuration references (infra/nginx/ already exists)

    - **Update documentation files:**
      - README.md: Add "Dictation Hardware Requirements" section under deployment prerequisites
      - docs/STT_DICTATION.md: Expand with GPU specs, CUDA setup, TLS certificate generation
      - Cross-link from agents/roadmap.md and agents/roadmapchecklist.md
      - Reference existing nginx TLS setup (infra/nginx/generate-certs.sh)

    - **Constraints:**
      - Air-gapped deployment: all model downloads and driver installs must be documented for offline transfer
      - No WAN dependencies: cannot rely on online resources during deployment
      - Must support both NVIDIA (4090) and Apple Silicon (M4 Pro) paths
  </requirements>

  <plan>
    - **Step 1 [Documentation Writer]:** Research Whisper-medium-en specifications
      - Check Hugging Face model card for whisper-medium-en (memory, VRAM, speed)
      - Check faster-whisper library docs (likely library in use for GPU inference)
      - Document minimum vs recommended VRAM
      - Document expected latency on 4090 vs M4 Pro
      - Note model file size for offline planning

    - **Step 2 [Infrastructure Engineer]:** Document GPU/CUDA prerequisites
      - List CUDA version requirements (faster-whisper typically needs CUDA 11.8+)
      - List NVIDIA driver minimum version (e.g., 520+ for CUDA 11.8)
      - Document nvidia-container-toolkit setup for Docker GPU passthrough
      - Document AMD ROCm alternative (if supporting AMD)
      - Document Apple Metal setup for M4 Pro path (whisper.cpp or CoreML)

    - **Step 3 [Frontend/Network Engineer]:** Document browser TLS requirements
      - Explain browser security policy blocking HTTP mic access
      - Reference existing nginx TLS setup in infra/nginx/
      - Document generate-certs.sh usage or Let's Encrypt for LAN
      - Note self-signed cert browser trust steps (Firefox, Chrome, Safari)
      - Mention .local domain alternative (if simpler for some deployments)

    - **Step 4 [Documentation Writer]:** Update README.md
      - Add "Dictation Hardware Requirements" section after existing hardware notes
      - Include GPU specs table (min VRAM, recommended VRAM, driver version)
      - Include TLS/HTTPS setup summary with link to STT_DICTATION.md
      - Add troubleshooting: "Why does browser block my microphone?"

    - **Step 5 [Documentation Writer]:** Update docs/STT_DICTATION.md
      - Expand existing guide with GPU setup steps
      - Add CUDA/driver installation walkthrough (Ubuntu/Debian focus)
      - Add TLS certificate generation section (reference nginx setup)
      - Add browser trust configuration steps (per-browser screenshots if helpful)
      - Add performance benchmarks table (4090 vs M4 Pro vs CPU fallback)

    - **Step 6 [Documentation Writer]:** Add cross-links
      - Update agents/roadmap.md to link to new docs section
      - Update agents/roadmapchecklist.md checkbox with doc reference
      - Ensure README.md links to docs/STT_DICTATION.md
      - Ensure docs/INTEGRATION_LIBRECHAT.md mentions dictation prerequisites if relevant
  </plan>

  <commands>
    - No automated tests for documentation, but executor should verify:
      - `grep -i "whisper-medium-en" README.md` (confirms README updated)
      - `grep -i "CUDA\|GPU\|VRAM" docs/STT_DICTATION.md` (confirms GPU docs added)
      - `grep -i "HTTPS\|TLS\|certificate" docs/STT_DICTATION.md` (confirms TLS docs added)
      - Links are valid (no broken references)
    - Manual review: Does documentation answer "What GPU do I need?" and "Why can't I use my microphone?"
  </commands>

  <verification>
    - **Success criteria:**
      1. README.md has clear "Dictation Hardware Requirements" section with GPU specs table
      2. docs/STT_DICTATION.md expanded with GPU setup, CUDA install, TLS cert generation
      3. Cross-links added from roadmap.md and roadmapchecklist.md
      4. Documentation covers both NVIDIA (4090) and Apple Silicon (M4 Pro) paths
      5. Browser TLS requirements explained with setup instructions
      6. Operator can answer: "What hardware do I need?" and "How do I enable my microphone?"

    - **Evidence to capture:**
      - Grep results showing new content in README.md and STT_DICTATION.md
      - Line numbers where GPU/CUDA/TLS content was added
      - Confirmation that links work (no 404s)
      - Brief summary of hardware specs documented (e.g., "min 4GB VRAM, recommended 8GB")
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md` (top of file) summarizing:
      - Documentation files updated (README.md, docs/STT_DICTATION.md)
      - Hardware specs documented (GPU VRAM, CUDA version, driver version)
      - TLS/HTTPS browser requirements documented
      - Cross-links added
      - Line numbers of key additions
    - Mark task in `agents/tasks.md` as COMPLETE with reference to historylog entry
    - Notify user that dictation hardware docs are ready for review
    - Note: This is documentation-only work; no code changes or container rebuilds required
  </handoff>
</prompt>

---

**Completion Footer:**
- **Completed:** 2025-11-18
- **Branch:** claude/follow-create-prompt-01C2kGvgTnKCF5Qy1FNn6YGf
- **Status:** ✅ COMPLETE - All verification criteria met
- **Files Modified:** README.md, docs/STT_DICTATION.md, agents/roadmap.md, agents/roadmapchecklist.md
- **Evidence:** All grep checks passed, cross-links functional, operator questions answered
- **QA Status:** Ready for review - documentation-only task, no code execution required
