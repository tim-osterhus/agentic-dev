<prompt id="001-https-lan-tls-microphone" branch="claude/follow-create-prompt-01DKM8ksa2e5hW61bdf7Miwa" task="Enable HTTPS/LAN TLS for microphone access">
  <objective>
    Enable secure HTTPS access to LibreChat across the local area network so that browsers grant microphone permissions for dictation features without requiring manual flags or localhost-only access. This unlocks the Whisper-based speech-to-text functionality for attorneys working from any device on the firm's network, supporting the air-gapped dictation workflow critical to Phase 2 productization.
  </objective>

  <context>
    - LibreChat's dictation feature uses OpenAI Whisper (local, air-gapped) for speech-to-text transcription
    - Modern browsers (Chrome, Firefox, Edge, Safari) require HTTPS for microphone API access except on localhost
    - Current setup works only on localhost (http://localhost:3080), blocking LAN device access to mic features
    - Infrastructure already includes: nginx reverse proxy config (infra/nginx/librechat-proxy.conf), self-signed cert generation script (infra/nginx/generate-certs.sh), nginx compose file (infra/compose/docker-compose.nginx.yml)
    - Existing nginx config listens on 443 with TLS, proxies to librechat:3080, includes security headers
    - Cert generation script creates self-signed certificate for specter.local domain with 365-day validity
    - Air-gapped deployment constraint: cannot use Let's Encrypt or external CA validation
    - Roadmap requirement (Phase 2): "ensure HTTPS / LAN TLS so browsers grant microphone permissions without flags"
    - STT documentation (docs/STT_DICTATION.md) notes microphone requires HTTPS in production
    - Network architecture: private network (internal=true) for backend services, public network for nginx
    - Current status: nginx service exists but may not be running; certificates may not be generated; client devices not configured
  </context>

  <requirements>
    - Generate or validate TLS certificates for LAN access (self-signed acceptable for air-gapped deployment)
    - Certificate must include Subject Alternative Names (SANs) for: specter.local, *.specter.local, localhost, and LAN IP address
    - Nginx must be configured to serve LibreChat over HTTPS on port 443 with HTTP→HTTPS redirect on port 80
    - Verify nginx docker-compose service configuration includes proper volume mounts for certificates
    - Start nginx service alongside LibreChat stack
    - Test microphone access from at least one non-localhost device on the LAN (e.g., laptop, tablet, phone)
    - Document certificate trust/onboarding process for new client devices (browsers must trust the self-signed cert)
    - Provide step-by-step guide for: generating certs, deploying stack with HTTPS, configuring client device DNS/hosts, importing certificate to trust store, verifying microphone access
    - Ensure air-gap compliance: no external certificate validation or OCSP calls
    - Maintain existing security headers (HSTS, X-Frame-Options, etc.) from librechat-proxy.conf
    - Support file uploads through HTTPS proxy (client_max_body_size already configured at 100M)
  </requirements>

  <plan>
    - **Infrastructure Engineer**: Validate and enhance certificate generation
      1. Review infra/nginx/generate-certs.sh to ensure it includes LAN IP address in SANs
      2. Determine server's LAN IP address (e.g., 192.168.1.x) and update cert script if needed
      3. Run generate-certs.sh to create fresh certificates in infra/nginx/certs/
      4. Verify certificate files: specter.crt, specter.key with correct permissions (600 for key, 644 for cert)
      5. Inspect certificate with openssl to confirm SANs include all required hostnames and IP

    - **DevOps Engineer**: Deploy HTTPS-enabled stack
      1. Ensure nginx compose file mounts certificates correctly (verify volume path: infra/nginx/certs:/etc/nginx/certs:ro)
      2. Start full stack including nginx: docker compose -f infra/compose/docker-compose.pgvector.yml -f infra/compose/docker-compose.mongo.yml -f infra/compose/docker-compose.ollama.yml -f infra/compose/docker-compose.rag.yml -f infra/compose/docker-compose.librechat.yml -f infra/compose/docker-compose.whisper.yml -f infra/compose/docker-compose.nginx.yml up -d
      3. Verify nginx container is running and healthy: docker ps | grep specter-nginx
      4. Check nginx logs for TLS errors: docker logs specter-nginx
      5. Test HTTPS endpoint from server: curl -k https://localhost (expect LibreChat HTML)
      6. Test HTTP→HTTPS redirect: curl -I http://localhost (expect 301 redirect)

    - **QA Engineer**: Test microphone access from LAN device
      1. Identify test device on same LAN (laptop, tablet, or phone)
      2. Configure DNS/hosts on test device to point specter.local to server's LAN IP
         - Linux/Mac: edit /etc/hosts, add line: <LAN_IP>  specter.local
         - Windows: edit C:\Windows\System32\drivers\etc\hosts, add same line
         - Mobile: use local DNS server or manual DNS override in Wi-Fi settings
      3. Import self-signed certificate to test device's trust store
         - Chrome/Edge: Settings > Privacy > Security > Manage certificates > Authorities > Import specter.crt
         - Firefox: Preferences > Privacy > Certificates > View Certificates > Authorities > Import specter.crt
         - Safari (macOS): Keychain Access > import specter.crt > mark as "Always Trust"
         - Mobile browsers: may require installing cert as device profile (iOS) or user certificate (Android)
      4. Open browser on test device, navigate to https://specter.local
      5. Verify no certificate warnings (if warnings appear, cert not trusted properly)
      6. Start new conversation in LibreChat
      7. Click microphone icon in chat input
      8. Verify browser prompts for microphone permission (not blocked/greyed out)
      9. Grant permission and test recording: speak a legal query (e.g., "What are estate planning requirements?")
      10. Stop recording and verify transcription appears in input box
      11. Document success/failure for each browser type tested (Chrome, Firefox, Safari, Edge, mobile browsers)

    - **Documentation Writer**: Create onboarding guide
      1. Create or update docs/HTTPS_LAN_SETUP.md with comprehensive guide
      2. Document prerequisites: server LAN IP address, administrator access to client devices
      3. Provide step-by-step certificate trust instructions for each platform (Windows, macOS, Linux, iOS, Android)
      4. Include screenshots or detailed menu paths for certificate import process
      5. Document troubleshooting steps: "Certificate not trusted" error, "NET::ERR_CERT_AUTHORITY_INVALID", microphone still blocked
      6. Add verification checklist: certificate imported → browser shows green padlock → microphone icon clickable → recording works
      7. Update README.md with link to HTTPS setup guide in "Quick Start" or "Deployment" section
      8. Update STT_DICTATION.md to reference HTTPS requirement and link to setup guide
  </plan>

  <commands>
    - Generate certificates: `cd infra/nginx && bash generate-certs.sh`
    - Inspect certificate SANs: `openssl x509 -in infra/nginx/certs/specter.crt -noout -text | grep -A1 "Subject Alternative Name"`
    - Start full stack with nginx: `docker compose -f infra/compose/docker-compose.pgvector.yml -f infra/compose/docker-compose.mongo.yml -f infra/compose/docker-compose.ollama.yml -f infra/compose/docker-compose.rag.yml -f infra/compose/docker-compose.librechat.yml -f infra/compose/docker-compose.whisper.yml -f infra/compose/docker-compose.nginx.yml up -d`
    - Verify nginx running: `docker ps | grep specter-nginx && docker logs specter-nginx | tail -20`
    - Test HTTPS locally: `curl -k -I https://localhost`
    - Test HTTP redirect: `curl -I http://localhost`
    - Check certificate expiry: `openssl x509 -in infra/nginx/certs/specter.crt -noout -dates`
    - Manual browser test: Navigate to https://specter.local from LAN device after hosts file config and cert import
  </commands>

  <verification>
    - **Success Criteria**:
      1. ✅ Certificates generated with correct SANs (specter.local, localhost, LAN IP)
      2. ✅ Nginx container running and healthy (docker ps shows "healthy" status)
      3. ✅ HTTPS endpoint accessible locally (curl -k https://localhost returns 200)
      4. ✅ HTTP redirects to HTTPS (curl http://localhost returns 301)
      5. ✅ Browser on LAN device loads https://specter.local without certificate errors (green padlock)
      6. ✅ Microphone icon clickable in LibreChat chat input on LAN device
      7. ✅ Browser prompts for microphone permission (not blocked due to insecure context)
      8. ✅ Recording and transcription works end-to-end from LAN device
      9. ✅ Documentation includes platform-specific certificate trust instructions
      10. ✅ Onboarding guide tested by following steps on at least one platform (Windows, macOS, or Linux)

    - **Evidence to Capture**:
      - Screenshot of browser showing green padlock on https://specter.local
      - Screenshot of microphone permission prompt on LAN device
      - Screenshot of successful transcription appearing in LibreChat input
      - Terminal output showing certificate SANs from openssl command
      - Terminal output showing nginx container status (healthy)
      - Copy of created HTTPS_LAN_SETUP.md documentation
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md` with:
      - Summary of HTTPS/TLS implementation (certificate approach, SANs included, platforms tested)
      - Files modified/created (list of docs, any nginx config changes, cert generation script updates)
      - Test results from each platform/browser (Chrome/Firefox/Safari/Edge on Windows/macOS/Linux/mobile)
      - Known limitations (e.g., self-signed cert warnings on platforms that don't support manual trust, mobile browser quirks)
      - Follow-up items if any (e.g., "iOS requires profile installation via MDM" or "Android Chrome may need flag override")
    - Update `agents/tasks.md`: Mark "Enable HTTPS/LAN TLS for microphone access" as COMPLETE with checkmark
    - If any blockers or incomplete items remain, document them in `agents/quickfix.md` with specific remediation steps
    - Notify user with summary: "HTTPS/TLS implementation complete. Microphone access verified on [list of tested platforms]. See docs/HTTPS_LAN_SETUP.md for onboarding new devices."
  </handoff>
</prompt>
