<prompt id="001-whisper-medium-upgrade" branch="claude/follow-create-prompt-01SmgYvfQx3hunXWfQdj5YdY" task="Upgrade dictation to Whisper-medium-en">
  <objective>
    Upgrade the Speech-to-Text (STT) backend from Whisper base.en to medium.en with GPU acceleration to improve transcription accuracy for legal dictation workflows. This matters because attorneys need highly accurate transcriptions of legal terminology, case citations, and complex sentence structures during document review and case note dictation. The medium.en model provides significantly better accuracy (rated "Great" vs "Good") at the cost of slower CPU inference, which GPU acceleration will mitigate.
  </objective>

  <context>
    - Current STT implementation uses Whisper base.en model (74MB, fast, good accuracy) - see docs/STT_DICTATION.md:38
    - Whisper service runs in Docker container (specter-whisper) using image onerahmet/openai-whisper-asr-webservice:latest
    - Service accessible at http://whisper:9000/v1/audio/transcriptions (air-gapped, local processing)
    - LibreChat configured to use Whisper via STT_PROVIDER=whisper in .env.librechat (line 36)
    - GPU infrastructure already available (Ollama container successfully using NVIDIA GPU per historylog)
    - Target model: medium.en (769MB, slow on CPU, great accuracy for legal terminology)
    - GPU acceleration configuration exists but commented out in docker-compose.whisper.yml (lines 20-27)
    - Roadmap Phase 2 goal: "Swap STT model to Whisper-medium-en (GPU inference); document hardware requirements" (roadmapchecklist.md:20)
    - Air-gap constraint: all processing must remain local, no WAN calls
    - Model files stored in Docker volume whisper_models:/root/.cache/whisper (line 19)
  </context>

  <requirements>
    - Update docker-compose.whisper.yml to set ASR_MODEL=medium.en (currently base.en at line 12)
    - Enable GPU acceleration by uncommenting and activating deploy.resources.reservations.devices section (lines 21-27)
    - Update librechat/.env.librechat STT_MODEL from base.en to medium.en (currently line 38)
    - Verify NVIDIA Docker runtime is available and CUDA drivers installed on host
    - Document GPU memory requirements for medium.en model (~5GB RAM per STT_DICTATION.md:129)
    - Document expected performance characteristics (GPU-accelerated medium.en vs CPU base.en)
    - Preserve air-gap architecture: no external API calls, all processing local
    - Maintain compatibility with LibreChat microphone button integration
    - Ensure model downloads on first startup (medium.en is 769MB vs 74MB for base.en)
  </requirements>

  <plan>
    - **Infrastructure & DevOps Engineer:**
      1. Update infra/compose/docker-compose.whisper.yml:
         - Change ASR_MODEL from "base.en" to "medium.en" (line 12)
         - Uncomment GPU deployment section (lines 21-27)
         - Add inline documentation about GPU requirements and first-run model download time
      2. Verify GPU runtime prerequisites:
         - Run `docker run --rm --gpus all nvidia/cuda:11.8.0-base-ubuntu22.04 nvidia-smi` to confirm GPU accessible
         - Check nvidia-docker runtime installed: `docker info | grep nvidia`
      3. Restart Whisper service with new configuration:
         - `docker compose -f infra/compose/docker-compose.whisper.yml down`
         - `docker compose -f infra/compose/docker-compose.whisper.yml up -d`
         - Monitor initial model download: `docker logs specter-whisper -f` (expect ~769MB download)
      4. Verify GPU utilization during transcription: `nvidia-smi` (should show specter-whisper process using GPU memory)

    - **Frontend & Integration Engineer:**
      1. Update librechat/.env.librechat:
         - Change STT_MODEL from "base.en" to "medium.en" (line 38)
         - Add comment documenting GPU acceleration and improved accuracy
      2. Restart LibreChat to pick up new STT_MODEL setting:
         - `docker compose -f infra/compose/docker-compose.librechat.yml restart librechat`
      3. Verify LibreChat can reach Whisper service:
         - Check LibreChat logs for STT configuration on startup
         - Confirm no errors connecting to http://whisper:9000

    - **QA & Test Engineer:**
      1. Execute manual dictation accuracy test (see verification section below)
      2. Compare transcription quality between base.en (if baseline available) and medium.en
      3. Measure transcription latency (target: <5 seconds for 30-second audio clip with GPU)
      4. Test with legal-specific terminology:
         - Case citations (e.g., "Smith v. Jones, 123 F.3d 456")
         - Latin terms (e.g., "per stirpes", "in terrorem clause")
         - Minnesota statutes (e.g., "Minnesota Statute 524.2-502")
      5. Document test commands and results in agents/context.txt

    - **Documentation & Enablement Writer:**
      1. Update docs/STT_DICTATION.md:
         - Change "Recommended default" from base.en to medium.en (line 64)
         - Update GPU acceleration section to reflect it's now enabled by default (lines 100-120)
         - Document medium.en as new default with GPU requirements
         - Add note about 769MB model download on first startup
      2. Update README.md if it references STT model choice
      3. Add troubleshooting entry for GPU-related issues (CUDA drivers, nvidia-docker runtime)
  </plan>

  <commands>
    - **GPU Runtime Verification:**
      ```bash
      # Verify NVIDIA Docker runtime
      docker run --rm --gpus all nvidia/cuda:11.8.0-base-ubuntu22.04 nvidia-smi

      # Check Docker runtime config
      docker info | grep -i runtime
      ```

    - **Service Deployment:**
      ```bash
      # Rebuild and restart Whisper service with GPU
      docker compose -f infra/compose/docker-compose.whisper.yml down
      docker compose -f infra/compose/docker-compose.whisper.yml up -d

      # Monitor model download (first start only, ~769MB)
      docker logs specter-whisper -f

      # Wait for "Application startup complete" message

      # Verify health
      curl http://localhost:9000/health
      ```

    - **LibreChat Configuration:**
      ```bash
      # Restart LibreChat to pick up new STT_MODEL
      docker compose -f infra/compose/docker-compose.librechat.yml restart librechat

      # Check logs for STT configuration
      docker logs specter-librechat | grep STT
      ```

    - **GPU Monitoring:**
      ```bash
      # Monitor GPU usage during transcription test
      watch -n 1 nvidia-smi

      # Should show specter-whisper process with GPU memory allocation when transcribing
      ```

    - **Manual Dictation Test:**
      ```bash
      # Test via LibreChat UI (primary method):
      # 1. Open http://localhost:3080
      # 2. Click microphone icon in chat input
      # 3. Allow browser microphone access
      # 4. Speak test phrase: "Pursuant to Minnesota Statute 524.2-502, a will must be in writing and signed by the testator or in the testator's name by some other individual in the testator's conscious presence and by the testator's direction."
      # 5. Click stop, verify accurate transcription
      # 6. Record result in agents/context.txt

      # Alternative: Direct API test
      # Record 10-second audio clip and test:
      curl http://localhost:9000/v1/audio/transcriptions \
        -F "file=@test_legal_dictation.wav" \
        -F "model=medium.en"
      ```

    - **Performance Benchmarking:**
      ```bash
      # Time a 30-second transcription
      time curl http://localhost:9000/v1/audio/transcriptions \
        -F "file=@30sec_legal_audio.wav" \
        -F "model=medium.en"

      # Target: <5 seconds with GPU (vs 15-20 seconds CPU-only)
      ```
  </commands>

  <verification>
    - **Success Criteria:**
      1. ✅ docker-compose.whisper.yml updated with ASR_MODEL=medium.en and GPU deployment enabled
      2. ✅ librechat/.env.librechat updated with STT_MODEL=medium.en
      3. ✅ specter-whisper container running with GPU access (verify with nvidia-smi)
      4. ✅ Model download completes successfully (~769MB medium.en model)
      5. ✅ Whisper service health check passes: `curl http://localhost:9000/health` returns 200
      6. ✅ LibreChat microphone button functional (no JavaScript errors)
      7. ✅ Manual dictation test produces accurate transcription of legal terminology
      8. ✅ Transcription latency acceptable (<5 seconds for 30-second clip with GPU)
      9. ✅ GPU memory usage visible during transcription (nvidia-smi shows process)
      10. ✅ Test results documented in agents/context.txt
      11. ✅ Documentation updated (STT_DICTATION.md reflects medium.en as default)

    - **Evidence to Capture:**
      - Screenshot or logs showing medium.en model loaded successfully
      - nvidia-smi output during active transcription (proving GPU utilization)
      - Transcription result of legal test phrase showing accuracy
      - Timing data comparing CPU base.en (if available) vs GPU medium.en
      - LibreChat UI screenshot showing microphone button and transcribed text
      - Any error messages or warnings encountered during deployment

    - **QA Validation Steps:**
      1. Verify configuration files changed correctly (git diff to show ASR_MODEL and STT_MODEL updates)
      2. Confirm GPU runtime accessible (docker run nvidia-smi test)
      3. Observe model download in logs (769MB medium.en download completes)
      4. Test STT endpoint directly with curl (bypasses UI, validates service)
      5. Test through LibreChat UI (validates end-to-end integration)
      6. Monitor GPU during transcription (nvidia-smi shows memory usage spike)
      7. Test accuracy with legal terminology (case citations, Latin phrases, statute numbers)
      8. Compare accuracy to previous base.en if baseline available
  </verification>

  <handoff>
    - **Update agents/historylog.md:**
      - Add new entry at top: `## [YYYY-MM-DD] Infrastructure + QA • Upgrade STT to Whisper medium.en with GPU (COMPLETE)`
      - Document: files touched, model size change (74MB→769MB), GPU enablement, performance characteristics
      - Note: transcription accuracy improvement for legal terminology
      - Record: test results from agents/context.txt
      - Mention: first startup takes longer due to model download
      - Capture: any GPU memory requirements discovered (should be ~5GB)

    - **Clear agents/tasks.md:**
      - Remove completed task "2025-11-05 — Upgrade dictation to Whisper-medium-en"
      - If no tasks remain, add placeholder: "(No active tasks - check tasksbacklog.md)"

    - **Notify user:**
      - Confirm dictation accuracy improved
      - Document transcription latency (should be faster with GPU despite larger model)
      - Note first-run model download requirement (769MB)
      - Provide GPU memory requirement (~5GB) for deployment planning
      - Suggest next task from roadmapchecklist.md if applicable (e.g., HTTPS/LAN TLS for browser mic permissions)

    - **Optional Follow-ups:**
      - If accuracy still insufficient, consider large model (1550MB, best accuracy)
      - If GPU memory constrained, document fallback to base.en or small.en
      - Add legal vocabulary customization if supported by Whisper service
      - Implement transcription audit logging for compliance (Phase 4)
  </handoff>
</prompt>

---

## Execution Record

**Completed:** 2025-11-18
**Branch:** claude/follow-create-prompt-01SmgYvfQx3hunXWfQdj5YdY
**Commit:** 976037c

**Status:** Configuration changes complete and committed. Ready for manual deployment.

**Builder Execution Summary:**
- ✅ All configuration files updated (docker-compose.whisper.yml, .env.librechat, STT_DICTATION.md)
- ✅ Documentation updated with GPU requirements and troubleshooting
- ✅ Changes committed and pushed to remote branch
- ⏳ Manual deployment required (Docker unavailable in build environment)
- ⏳ Testing required after deployment

**Deployment Steps (Manual):**
See historylog.md entry dated 2025-11-18 for complete deployment instructions.

**QA Status:** Pending deployment and testing
