<prompt id="003-hybrid-lexical-dense-retrieval" branch="claude/move-hybrid-retrieval-task-015JSiwNtD7bfyFAASo3VCy1" task="Add hybrid lexical+dense retrieval option">
  <objective>
    Complement the existing pgvector dense vector search with optional pg_trgm lexical scoring and reciprocal-rank fusion to boost recall on short snippets, exact terminology matches, and legal citations that may not be semantically captured by embeddings alone. This hybrid approach ensures attorneys can retrieve both semantically similar documents and exact phrase matches, improving the reliability of citation-backed answers in edge cases where pure dense search may miss critical legal language.
  </objective>

  <context>
    - Current retrieval: Pure dense vector search via pgvector with HNSW indexing, cosine similarity (query.py:98-156)
    - Database: Postgres 15+ with pgvector extension enabled (infra/initdb/001_pgvector.sql)
    - Schema: global_law and tenant_<id> tables with vector(768) embeddings (infra/initdb/002_rag_schema.sql)
    - Embedding model: nomic-embed-text (768-dim) via Ollama, canonical model for all collections
    - Query service: rag_api/services/query.py orchestrates search, deduplication, reranking, and audit logging
    - Reranking: Optional cross-encoder reranking already implemented (query.py:166-187)
    - RAG strategy: agents/ragstrategy.md mentions "Hybrid option (Phase 2/3) enabling pg_trgm lexical scoring with future reciprocal-rank fusion" (line 18)
    - Air-gap constraint: No external dependencies, all models/extensions must work offline
    - Roadmap: Phase 2 productization includes enhanced retrieval before scaling to Phase 3 hardware
    - pg_trgm: Standard Postgres extension for trigram-based text similarity, well-suited for legal text matching
    - Reciprocal Rank Fusion (RRF): Algorithm for merging ranked lists from different retrieval methods (1/(k + rank))
    - Configuration: config.py uses pydantic-settings with .env.rag environment variables
    - Current search threshold: SCORE_THRESHOLD = 0.3 (config.py:28)
    - Top-K default: TOP_K = 8 (config.py:27)
  </context>

  <requirements>
    - Enable pg_trgm extension in database initialization scripts (infra/initdb/)
    - Add configuration flags to control hybrid search behavior:
      * HYBRID_SEARCH_ENABLED: bool (default: False) - master toggle for hybrid mode
      * HYBRID_LEXICAL_WEIGHT: float (default: 0.3) - weight for lexical scores in fusion (0.0-1.0)
      * HYBRID_FUSION_METHOD: str (default: "rrf") - options: "rrf" (reciprocal rank fusion), "weighted_sum"
      * HYBRID_RRF_K: int (default: 60) - constant for RRF algorithm (1/(k + rank))
    - Update rag_api/services/query.py to support dual-path retrieval:
      * Run lexical search in parallel with vector search when hybrid mode enabled
      * Implement RRF fusion algorithm for combining ranked results
      * Implement weighted sum fusion as alternative method
      * Preserve existing deduplication, reranking, and audit logging
      * Add hybrid search metadata to audit logs (method used, lexical score, fusion score)
    - Create GIN trigram indexes on content/title/snippet columns for efficient text search
    - Support hybrid search for both global_law and tenant collections
    - Maintain backward compatibility: when HYBRID_SEARCH_ENABLED=False, use current vector-only path
    - Document CPU impact of trigram indexing and text search (index size, query latency)
    - Create test fixtures demonstrating cases where hybrid search improves recall:
      * Exact legal citations (e.g., "524.2-502" statute number)
      * Short technical phrases (e.g., "testator's signature")
      * Abbreviations and acronyms common in legal text
    - Air-gap compliance: pg_trgm is bundled with standard Postgres, no external dependencies
    - Update documentation with hybrid search configuration, CPU impact guidance, and testing examples
  </requirements>

  <plan>
    - **Backend Systems Engineer**: Enable pg_trgm extension and create indexes
      1. Review infra/initdb/001_pgvector.sql to understand extension loading pattern
      2. Create new migration script infra/initdb/003_pg_trgm.sql that:
         * Enables pg_trgm extension
         * Creates GIN trigram indexes on global_law (content, title, snippet)
         * Creates function to add trigram indexes to tenant collections
         * Updates create_tenant_collection() to include trigram indexes
      3. Test migration on local database: docker exec into specter-pgvector, run migration manually
      4. Verify indexes created successfully: \di global_law* to list indexes
      5. Test trigram similarity query manually: SELECT title, similarity(content, 'testator signature') AS score FROM global_law WHERE content % 'testator signature' ORDER BY score DESC LIMIT 5;

    - **Backend Systems Engineer**: Add hybrid search configuration
      1. Update rag_api/config.py to add hybrid search settings:
         * HYBRID_SEARCH_ENABLED: bool = False
         * HYBRID_LEXICAL_WEIGHT: float = 0.3
         * HYBRID_FUSION_METHOD: str = "rrf"
         * HYBRID_RRF_K: int = 60
      2. Add validation: ensure HYBRID_LEXICAL_WEIGHT is between 0.0 and 1.0
      3. Add validation: ensure HYBRID_FUSION_METHOD is in ["rrf", "weighted_sum"]
      4. Document each setting with inline comments explaining impact and recommended values
      5. Update rag_api/.env.rag with example configuration (commented out by default)

    - **Backend Systems Engineer**: Implement lexical search method
      1. Add _search_collection_lexical() method to QueryService class in query.py
      2. Implement pg_trgm similarity search using similarity() function and % operator
      3. Return same dict structure as _search_collection() for consistent downstream processing
      4. Include both similarity score and word_similarity score for better short-phrase matching
      5. Apply same filters (tags, metadata) as vector search for consistency
      6. Handle exceptions gracefully: if trigram indexes missing, log warning and return empty results

    - **Backend Systems Engineer**: Implement fusion algorithms
      1. Add _fuse_results_rrf() method implementing reciprocal rank fusion:
         * Formula: score = sum(1 / (k + rank)) for each result across both ranked lists
         * Use HYBRID_RRF_K constant (default 60, common in literature)
         * Normalize scores to 0-1 range for consistency with vector scores
      2. Add _fuse_results_weighted() method implementing weighted sum:
         * Formula: score = (1 - w) * vector_score + w * lexical_score
         * Use HYBRID_LEXICAL_WEIGHT for weighting
         * Handle missing scores gracefully (e.g., result only in one list)
      3. Add _fuse_hybrid_results() dispatcher that calls appropriate fusion method based on config
      4. Preserve metadata from both sources (vector_score, lexical_score, fusion_method) for debugging

    - **Backend Systems Engineer**: Integrate hybrid search into query flow
      1. Modify QueryService.query() method to check HYBRID_SEARCH_ENABLED flag
      2. When enabled, run both _search_collection() and _search_collection_lexical() in sequence for each collection
      3. Merge results using _fuse_hybrid_results() before deduplication
      4. Update _log_query_audit() to include hybrid search metadata (method, lexical_weight, fusion_method)
      5. Ensure backward compatibility: when disabled, use existing vector-only path without performance overhead
      6. Add debug logging showing number of results from each path and fusion scores

    - **Backend Systems Engineer**: Update tenant collection creation
      1. Modify create_tenant_collection() SQL function in 002_rag_schema.sql to include trigram indexes
      2. Add GIN indexes on content, title, snippet for new tenant tables
      3. Test dynamic tenant creation: call create_tenant_collection('test_hybrid') and verify indexes
      4. Document index creation impact: GIN indexes take ~30% more space than no index

    - **QA Test Engineer**: Create hybrid search test fixtures
      1. Add test cases in tests/test_rag_api.py for hybrid search scenarios:
         * Test exact citation matching (e.g., "524.2-502" should retrieve MN Statute 524.2-502)
         * Test short phrase matching (e.g., "testator's signature" retrieval)
         * Test acronym/abbreviation matching
         * Test hybrid disabled (should use vector-only path)
         * Test RRF fusion vs weighted sum fusion (compare results)
      2. Create fixtures/hybrid_test_queries.json with known test queries and expected doc_ids
      3. Add test_hybrid_search_enabled() checking that both vector and lexical results are merged
      4. Add test_hybrid_search_disabled() verifying vector-only path still works
      5. Add test_fusion_methods() comparing RRF vs weighted sum output
      6. Add performance benchmark: measure query latency with hybrid on vs off (expect <2x increase)

    - **Documentation Writer**: Document hybrid search feature
      1. Create docs/HYBRID_RETRIEVAL.md with comprehensive guide:
         * Overview: Why hybrid search? When to enable it? Performance tradeoffs
         * Configuration: All HYBRID_* environment variables with examples
         * CPU impact: Estimated index size increase (~30%), query latency increase (~1.5-2x)
         * Testing guidance: How to verify hybrid search is working, sample queries
         * Troubleshooting: Missing indexes, poor lexical matches, fusion method selection
      2. Update README.md to mention hybrid retrieval feature in "Features" section
      3. Update agents/ragstrategy.md to reflect hybrid search as implemented (Phase 2)
      4. Add inline code comments in query.py explaining RRF algorithm and fusion logic
      5. Document recommended use cases: legal citations, exact phrase matching, technical terminology

    - **Documentation Writer**: Update configuration documentation
      1. Update rag_api/.env.rag with example hybrid search configuration
      2. Add comments explaining each HYBRID_* variable and recommended values
      3. Document performance tradeoffs: "Hybrid search increases recall by ~15-20% on exact phrase queries but adds ~50-100ms latency"
      4. Provide decision tree: "Enable hybrid if you frequently query exact citations or technical terms; disable for pure semantic search use cases"
  </plan>

  <commands>
    - Enable pg_trgm extension: `docker exec -it specter-pgvector psql -U specter -d specter_legal -c "CREATE EXTENSION IF NOT EXISTS pg_trgm;"`
    - Verify extension enabled: `docker exec -it specter-pgvector psql -U specter -d specter_legal -c "\dx pg_trgm"`
    - Run new migration script: `docker exec -i specter-pgvector psql -U specter -d specter_legal < infra/initdb/003_pg_trgm.sql`
    - Verify trigram indexes created: `docker exec -it specter-pgvector psql -U specter -d specter_legal -c "\di global_law*"`
    - Test trigram similarity manually: `docker exec -it specter-pgvector psql -U specter -d specter_legal -c "SELECT title, similarity(content, 'testator signature') AS score FROM global_law WHERE content % 'testator signature' ORDER BY score DESC LIMIT 5;"`
    - Rebuild RAG API container: `docker compose -f infra/compose/docker-compose.rag.yml build --no-cache`
    - Restart RAG API with new config: `docker compose -f infra/compose/docker-compose.pgvector.yml -f infra/compose/docker-compose.mongo.yml -f infra/compose/docker-compose.ollama.yml -f infra/compose/docker-compose.rag.yml up -d --force-recreate rag-api`
    - Test hybrid search via API: `curl -X POST http://localhost:8001/query -H "Content-Type: application/json" -d '{"query": "testator signature requirements", "tenant_id": null, "top_k": 5, "merge_global": true}'`
    - Run test suite: `pytest tests/test_rag_api.py::test_hybrid_search_enabled tests/test_rag_api.py::test_hybrid_search_disabled tests/test_rag_api.py::test_fusion_methods -v`
    - Check audit logs for hybrid metadata: `docker exec -it specter-pgvector psql -U specter -d specter_legal -c "SELECT query_text, filters->'fusion_method' AS fusion, latency_ms FROM query_audit ORDER BY created_at DESC LIMIT 10;"`
    - Benchmark query latency: `time curl -X POST http://localhost:8001/query -H "Content-Type: application/json" -d '{"query": "will execution", "merge_global": true}'` (run with HYBRID_SEARCH_ENABLED=true vs false, compare times)
  </commands>

  <verification>
    - **Success Criteria**:
      1. ✅ pg_trgm extension enabled in database (\dx shows pg_trgm installed)
      2. ✅ GIN trigram indexes created on global_law (content, title, snippet)
      3. ✅ Trigram indexes automatically created for new tenant collections
      4. ✅ HYBRID_* configuration variables added to config.py with validation
      5. ✅ _search_collection_lexical() method implemented and tested
      6. ✅ _fuse_results_rrf() and _fuse_results_weighted() methods implemented with correct algorithms
      7. ✅ QueryService.query() supports hybrid mode when HYBRID_SEARCH_ENABLED=True
      8. ✅ Backward compatibility: HYBRID_SEARCH_ENABLED=False uses vector-only path
      9. ✅ Audit logs include hybrid search metadata (fusion_method, lexical_weight)
      10. ✅ Test suite passes for hybrid enabled/disabled scenarios
      11. ✅ Exact citation queries (e.g., "524.2-502") retrieve correct statute with hybrid search
      12. ✅ Short phrase queries (e.g., "testator's signature") show improved recall vs vector-only
      13. ✅ Query latency with hybrid search is <2x vector-only baseline
      14. ✅ Documentation includes configuration guide, CPU impact analysis, and testing examples
      15. ✅ Code includes inline comments explaining fusion algorithms

    - **Evidence to Capture**:
      - Terminal output showing pg_trgm extension installed (\dx command)
      - Terminal output showing trigram indexes created (\di command)
      - Screenshot or terminal output of manual trigram similarity query returning results
      - pytest output showing all hybrid search tests passing
      - API response showing both vector_score and lexical_score in results metadata
      - Audit log entries showing fusion_method field populated
      - Latency benchmark comparison: hybrid vs vector-only (terminal output with time measurements)
      - Sample query demonstrating improved recall: exact citation "524.2-502" retrieval
      - Copy of created HYBRID_RETRIEVAL.md documentation
      - Git diff showing config.py changes with new HYBRID_* variables
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md` with:
      - Summary of hybrid retrieval implementation (pg_trgm setup, fusion algorithms used, configuration added)
      - Files created: infra/initdb/003_pg_trgm.sql, docs/HYBRID_RETRIEVAL.md
      - Files modified: rag_api/config.py, rag_api/services/query.py, infra/initdb/002_rag_schema.sql, tests/test_rag_api.py, README.md, agents/ragstrategy.md, rag_api/.env.rag
      - Performance impact: index size increase (~30%), query latency increase (~1.5-2x), recall improvement (~15-20% on exact phrase queries)
      - Test results: All test cases passing, exact citation matching verified, latency benchmarks documented
      - Configuration recommendations: Enable hybrid for exact citation/technical term use cases, disable for pure semantic search
      - Known limitations: GIN indexes increase disk usage, lexical search less effective on highly semantic queries
      - Follow-up items: Monitor query performance in production, consider adding similarity threshold tuning, explore alternative fusion algorithms if needed
    - Update `agents/tasks.md`: Mark "Add hybrid lexical+dense retrieval option" as COMPLETE with checkmark
    - Move prompt artifact from `agents/prompts/tasks/` to `agents/prompts/completed/` with completion footer:
      ```
      ---
      Completed: 2025-11-18
      Branch: claude/move-hybrid-retrieval-task-015JSiwNtD7bfyFAASo3VCy1
      QA Status: Ready for validation
      ```
    - Notify user with summary: "Hybrid lexical+dense retrieval implementation complete. Feature can be toggled via HYBRID_SEARCH_ENABLED config. See docs/HYBRID_RETRIEVAL.md for configuration and testing guidance. Latency impact: ~1.5-2x, recall improvement: ~15-20% on exact phrase queries."
  </handoff>
</prompt>
