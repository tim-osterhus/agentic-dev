<prompt id="002-in-app-cert-onboarding" branch="claude/follow-create-prompt-017oRJrUqz7N3ZmTiYKVM9wy" task="In-app HTTPS certificate onboarding for dictation">
  <objective>
    When users attempt to enable dictation from non-localhost devices, present an in-app modal that guides them through downloading and trusting the local TLS certificate, enabling microphone access without leaving LibreChat. This eliminates the need for users to manually reference external documentation and streamlines the onboarding experience for attorneys across the firm's network who need secure dictation functionality.
  </objective>

  <context>
    - Modern browsers require HTTPS for microphone API access (except localhost per WebRTC specification)
    - Existing HTTPS/TLS infrastructure documented in docs/HTTPS_LAN_SETUP.md with comprehensive platform-specific instructions
    - Self-signed certificate available at infra/nginx/certs/specter.crt for air-gapped deployment
    - Browser security APIs provide detection mechanisms: navigator.mediaDevices.getUserMedia() errors, window.isSecureContext
    - Current UX: users click mic icon and get browser-level permission denial on non-HTTPS contexts
    - Target users: attorneys on LAN devices (tablets, laptops, phones) accessing https://specter.local or https://<LAN_IP>
    - Onboarding only needed once per device (subsequent visits skip modal if cert already trusted)
    - Phase 2 roadmap goal: "ensure HTTPS / LAN TLS so browsers grant microphone permissions without flags"
    - Air-gapped constraint: modal must work entirely offline, no external CDN dependencies
    - Existing documentation provides platform-specific instructions that can be repurposed for in-app display
  </context>

  <requirements>
    - Detect insecure context or microphone permission failures before showing modal
      * Use window.isSecureContext to check if HTTPS is active
      * Catch navigator.mediaDevices.getUserMedia() errors indicating insecure context
      * Alternative: ping /cert-check endpoint (if implemented server-side) to validate certificate trust
    - Display modal only when certificate onboarding is needed (skip for localhost and already-trusted contexts)
    - Modal UI components:
      * Title: "Enable Microphone for Dictation"
      * Explanation: Brief text explaining HTTPS requirement and one-time setup
      * Tab navigation for OS/browser-specific instructions (Windows, macOS, Linux, iOS, Android)
      * "Download Certificate" button pointing to /certs/specter.crt (or bundled cert endpoint)
      * Collapsible/tabbed instruction sections with concise steps per platform
      * "Verify & Continue" button that re-runs microphone permission check
      * "Skip" or "Dismiss" option for users who want to defer setup
    - Repurpose content from docs/HTTPS_LAN_SETUP.md Part 2 (Client Device Setup) into user-friendly in-app format
      * Simplify technical language for non-technical users
      * Use bullet points or numbered steps
      * Highlight platform detection if possible (e.g., auto-expand macOS tab on Mac)
    - Re-check mechanism:
      * "Verify & Continue" button triggers fresh getUserMedia() permission request
      * If successful (cert now trusted), dismiss modal and enable dictation
      * If still failing, show error message with troubleshooting hints
    - Persistence: Remember if user dismissed modal to avoid repeated interruptions (localStorage or session flag)
    - Accessibility: keyboard navigation, ARIA labels, screen reader support
    - Air-gap compliance: no external resources, all instructions and assets bundled locally
    - Admin configurability: document how to update instruction text if cert paths or hostnames change
  </requirements>

  <plan>
    - **Frontend Engineer**: Implement certificate onboarding modal component
      1. Create modal component in LibreChat client (e.g., librechat/LibreChat/client/src/components/Dictation/CertOnboardingModal.tsx)
      2. Implement detection logic:
         - Check window.isSecureContext on component mount
         - Wrap getUserMedia() call in try/catch to detect permission/security errors
         - Set state flag to show/hide modal based on detection results
      3. Build modal UI:
         - Header with clear title and explanation
         - Tabbed interface for OS/browser instructions (Windows/macOS/Linux/iOS/Android)
         - Download button for certificate (/certs/specter.crt or static asset endpoint)
         - Collapsible instruction sections per platform (reuse HTTPS_LAN_SETUP.md content)
         - "Verify & Continue" button and "Skip" button
      4. Implement platform detection (optional enhancement):
         - Use navigator.userAgent or navigator.platform to auto-select relevant tab
         - Example: detect macOS and pre-expand macOS instructions
      5. Add re-check handler:
         - "Verify & Continue" button triggers fresh getUserMedia() call
         - On success: dismiss modal, enable dictation, set localStorage flag (cert-onboarded: true)
         - On failure: display inline error message with troubleshooting link
      6. Persist dismissal state:
         - Use localStorage to remember if user clicked "Skip" (avoid repeated modals)
         - Clear flag if user explicitly clicks mic icon again (re-trigger onboarding)
      7. Integrate modal into dictation workflow:
         - Trigger modal when mic icon clicked AND insecure context detected
         - Skip modal if window.isSecureContext === true and getUserMedia succeeds
         - Skip modal if localStorage['cert-onboarded'] === 'true'

    - **Content Writer**: Adapt platform-specific instructions for in-app display
      1. Extract relevant sections from docs/HTTPS_LAN_SETUP.md Part 2 (Client Device Setup)
      2. Simplify language for non-technical attorneys:
         - Replace "trust store" with "install certificate"
         - Remove command-line instructions where possible, focus on GUI steps
         - Shorten to 3-5 key steps per platform (not comprehensive troubleshooting)
      3. Create concise instruction text for each platform:
         - Windows (Chrome/Edge): Settings → Security → Manage certificates → Authorities → Import
         - macOS (all browsers): Keychain Access → Import → Always Trust
         - Linux (Chrome): Copy to /usr/local/share/ca-certificates, run update-ca-certificates
         - iOS: Email cert → Install Profile → Certificate Trust Settings
         - Android: Settings → Security → Install certificate → CA certificate
      4. Add visual hints if possible (icons, emoji, or small illustrations)
      5. Document how admins can update instruction text in code (e.g., constant file or config)

    - **Backend Engineer (optional)**: Implement /cert-check endpoint
      1. Add lightweight endpoint in LibreChat or nginx to validate certificate trust
      2. Returns 200 if request made over HTTPS with trusted cert, 403 otherwise
      3. Frontend can ping this endpoint as alternative detection method
      4. Document endpoint in API docs or inline comments
      5. **Note**: This step is optional; client-side window.isSecureContext may be sufficient

    - **QA Engineer**: Test onboarding flow across devices and browsers
      1. Test on fresh device without certificate installed:
         - Navigate to https://specter.local from LAN device
         - Click microphone icon
         - Verify modal appears (not browser permission prompt)
         - Verify correct platform tab is shown (if auto-detection implemented)
      2. Follow in-app instructions to install certificate:
         - Click "Download Certificate" button (cert file downloads)
         - Import certificate following modal instructions
         - Click "Verify & Continue"
         - Verify modal dismisses and browser now prompts for microphone permission
         - Grant permission and verify dictation works
      3. Test skip behavior:
         - On fresh device, click "Skip" button
         - Verify modal dismisses
         - Refresh page or re-click mic icon
         - Verify modal does NOT reappear (localStorage flag prevents it)
      4. Test on already-trusted device:
         - Navigate to https://specter.local from device that already trusts cert
         - Click microphone icon
         - Verify modal does NOT appear (secure context detected, skips onboarding)
         - Verify browser directly prompts for microphone permission
      5. Test localhost exception:
         - Navigate to http://localhost:3080
         - Click microphone icon
         - Verify modal does NOT appear (localhost always secure context)
         - Verify browser prompts for microphone permission
      6. Test on non-HTTPS context:
         - Navigate to http://<LAN_IP>:3080 (insecure HTTP)
         - Click microphone icon
         - Verify modal appears with clear HTTPS requirement message
      7. Document test results per platform/browser combination (Chrome, Firefox, Safari, Edge on Windows/macOS/Linux/mobile)

    - **Documentation Writer**: Update admin docs with configuration guidance
      1. Add section to docs/HTTPS_LAN_SETUP.md or create docs/CERT_ONBOARDING_MODAL.md
      2. Document modal trigger conditions (insecure context, getUserMedia errors)
      3. Explain how admins can customize instruction text (e.g., if using custom domain or corporate CA)
      4. Document localStorage flags and how to clear them for testing
      5. Add troubleshooting guide for common issues:
         - Modal not appearing: check window.isSecureContext value
         - Modal appearing on localhost: check for localhost detection logic
         - "Verify & Continue" fails: cert not properly imported, refer to full HTTPS_LAN_SETUP.md
      6. Link modal docs from README.md and STT_DICTATION.md
  </plan>

  <commands>
    - **Development**:
      - Build LibreChat with modal component: `docker compose -f infra/compose/docker-compose.librechat.yml up -d --build`
      - Check for TypeScript errors: `cd librechat/LibreChat && npm run type-check`
      - Check for linting warnings: `npm run lint`

    - **Testing (requires manual browser testing)**:
      - Navigate to https://specter.local on fresh device (no cert installed)
      - Click microphone icon and verify modal appears
      - Download certificate via modal button: `wget https://specter.local/certs/specter.crt`
      - Import certificate following modal instructions
      - Click "Verify & Continue" and verify modal dismisses
      - Verify browser prompts for microphone permission
      - Test recording: speak test phrase → verify transcription appears

    - **Detection validation**:
      - Open browser console on HTTPS site: `console.log(window.isSecureContext)` → should be true
      - Open browser console on HTTP site: `console.log(window.isSecureContext)` → should be false
      - Test getUserMedia error handling: `navigator.mediaDevices.getUserMedia({audio: true}).catch(err => console.error(err))`

    - **Persistence validation**:
      - Check localStorage after clicking "Skip": `localStorage.getItem('cert-onboarded')`
      - Clear flag for testing: `localStorage.removeItem('cert-onboarded')`
  </commands>

  <verification>
    - **Success Criteria**:
      1. ✅ Modal component created in LibreChat client with tabbed OS/browser instructions
      2. ✅ Detection logic correctly identifies insecure contexts (window.isSecureContext or getUserMedia errors)
      3. ✅ Modal appears when mic icon clicked on non-localhost device without trusted certificate
      4. ✅ Modal does NOT appear on localhost or devices with already-trusted certificates
      5. ✅ "Download Certificate" button successfully downloads infra/nginx/certs/specter.crt
      6. ✅ Platform-specific instructions displayed (Windows/macOS/Linux/iOS/Android tabs or sections)
      7. ✅ "Verify & Continue" button re-checks microphone permission and dismisses modal on success
      8. ✅ "Skip" button dismisses modal and sets localStorage flag to prevent repeated interruptions
      9. ✅ After following instructions, browser grants microphone permission and dictation works
      10. ✅ Keyboard navigation and ARIA labels implemented for accessibility
      11. ✅ No external dependencies (all assets bundled locally for air-gap compliance)
      12. ✅ Admin documentation explains how to customize instruction text

    - **Evidence to Capture**:
      - Screenshot of modal on fresh device (before certificate installation)
      - Screenshot showing platform tabs/sections (Windows, macOS, Linux, iOS, Android)
      - Screenshot of successful modal dismissal after "Verify & Continue"
      - Screenshot of browser microphone permission prompt after modal dismisses
      - Screenshot of successful transcription in LibreChat input box
      - Browser console output showing window.isSecureContext values (true on HTTPS, false on HTTP)
      - localStorage contents showing 'cert-onboarded' flag after skip/completion
      - Code snippets showing detection logic and modal integration points
      - Documentation updates (HTTPS_LAN_SETUP.md or new CERT_ONBOARDING_MODAL.md)
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md` with:
      - Summary of certificate onboarding modal implementation
      - Files created/modified (modal component, instruction content, integration points)
      - Platforms tested (Windows/macOS/Linux/iOS/Android browser combinations)
      - Detection logic approach (window.isSecureContext vs getUserMedia errors vs /cert-check endpoint)
      - Persistence mechanism (localStorage flags and expiry behavior)
      - Known limitations (e.g., "iOS Safari requires profile installation, cannot be fully automated")
      - Follow-up items if any (e.g., "Add visual screenshots to modal", "Implement server-side /cert-check endpoint")
    - Update `agents/tasks.md`: Mark "In-app HTTPS certificate onboarding for dictation" as COMPLETE with checkmark
    - If blockers or incomplete items remain, document in `agents/quickfix.md` with specific remediation steps
    - Notify user with summary: "Certificate onboarding modal implemented. Tested on [list platforms]. Users on fresh devices now see in-app guidance when clicking mic icon. See docs/HTTPS_LAN_SETUP.md for admin configuration."
    - Document how admins can update instruction text if deployment uses custom domain (not specter.local) or corporate CA
  </handoff>
</prompt>
