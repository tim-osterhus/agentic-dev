<prompt id="002-whisper-dns-diagnosis" branch="claude/follow-create-prompt-01Ea18zf4BtGJbjxmHj9J9Ab" task="Diagnose Whisper DNS failures in Docker">
  <objective>
    Identify and fix DNS resolution failures in the specter-whisper Docker container that prevent automatic Whisper model downloads from https://openaipublic.azureedge.net/. Other containers in the same Docker stack resolve external hosts successfully, suggesting a container-specific networking issue. The fix must enable automatic model downloads on first startup without manual workarounds or pre-cached models, maintaining the air-gapped deployment's plug-and-play experience.
  </objective>

  <context>
    - Whisper service uses upstream image: onerahmet/openai-whisper-asr-webservice:latest
    - Container configured in infra/compose/docker-compose.whisper.yml with GPU acceleration
    - Current model: medium.en (769MB, downloaded from OpenAI CDN on first startup)
    - Error observed: `socket.gaierror [Errno -3] Temporary failure in name resolution` when trying to reach openaipublic.azureedge.net
    - Docker networking: Custom 'private' network (bridge driver) shared across all services
    - Other containers (busybox, ollama) successfully resolve external hosts on the same network
    - This suggests issue is specific to specter-whisper container configuration or upstream image
    - Phase 2 requirement: Whisper-medium-en running on GPU for attorney dictation (roadmap.md:15-17)
    - GPU acceleration already configured with nvidia-docker runtime (docker-compose.whisper.yml:23-29)
    - Documentation exists at docs/STT_DICTATION.md but may need updates based on findings
  </context>

  <requirements>
    - Reproduce DNS failure consistently (capture full stack trace and docker logs output)
    - Investigate Docker networking: inspect 'private' network configuration, DNS settings, nameserver configuration
    - Test whether issue is network-mode-specific: try default bridge, host network mode, bridge with explicit DNS
    - Debug from inside container: exec into specter-whisper, run nslookup/dig/curl, inspect /etc/resolv.conf
    - Compare working container (ollama or busybox) vs broken container (specter-whisper): network config, resolv.conf, capabilities
    - Determine if upstream image has hardcoded DNS assumptions or missing network capabilities
    - Provide stable, reproducible fix that works across different host environments (development machines, production deployments)
    - Update docker-compose.whisper.yml with fix (network mode, dns settings, extra capabilities, or environment variables)
    - Document findings and fix in docs/STT_DICTATION.md under new "Troubleshooting DNS Issues" section
    - Ensure fix maintains GPU acceleration and air-gapped operation (no changes that break existing functionality)
    - Verify fix works: container starts cleanly, downloads medium.en model automatically, no DNS errors in logs
  </requirements>

  <plan>
    - **DevOps Engineer**: Reproduce failure and gather diagnostics
      1. Start full compose stack as documented (list all compose files from existing setup)
      2. Capture specter-whisper container logs showing DNS failure: `docker logs specter-whisper`
      3. Record exact error message, stack trace, and timestamp
      4. Verify other containers can resolve external hosts: `docker exec specter-ollama curl -I https://openaipublic.azureedge.net/`
      5. Document baseline: which containers work, which fail, all using same 'private' network

    - **Network Engineer**: Inspect Docker networking configuration
      1. Inspect 'private' network: `docker network inspect private`
      2. Check DNS configuration: look for custom DNS servers, IPAM config, internal/external flags
      3. Inspect specter-whisper container network settings: `docker inspect specter-whisper | grep -A 20 NetworkSettings`
      4. Compare resolv.conf between working and broken containers:
         - `docker exec specter-ollama cat /etc/resolv.conf`
         - `docker exec specter-whisper cat /etc/resolv.conf`
      5. Check Docker daemon DNS configuration: `cat /etc/docker/daemon.json` (if exists)
      6. Document findings: any differences in DNS nameservers, search domains, or network capabilities

    - **Systems Debugger**: Test DNS resolution from inside specter-whisper container
      1. Exec into running container: `docker exec -it specter-whisper /bin/bash` (or /bin/sh)
      2. Install debugging tools if not present: `apt-get update && apt-get install -y dnsutils curl iputils-ping` (or equivalent for Alpine)
      3. Test DNS resolution: `nslookup openaipublic.azureedge.net` and `dig openaipublic.azureedge.net`
      4. Test connectivity: `ping -c 3 8.8.8.8` (IP), `ping -c 3 openaipublic.azureedge.net` (DNS)
      5. Test HTTP request: `curl -v https://openaipublic.azureedge.net/`
      6. Check nameserver reachability: `ping -c 3 <nameserver_from_resolv.conf>`
      7. Document which step fails: DNS query to nameserver? Nameserver unreachable? DNS query succeeds but connection fails?

    - **Docker Specialist**: Test network mode variations
      1. Stop specter-whisper: `docker compose -f infra/compose/docker-compose.whisper.yml down`
      2. **Test A: Default bridge network**
         - Edit docker-compose.whisper.yml: comment out `networks: - private`, add `network_mode: bridge`
         - Start container: `docker compose -f infra/compose/docker-compose.whisper.yml up -d`
         - Check logs for DNS errors
         - Document result: does default bridge fix DNS?
      3. **Test B: Host network mode**
         - Edit docker-compose.whisper.yml: change to `network_mode: host`
         - Start container (note: port binding removed in host mode)
         - Check logs and DNS resolution
         - Document result: does host networking fix DNS?
      4. **Test C: Explicit DNS servers**
         - Revert to custom 'private' network
         - Add to docker-compose.whisper.yml under whisper service:
           ```yaml
           dns:
             - 8.8.8.8
             - 8.8.4.4
           ```
         - Start container and check logs
         - Document result: do explicit DNS servers fix issue?
      5. **Test D: Add NET_ADMIN capability**
         - Add to docker-compose.whisper.yml:
           ```yaml
           cap_add:
             - NET_ADMIN
           ```
         - Start container and check logs
         - Document result: does additional capability fix DNS?

    - **Root Cause Analyst**: Determine why specter-whisper differs from working containers
      1. Investigate upstream image: research onerahmet/openai-whisper-asr-webservice for known DNS issues
      2. Check image base: `docker inspect onerahmet/openai-whisper-asr-webservice:latest | grep -i "FROM\|base"`
      3. Compare image entrypoints: does whisper use different network libraries or DNS resolution methods?
      4. Review Python DNS resolution: upstream image uses Python requests library, which relies on system DNS
      5. Check for hardcoded DNS or proxy settings in image: `docker exec specter-whisper env | grep -i dns`
      6. Document hypothesis: Is this a Python DNS caching issue? Image-specific network config? Missing dependency?
      7. Identify the winning fix from Test A/B/C/D and explain WHY it worked

    - **Solution Architect**: Implement stable fix
      1. Based on test results, choose most appropriate fix:
         - If explicit DNS works: add `dns: [8.8.8.8, 8.8.4.4]` to docker-compose.whisper.yml
         - If default bridge works: document rationale for switching from custom network (may affect other services)
         - If host network works: evaluate trade-offs (loses network isolation, port conflicts)
         - If capability needed: add `cap_add: [NET_ADMIN]` (or specific required capability)
      2. Update infra/compose/docker-compose.whisper.yml with chosen fix
      3. Add inline comments explaining the fix and why it's needed
      4. Ensure GPU acceleration configuration remains intact
      5. Ensure volume mounts and environment variables unchanged
      6. Test fix end-to-end: clean start, automatic model download, successful transcription

    - **Documentation Writer**: Update STT_DICTATION.md
      1. Add new section: "## Troubleshooting DNS Issues"
      2. Document the problem: "Whisper container fails to download models with DNS resolution errors"
      3. Explain root cause: [based on findings from Root Cause Analyst]
      4. Document the fix applied to docker-compose.whisper.yml
      5. Provide manual workaround if needed: pre-download models, manual DNS config, etc.
      6. Add verification steps: "After applying fix, run `docker logs specter-whisper` and confirm model downloads successfully"
      7. Note any platform-specific considerations (e.g., "Some corporate networks block Docker's default DNS")
      8. Update existing setup instructions if fix changes deployment steps
  </plan>

  <commands>
    - Start full stack: `docker compose -f infra/compose/docker-compose.pgvector.yml -f infra/compose/docker-compose.mongo.yml -f infra/compose/docker-compose.ollama.yml -f infra/compose/docker-compose.rag.yml -f infra/compose/docker-compose.librechat.yml -f infra/compose/docker-compose.whisper.yml up -d`
    - View Whisper logs: `docker logs specter-whisper --tail 100 --follow`
    - Inspect private network: `docker network inspect private`
    - Inspect whisper container: `docker inspect specter-whisper`
    - Compare resolv.conf: `docker exec specter-ollama cat /etc/resolv.conf && echo "---" && docker exec specter-whisper cat /etc/resolv.conf`
    - Exec into whisper: `docker exec -it specter-whisper /bin/bash`
    - Test DNS from inside: `nslookup openaipublic.azureedge.net` and `curl -I https://openaipublic.azureedge.net/`
    - Test working container DNS: `docker exec specter-ollama curl -I https://openaipublic.azureedge.net/`
    - Stop whisper service: `docker compose -f infra/compose/docker-compose.whisper.yml down`
    - Rebuild after fix: `docker compose -f infra/compose/docker-compose.whisper.yml up -d --force-recreate`
    - Verify model download: `docker logs specter-whisper | grep -i "model\|download\|error"`
    - Check Whisper health: `curl http://localhost:9000/health` (if service exposes health endpoint)
  </commands>

  <verification>
    - **Success Criteria**:
      1. ✅ DNS failure reproduced and root cause identified (documented in findings)
      2. ✅ Fix applied to docker-compose.whisper.yml (specific configuration change documented)
      3. ✅ Whisper container starts without DNS errors: `docker logs specter-whisper` shows no "Temporary failure in name resolution"
      4. ✅ Model downloads automatically on first startup: logs show "Downloading model medium.en" or similar
      5. ✅ Model download completes successfully: ~769MB file cached in whisper_models volume
      6. ✅ Whisper service responds to health checks: `curl http://localhost:9000/` returns expected response
      7. ✅ GPU acceleration still works: `docker exec specter-whisper nvidia-smi` shows GPU detected (if applicable)
      8. ✅ Transcription works end-to-end: POST to /v1/audio/transcriptions returns transcribed text
      9. ✅ Fix is reproducible: clean restart (`docker compose down && docker compose up`) works without errors
      10. ✅ Documentation updated: docs/STT_DICTATION.md includes troubleshooting section with fix details

    - **Evidence to Capture**:
      - Terminal output showing DNS error before fix (docker logs with stack trace)
      - Output of `docker network inspect private` showing network configuration
      - Comparison of /etc/resolv.conf between working and broken containers
      - Terminal output showing successful model download after fix
      - Updated docker-compose.whisper.yml with fix applied (git diff)
      - Screenshot or log snippet showing specter-whisper container healthy status
      - Test transcription result proving end-to-end functionality
      - Updated docs/STT_DICTATION.md showing new troubleshooting section (git diff)
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md` with:
      - Summary of DNS issue root cause (e.g., "Custom bridge network missing DNS propagation" or "Upstream image requires explicit DNS servers")
      - Specific fix applied (e.g., "Added dns: [8.8.8.8, 8.8.4.4] to docker-compose.whisper.yml")
      - Files modified: infra/compose/docker-compose.whisper.yml, docs/STT_DICTATION.md
      - Test results: model download time, successful transcription test, GPU verification
      - Alternative solutions tested and why they were rejected (if applicable)
      - Any caveats or edge cases (e.g., "Corporate firewalls may require different DNS servers")
    - Update `agents/tasks.md`: Mark "2025-11-18 — Diagnose Whisper DNS failures" as COMPLETE or move to completed section
    - If any follow-up work needed (e.g., "Test on production hardware"), add to `agents/tasksbacklog.md`
    - Notify user with summary: "Whisper DNS issue resolved. Root cause: [brief explanation]. Fix: [one-liner]. Model downloads automatically now. See docs/STT_DICTATION.md for details."
  </handoff>
</prompt>

---
Completed: 2025-11-18 on branch main (READY FOR QA)
