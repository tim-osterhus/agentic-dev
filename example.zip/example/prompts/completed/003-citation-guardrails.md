<prompt id="003-citation-guardrails" branch="claude/citation-guardrails-003" task="Reinstate citation-enforcing system prompt">
  <objective>
    Restore and strengthen the guardrail system prompt that enforces citation requirements in `/chat` responses, ensuring attorneys never receive uncited legal assertions and see clear "insufficient evidence" warnings when the RAG corpus cannot support an answer. This maintains the core "sources required" principle that distinguishes Specter Legal from generic chat interfaces.
  </objective>

  <context>
    - Current system prompt exists in `apps/api/routers/chat.py:25-38` (SYSTEM_PROMPT) with basic citation language ("Cite sources where claims rely on them using (doc_id=123: name.ext)")
    - Fallback messaging for empty corpus exists at `chat.py:127-139` returning "I don't have enough evidence in the corpus to answer"
    - Historical context from roadmap.md:20 and ragstrategy.md:22,43 emphasizes citation enforcement as a Phase 2 priority
    - Agents strategy (agents/agents.md:11, agents/claude.md:15) specifies "needs research" task list format when no sources meet threshold
    - Current implementation provides citations array in response (chat.py:195-210) but does not enforce their presence in the answer text
    - LLM synthesis happens via Ollama /api/generate with current system prompt (chat.py:150-183)
    - Testing infrastructure exists in tests/test_chat_endpoint.py with citation validation (historylog.md mentions test_chat_endpoint_with_citations and test_chat_endpoint_no_citations)
  </context>

  <requirements>
    - Strengthen SYSTEM_PROMPT in apps/api/routers/chat.py to explicitly require:
      * Every substantive legal claim must cite at least one source using (doc_id=N: filename) format
      * When context is insufficient, respond with "Insufficient evidence. Please ingest:" followed by a bulleted list of recommended document types
      * No uncited prose assertions about law or legal procedures
    - Ensure fallback path (chat.py:125-139) returns structured "insufficient evidence" message matching the prompt requirements
    - Update LLM fallback when model is unreachable (chat.py:186-193) to maintain citation guardrails
    - Document the guardrail behavior in README.md section on RAG workflow and docs/INTEGRATION_LIBRECHAT.md (create if missing)
    - Ensure operators know how to customize the prompt while preserving citation requirements
    - Maintain backward compatibility with LibreChat dual-format messages (query string + OpenAI-style messages array)
    - No WAN dependencies or external API calls
  </requirements>

  <plan>
    1. **Prompt Engineering** (Builder role):
       - Review current SYSTEM_PROMPT structure and identify gaps in citation enforcement language
       - Draft strengthened prompt with explicit citation requirements, format examples, and insufficient-evidence template
       - Test prompt variations against sample queries to ensure it doesn't over-cite or produce verbose responses

    2. **Code Implementation** (Builder role):
       - Update SYSTEM_PROMPT constant in apps/api/routers/chat.py with strengthened citation language
       - Revise fallback message at chat.py:127-139 to match "Insufficient evidence. Please ingest: ..." format with document type suggestions
       - Update LLM-failure fallback (chat.py:186-193) to include citation guidance if snippets are available
       - Add inline comments explaining the guardrail design for future maintainers

    3. **Documentation** (Builder role):
       - Update README.md RAG workflow section (or create "Citation Guardrails" subsection) explaining the citation enforcement policy
       - Create or update docs/INTEGRATION_LIBRECHAT.md with operator instructions for customizing SYSTEM_PROMPT while keeping guardrails intact
       - Add examples of good vs bad responses (cited vs uncited) for reference

    4. **Testing** (QA role):
       - Run existing pytest suite: `pytest tests/test_chat_endpoint.py -v`
       - Verify test_chat_endpoint_no_citations validates the new "Insufficient evidence" message format
       - Verify test_chat_endpoint_with_citations confirms citations appear in synthesized answers
       - Manual smoke test: POST to /chat with a query that has no matching corpus documents, confirm response matches new format
       - Manual smoke test: POST to /chat with a query that matches seeded documents, confirm answer includes (doc_id=N: filename) citations

    5. **Handoff & Logging** (QA role):
       - Log completion in agents/historylog.md with date, prompt number, files changed, test results
       - Mark task in agents/tasks.md as completed with reference to this prompt
       - Note any edge cases discovered during testing in agents/quickfix.md if they require follow-up
  </plan>

  <commands>
    # Unit tests for chat endpoint
    pytest tests/test_chat_endpoint.py -v -k citation

    # Full test suite to catch regressions
    pytest tests/test_chat_endpoint.py -v

    # Manual smoke test: no matching documents
    curl -X POST http://localhost:8765/chat \
      -H "Content-Type: application/json" \
      -d '{"query": "What is the airspeed velocity of an unladen swallow?"}'
    # Expected: {"answer": "Insufficient evidence. Please ingest: ...", "citations": []}

    # Manual smoke test: with matching documents (assumes seeded corpus)
    curl -X POST http://localhost:8765/chat \
      -H "Content-Type: application/json" \
      -d '{"query": "What are the Minnesota estate planning statute requirements?"}'
    # Expected: answer contains citations like (doc_id=123: statute.pdf), citations array non-empty

    # Verify LibreChat integration (requires stack running)
    # 1. Start full stack: docker compose -f infra/compose/docker-compose.pgvector.yml ... up -d
    # 2. Open LibreChat UI, send query with no corpus match → verify "Insufficient evidence" modal/message
    # 3. Send query matching seeded documents → verify citations appear in response
  </commands>

  <verification>
    - [ ] SYSTEM_PROMPT in apps/api/routers/chat.py contains explicit "cite every claim" language
    - [ ] SYSTEM_PROMPT specifies "Insufficient evidence. Please ingest: ..." format for empty corpus scenarios
    - [ ] Fallback path (chat.py:127-139) returns message matching the prompt's insufficient-evidence template
    - [ ] LLM-failure fallback (chat.py:186-193) preserves citation guidance when snippets are available
    - [ ] README.md documents citation guardrail policy with examples
    - [ ] docs/INTEGRATION_LIBRECHAT.md exists and explains how operators can customize prompts safely
    - [ ] pytest tests/test_chat_endpoint.py passes with 100% pass rate on citation tests
    - [ ] Manual curl test with no-match query returns structured "Insufficient evidence" message
    - [ ] Manual curl test with matching query returns answer containing at least one (doc_id=N: filename) citation
    - [ ] LibreChat UI displays citations correctly and shows insufficient-evidence warnings when RAG returns empty
    - [ ] No new WAN dependencies introduced
    - [ ] Git commit message references prompt-003 and summarizes changes
  </verification>

  <handoff>
    - Update agents/historylog.md with entry:
      ```
      ## 2025-11-19 — Prompt 003: Citation-Enforcing System Prompt (Completed)
      - **Files changed:** apps/api/routers/chat.py (SYSTEM_PROMPT + fallback messages), README.md (citation guardrails section), docs/INTEGRATION_LIBRECHAT.md (new operator guide)
      - **Tests:** pytest tests/test_chat_endpoint.py (all citation tests passing), manual curl smoke tests (verified insufficient-evidence format and citation presence)
      - **Outcome:** `/chat` responses now enforce citation requirements; empty corpus scenarios return structured "Insufficient evidence. Please ingest: [doc types]" messages
      - **Edge cases:** None discovered during implementation
      - **Prompt artifact:** agents/prompts/tasks/003-citation-guardrails.md
      ```

    - Mark task complete in agents/tasks.md by removing the card (it should move to completed section or be archived per workflow)

    - If any edge cases arise (e.g., LLM occasionally omits citations despite prompt), document in agents/quickfix.md with:
      * Symptom description
      * Reproduction steps
      * Proposed mitigation (e.g., post-processing validation, stricter prompt language)

    - Notify human operator (via commit message or PR description) that citation guardrails are now active and operators should review the new prompt language before production deployment
  </handoff>
</prompt>
