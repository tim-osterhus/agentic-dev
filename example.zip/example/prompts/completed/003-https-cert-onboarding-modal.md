<prompt id="003-https-cert-onboarding-modal" branch="claude/https-cert-onboarding-003" task="In-app HTTPS certificate onboarding for dictation">
  <objective>
    Create an in-app modal experience that detects when dictation is unavailable due to missing HTTPS certificate trust and guides users through downloading and trusting the local TLS certificate. This eliminates the need for users to leave LibreChat or manually follow external documentation, streamlining the onboarding flow for attorney dictation on LAN devices.
  </objective>

  <context>
    - LibreChat client located at: librechat/LibreChat/client (React/TypeScript SPA)
    - Existing HTTPS/TLS infrastructure: nginx reverse proxy, self-signed certificate at /etc/nginx/certs/specter.crt
    - Comprehensive onboarding documentation exists: docs/HTTPS_LAN_SETUP.md with platform-specific instructions
    - Modern browsers require HTTPS for microphone API (navigator.mediaDevices.getUserMedia) except on localhost
    - Phase 2 roadmap: streamlined UX without external dependencies or technical complexity
    - Target users: attorneys (non-technical, expect consumer-grade UX)
    - Air-gapped deployment: modal must work without WAN access (no external CDN, API calls, or remote resources)
    - Certificate trust workflow requires OS/browser-specific steps (Windows/macOS/Linux/iOS/Android each different)
    - Whisper dictation feature is critical to product value (Phase 2 productization goal)
    - Current gap: users must manually follow 400+ line HTTPS_LAN_SETUP.md doc (high friction, error-prone)
  </context>

  <requirements>
    - Detect insecure context or failed microphone permission attempts when user clicks mic icon
    - Trigger modal automatically when detection occurs (don't require user to find settings)
    - Provide "Download Certificate" button pointing to self-signed cert (must be served by LibreChat/nginx)
    - Serve certificate file via static route (e.g., GET /certs/specter.crt) - verify nginx already serves this or add configuration
    - Display platform/browser-specific installation instructions in tabbed interface (repurpose content from docs/HTTPS_LAN_SETUP.md)
    - Support at minimum: Windows (Chrome/Edge/Firefox), macOS (Safari/Chrome/Firefox), Linux (Chrome/Firefox), iOS (Safari), Android (Chrome)
    - Provide "Verify & Continue" button that re-runs microphone permission check
    - Dismiss modal automatically when browser trusts certificate and mic access granted
    - Show success message upon verification (e.g., "Certificate trusted! Dictation ready.")
    - Persist dismissal state if user closes modal manually (don't re-show until next failed mic attempt)
    - Make modal content maintainable: admins should be able to update instruction text without code changes (consider config file or markdown import)
    - Ensure modal is accessible (keyboard navigation, screen reader support, ARIA labels)
    - Match LibreChat's existing UI/UX patterns (styling, component libraries, design system)
    - Maintain air-gap compliance: no external fetches, no telemetry, no WAN dependencies
  </requirements>

  <plan>
    - **Frontend Architect**: Research LibreChat UI structure and identify integration points
      1. Locate dictation/microphone button component in client/src/components/
      2. Identify modal/dialog component library used by LibreChat (likely shadcn/ui, MUI, or custom)
      3. Review existing permission handling patterns (how LibreChat handles browser APIs)
      4. Determine where to inject detection logic (mic button click handler, useEffect hook, or permission API)
      5. Identify state management approach (React Context, Redux, Zustand, or local useState)
      6. Document component hierarchy and file paths to modify

    - **UX Designer**: Plan modal flow and content structure
      1. Draft modal wireframe: header, body (tabbed sections), footer (action buttons)
      2. Design tab structure for platforms: Windows, macOS, Linux, Mobile (iOS/Android combined or separate)
      3. Extract and condense content from docs/HTTPS_LAN_SETUP.md for each platform
      4. Plan progressive disclosure: show relevant tab based on user's detected OS (navigator.userAgent or navigator.platform)
      5. Design button states: "Download Certificate" (primary), "Verify & Continue" (secondary), "Close" (tertiary)
      6. Plan success/error feedback: success message on verification, error message if still blocked
      7. Define dismissal behavior: manual close (don't show again this session) vs verification success (permanent)

    - **Backend Engineer**: Expose certificate download endpoint
      1. Verify nginx configuration: check if /certs/specter.crt route exists or if /etc/nginx/certs/ is served
      2. If not exposed, add nginx location block to serve specter.crt:
         ```nginx
         location /certs/specter.crt {
             alias /etc/nginx/certs/specter.crt;
             add_header Content-Type application/x-x509-ca-cert;
             add_header Content-Disposition 'attachment; filename="specter.crt"';
         }
         ```
      3. Test endpoint: `curl -O https://specter.local/certs/specter.crt`
      4. Verify correct MIME type (application/x-x509-ca-cert) and Content-Disposition header
      5. Document endpoint in API reference or internal docs

    - **React Developer**: Implement modal component
      1. Create new component: `client/src/components/CertOnboardingModal.tsx` (or similar path matching LibreChat conventions)
      2. Implement tabbed interface for platform-specific instructions (use existing tab component or build minimal version)
      3. Add platform detection logic:
         ```typescript
         const getPlatform = (): Platform => {
           const ua = navigator.userAgent.toLowerCase();
           if (ua.includes('win')) return 'windows';
           if (ua.includes('mac')) return 'macos';
           if (ua.includes('linux')) return 'linux';
           if (ua.includes('iphone') || ua.includes('ipad')) return 'ios';
           if (ua.includes('android')) return 'android';
           return 'windows'; // default fallback
         };
         ```
      4. Implement "Download Certificate" button linking to /certs/specter.crt
      5. Implement "Verify & Continue" button that:
         - Attempts `navigator.mediaDevices.getUserMedia({ audio: true })`
         - On success: show success message, close modal, enable dictation
         - On failure: show error message with troubleshooting hint
      6. Add local state for tab selection, verification status, dismissal flag
      7. Use LibreChat's existing modal/dialog component for consistency
      8. Apply LibreChat's theme/styling (use existing CSS modules, Tailwind classes, or styled-components)

    - **Content Writer**: Adapt HTTPS_LAN_SETUP.md content for modal
      1. Extract platform-specific instructions from docs/HTTPS_LAN_SETUP.md Part 2
      2. Condense to concise step-by-step format (5-7 steps per platform, no more than 100 words per section)
      3. Remove server-side steps (only client device actions)
      4. Simplify technical language for non-technical users (replace "trust store" with "install certificate")
      5. Include menu paths with arrow notation: Settings → Privacy → Certificates
      6. Create instruction text for each platform:
         - Windows (Chrome/Edge): "Settings → Privacy and security → Security → Manage certificates → Authorities → Import"
         - Windows (Firefox): "Preferences → Certificates → View Certificates → Authorities → Import"
         - macOS: "Keychain Access → System → Import → Trust: Always Trust"
         - Linux: Command-line or Firefox (simpler for most users)
         - iOS: "Install Profile → Settings → Certificate Trust Settings → Enable"
         - Android: "Settings → Security → Install a certificate → CA certificate"
      7. Write success message: "✅ Certificate trusted! You can now use dictation."
      8. Write error message: "❌ Certificate not yet trusted. Please follow the instructions above and try again."

    - **Integration Engineer**: Wire modal to dictation flow
      1. Locate microphone button click handler in LibreChat client
      2. Add detection logic before `getUserMedia` call:
         ```typescript
         const checkSecureContext = async (): Promise<boolean> => {
           // Check if context is secure (HTTPS or localhost)
           if (!window.isSecureContext) return false;

           // Check if mic permissions blocked
           try {
             const permStatus = await navigator.permissions.query({ name: 'microphone' as PermissionName });
             return permStatus.state !== 'denied';
           } catch {
             // Fallback: try getUserMedia directly
             try {
               const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
               stream.getTracks().forEach(track => track.stop());
               return true;
             } catch {
               return false;
             }
           }
         };
         ```
      3. On failure, show CertOnboardingModal:
         ```typescript
         const handleMicClick = async () => {
           const isSecure = await checkSecureContext();
           if (!isSecure) {
             setShowCertModal(true);
             return;
           }
           // Proceed with normal dictation flow...
         };
         ```
      4. Pass modal state and handlers via props or context
      5. Ensure modal doesn't block user from accessing rest of app (non-blocking, can be dismissed)

    - **QA Engineer**: Test modal across platforms and browsers
      1. **Setup test environment**: Deploy LibreChat with HTTPS on LAN (follow HTTPS_LAN_SETUP.md Part 1)
      2. **Test on fresh device** (certificate not yet trusted):
         - Windows 10/11: Chrome, Edge, Firefox
         - macOS: Safari, Chrome, Firefox
         - Linux (Ubuntu): Chrome, Firefox
         - iOS 16+: Safari, Chrome
         - Android 12+: Chrome, Firefox
      3. **Test flow**:
         - Navigate to https://specter.local without certificate trusted (expect cert warning, click through)
         - Click microphone icon in LibreChat
         - Verify modal appears automatically
         - Verify correct platform tab is pre-selected
         - Click "Download Certificate" → verify specter.crt downloads
         - Follow platform-specific instructions to import certificate
         - Click "Verify & Continue" → verify modal shows success and closes
         - Click microphone again → verify dictation works (no modal)
      4. **Test edge cases**:
         - Already-trusted certificate (modal should not appear)
         - User closes modal manually (should not re-appear until next page load or explicit retry)
         - Certificate download fails (show fallback instructions or error message)
         - Verification fails after import (show clear error with retry option)
      5. **Accessibility testing**:
         - Keyboard navigation (Tab, Enter, Escape to close)
         - Screen reader compatibility (NVDA on Windows, VoiceOver on macOS/iOS)
         - High contrast mode, font scaling
      6. **Document results**: Create test matrix (platform × browser × outcome)

    - **Documentation Writer**: Update end-user and admin docs
      1. Update docs/HTTPS_LAN_SETUP.md:
         - Add note at top: "✨ LibreChat now includes an in-app onboarding modal. These manual steps are only needed if troubleshooting."
         - Keep existing content for reference and troubleshooting
      2. Create or update user guide (docs/USER_GUIDE.md or similar):
         - Add section: "Enabling Dictation on LAN Devices"
         - Explain: "If using LibreChat from a device other than the server, you'll be guided through a one-time certificate setup."
         - Include screenshot of modal (if applicable)
      3. Document for admins (README.md or docs/ADMIN_GUIDE.md):
         - Explain how to update modal instruction text if cert paths or steps change
         - Document the /certs/specter.crt endpoint and nginx configuration
         - Note: modal content extracted from HTTPS_LAN_SETUP.md (keep that doc updated)
      4. Add entry to agents/historylog.md summarizing implementation
  </plan>

  <commands>
    - Start LibreChat stack with HTTPS: `docker compose -f infra/compose/docker-compose.pgvector.yml -f infra/compose/docker-compose.mongo.yml -f infra/compose/docker-compose.ollama.yml -f infra/compose/docker-compose.rag.yml -f infra/compose/docker-compose.librechat.yml -f infra/compose/docker-compose.whisper.yml -f infra/compose/docker-compose.nginx.yml up -d`
    - Test certificate endpoint: `curl -I https://specter.local/certs/specter.crt` (expect 200 and correct Content-Type)
    - Verify nginx serves certificate: `curl -o test-cert.crt https://specter.local/certs/specter.crt && openssl x509 -in test-cert.crt -noout -subject`
    - Check LibreChat client build: `cd librechat/LibreChat/client && npm run build` (if build required)
    - Run LibreChat dev mode for testing: `cd librechat/LibreChat && npm run frontend` (if applicable)
    - Test microphone permission check: Open browser console, run `navigator.mediaDevices.getUserMedia({ audio: true })` and observe error/success
    - Test modal on fresh device: Use private/incognito window or different device without certificate installed
    - Verify modal accessibility: Use keyboard only (Tab, Enter, Esc) to navigate and interact with modal
  </commands>

  <verification>
    - **Success Criteria**:
      1. ✅ Certificate download endpoint accessible: `GET /certs/specter.crt` returns 200 with correct MIME type
      2. ✅ Modal component created and integrated into LibreChat client
      3. ✅ Modal triggers automatically when microphone blocked due to insecure context or untrusted certificate
      4. ✅ Platform detection works: correct tab pre-selected based on user's OS
      5. ✅ "Download Certificate" button works: downloads specter.crt file
      6. ✅ Platform-specific instructions visible and accurate (condensed from HTTPS_LAN_SETUP.md)
      7. ✅ "Verify & Continue" button re-checks microphone permission
      8. ✅ Success path: After certificate trusted and verification succeeds, modal closes and dictation works
      9. ✅ Error path: If verification fails, modal shows clear error message with retry option
      10. ✅ Modal can be manually dismissed (close button or Escape key)
      11. ✅ Modal does not re-appear after successful verification
      12. ✅ Modal matches LibreChat's UI/UX patterns (consistent styling, component usage)
      13. ✅ Accessibility: keyboard navigation, screen reader support, ARIA labels present
      14. ✅ Tested on at least 3 platforms: Windows (Chrome), macOS (Safari), Linux (Firefox)
      15. ✅ Documentation updated: HTTPS_LAN_SETUP.md, USER_GUIDE.md, historylog.md

    - **Evidence to Capture**:
      - Screenshot of modal on each platform showing correct tab selected
      - Screenshot of "Download Certificate" working (browser download dialog)
      - Screenshot of success message after verification
      - Screenshot of dictation working after modal flow complete
      - Terminal output showing `curl` to /certs/specter.crt endpoint (headers and status)
      - Test matrix: platform × browser × outcome (table in historylog or test report)
      - Git diff showing new CertOnboardingModal component and integration points
      - Updated docs/HTTPS_LAN_SETUP.md with in-app onboarding note
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md` with:
      - Summary: "Implemented in-app HTTPS certificate onboarding modal for dictation feature"
      - Files created: client/src/components/CertOnboardingModal.tsx (or actual path), nginx configuration changes
      - Files modified: Microphone button component, modal state management, docs/HTTPS_LAN_SETUP.md
      - Platform/browser test results: list platforms tested and outcomes
      - Known limitations: e.g., "iOS Safari strict about self-signed certs, modal provides guidance but may require manual troubleshooting"
      - Admin notes: how to update modal instruction text, /certs/specter.crt endpoint details
    - Update `agents/tasks.md`: Mark "2025-11-18 — In-app HTTPS certificate onboarding for dictation" as COMPLETE with checkmark
    - Update `agents/roadmapchecklist.md`: Check off "Implement HTTPS/LAN TLS so browsers grant mic access without flags; provide onboarding steps for new devices"
    - If any issues remain, document in `agents/quickfix.md` with specific remediation steps
    - Notify user: "✅ In-app certificate onboarding modal complete. Users can now enable dictation directly from LibreChat without external documentation. Tested on [list platforms]. See historylog.md for details."
  </handoff>
</prompt>
