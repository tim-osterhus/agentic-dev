<prompt id="003-hyde-lite-retrieval" branch="claude/hyde-lite-implementation-003" task="Add HyDE-lite retrieval augmentation">
  <objective>
    Implement HyDE-lite (Hypothetical Document Embeddings - lightweight) to improve retrieval recall by generating a synthetic draft answer using a small local LLM, embedding that hallucinated response, and combining it with the original query embedding before vector search. This technique helps bridge the vocabulary gap between user questions and stored legal documents, particularly when attorneys ask in natural language but documents use formal legal terminology. The feature must be toggleable for A/B testing and must maintain air-gap compliance.
  </objective>

  <context>
    - Current retrieval flow: user query → embed query → pgvector search → rerank → return citations (rag_api/services/query.py:25-96)
    - Embedding service already supports Ollama provider with nomic-embed-text model (rag_api/services/embedding.py)
    - Config system uses pydantic-settings with .env.rag file (rag_api/config.py)
    - Roadmap Phase 3 specifies: "Benchmark Qwen3-4B HyDE" and Phase 4 includes "Develop the prompt library + HyDE-lite workflow" (agents/roadmap.md:29,34)
    - Air-gap constraint: HyDE model must run locally via containerized Ollama (no external API calls)
    - Performance requirement: HyDE generation should add minimal latency (<500ms) to maintain responsive UX
    - Existing LLM config in place: LLM_PROVIDER=ollama, LLM_MODEL=granite4:tiny-h, LLM_BASE_URL=http://ollama:11434 (rag_api/config.py:22-24)
    - Task card suggests Qwen2.5-0.5B as lightweight option, roadmap mentions Qwen3-4B; granite4:tiny-h already configured as primary small model
    - Tests exist at tests/test_rag_api.py with async fixtures and httpx client patterns
    - Audit logging already in place for queries (rag_api/services/query.py:189-218)
  </context>

  <requirements>
    - **Configuration**: Add HYDE_ENABLED (bool, default False), HYDE_MODEL (str, default "granite4:tiny-h"), HYDE_WEIGHT (float, 0.0-1.0, default 0.5) to rag_api/config.py Settings class
    - **HyDE Service**: Create rag_api/services/hyde.py with HyDEService class that:
      * Calls Ollama chat/completion endpoint (http://ollama:11434/v1/chat/completions) with configured HYDE_MODEL
      * Uses a concise system prompt instructing model to generate a hypothetical answer (1-2 paragraphs) to the user's legal question
      * Implements timeout (3-5 seconds) and error handling to gracefully fall back if generation fails
      * Returns synthetic text or None on failure
    - **Query Service Integration**: Modify rag_api/services/query.py QueryService.query() method to:
      * Check if HYDE_ENABLED before calling HyDE generator
      * Generate synthetic answer text if enabled
      * Embed both original query and synthetic answer (2 separate embeddings)
      * Merge embeddings using weighted average: final_embedding = (1 - HYDE_WEIGHT) * query_embedding + HYDE_WEIGHT * hyde_embedding
      * Use merged embedding for all subsequent vector searches
      * Log HyDE usage in audit table (add hyde_used boolean column via migration)
    - **Logging**: Extend query audit logging to capture hyde_used=true/false and hyde_generation_ms latency
    - **Testing**: Add tests to tests/test_rag_api.py:
      * Mock HyDE generation with deterministic synthetic text
      * Test with HYDE_ENABLED=True and HYDE_ENABLED=False
      * Verify both code paths execute without errors
      * Assert audit logs show correct hyde_used flag
    - **Documentation**: Update docs/INTEGRATION_LIBRECHAT.md or create new docs/HYDE_RETRIEVAL.md explaining:
      * What HyDE-lite is and when to enable it
      * How to toggle HYDE_ENABLED in .env.rag
      * How to choose HYDE_MODEL (granite4:tiny-h for speed, qwen3-4b for quality)
      * How to tune HYDE_WEIGHT (0.5 = equal weighting, 0.3 = favor original query, 0.7 = favor synthetic answer)
      * Performance implications and recommended baselines
    - **Air-gap compliance**: All LLM calls must go to local Ollama container, no external APIs
    - **Error resilience**: If HyDE generation fails (timeout, model unavailable), fall back silently to original query embedding without breaking retrieval
  </requirements>

  <plan>
    - **ML Engineer**: Design HyDE prompt and implement HyDEService
      1. Research HyDE technique and legal domain prompting best practices
      2. Draft system prompt for HyDE generator (instruct model to hallucinate a plausible legal document snippet or answer)
      3. Create rag_api/services/hyde.py with HyDEService class
      4. Implement async generate_hypothetical_answer(query: str) -> Optional[str] method
      5. Use httpx.AsyncClient to call Ollama chat completions endpoint
      6. Add retry logic (1-2 retries) and timeout handling (3-5s)
      7. Log HyDE generation failures at WARNING level without breaking retrieval flow

    - **Backend Engineer**: Integrate HyDE into query pipeline
      1. Add HYDE_ENABLED, HYDE_MODEL, HYDE_WEIGHT to rag_api/config.py Settings
      2. Modify rag_api/services/query.py QueryService.__init__() to instantiate HyDEService if HYDE_ENABLED
      3. Update QueryService.query() method:
         - After line 40 (query_embedding generation), check if HYDE_ENABLED
         - If enabled, call hyde_service.generate_hypothetical_answer(request.query)
         - Embed the synthetic text using embedding_service.embed_query(synthetic_text)
         - Merge embeddings: final_embedding = [(1 - w) * q + w * h for q, h in zip(query_embedding, hyde_embedding)] where w = HYDE_WEIGHT
         - Replace query_embedding with final_embedding for all _search_collection calls
      4. Track hyde_used flag and hyde_latency_ms for audit logging

    - **Database Engineer**: Add HyDE audit columns
      1. Create migration script (e.g., rag_api/migrations/003_add_hyde_audit.sql or Alembic migration)
      2. Add columns to query_audit table: hyde_used BOOLEAN DEFAULT FALSE, hyde_generation_ms INTEGER
      3. Update QueryService._log_query_audit() to insert hyde_used and hyde_generation_ms values
      4. Test migration runs cleanly on fresh database and existing database

    - **QA Engineer**: Test HyDE-lite feature
      1. Add test fixtures in tests/test_rag_api.py or tests/conftest.py with mock HyDE responses
      2. Create test_query_with_hyde_enabled():
         - Set HYDE_ENABLED=True in test config
         - Mock HyDE generation to return deterministic synthetic text
         - Call /query endpoint
         - Assert response succeeds and includes citations
         - Verify audit log shows hyde_used=true
      3. Create test_query_with_hyde_disabled():
         - Set HYDE_ENABLED=False
         - Call /query endpoint
         - Verify behavior unchanged from baseline (no HyDE calls)
      4. Create test_query_hyde_fallback():
         - Mock HyDE service to raise exception or timeout
         - Verify query still succeeds using original embedding
         - Check logs show HyDE failure warning
      5. Run full test suite: pytest tests/test_rag_api.py -v

    - **DevOps Engineer**: Environment configuration
      1. Add HyDE settings to .env.rag template with defaults:
         HYDE_ENABLED=false
         HYDE_MODEL=granite4:tiny-h
         HYDE_WEIGHT=0.5
      2. Document in comments: "Enable HyDE-lite to improve recall by generating hypothetical answers. Adds ~200-500ms latency per query."
      3. Ensure granite4:tiny-h model is pulled in Ollama container (add to model initialization scripts if needed)
      4. Provide example .env.rag snippets for different use cases:
         - Speed-optimized: HYDE_MODEL=granite4:tiny-h, HYDE_WEIGHT=0.3
         - Quality-optimized: HYDE_MODEL=qwen3-4b, HYDE_WEIGHT=0.7
         - Baseline: HYDE_ENABLED=false

    - **Documentation Writer**: Create HyDE-lite guide
      1. Create docs/HYDE_RETRIEVAL.md or add section to docs/INTEGRATION_LIBRECHAT.md
      2. Explain HyDE concept: "Generates a hypothetical legal document snippet that might answer the question, then searches for documents similar to both the question AND the synthetic answer"
      3. Document configuration options with examples
      4. Provide tuning guidance: when to increase/decrease HYDE_WEIGHT based on precision vs recall needs
      5. Include performance benchmarks (once available): baseline vs HyDE-enabled latency, recall improvements
      6. Add troubleshooting section: HyDE timeouts, model not found, unexpected results
      7. Update README.md to mention HyDE-lite as an optional retrieval enhancement feature
  </plan>

  <commands>
    - **Development**:
      ```bash
      # Pull required model if not present
      docker exec specter-ollama ollama pull granite4:tiny-h

      # Restart RAG API after code changes
      docker compose -f infra/compose/docker-compose.rag.yml restart

      # Check RAG API logs for HyDE generation events
      docker logs specter-rag-api | grep -i hyde
      ```

    - **Testing**:
      ```bash
      # Run HyDE-specific tests
      pytest tests/test_rag_api.py::test_query_with_hyde_enabled -v
      pytest tests/test_rag_api.py::test_query_with_hyde_disabled -v
      pytest tests/test_rag_api.py::test_query_hyde_fallback -v

      # Run full RAG API test suite
      pytest tests/test_rag_api.py -v

      # Manual test with HyDE enabled (modify .env.rag first)
      curl -X POST http://localhost:8001/query \
        -H "Content-Type: application/json" \
        -d '{"query": "requirements for a valid will in Minnesota", "top_k": 5, "merge_global": true}'

      # Check audit logs for HyDE usage
      docker exec specter-pg psql -U specter -d specter -c "SELECT query_text, hyde_used, hyde_generation_ms, latency_ms FROM query_audit ORDER BY created_at DESC LIMIT 10;"
      ```

    - **Verification**:
      ```bash
      # Verify HyDE model available
      docker exec specter-ollama ollama list | grep granite4

      # Test Ollama chat endpoint directly
      curl http://localhost:11434/v1/chat/completions \
        -H "Content-Type: application/json" \
        -d '{"model": "granite4:tiny-h", "messages": [{"role": "user", "content": "What are the requirements for a valid will?"}], "max_tokens": 200}'

      # Verify database migration applied
      docker exec specter-pg psql -U specter -d specter -c "\d query_audit"
      ```

  </commands>

  <verification>
    1. **Configuration valid**: Settings class includes HYDE_ENABLED, HYDE_MODEL, HYDE_WEIGHT with correct types and defaults
    2. **HyDE service functional**: HyDEService can generate synthetic text via Ollama and handles timeouts/errors gracefully
    3. **Query integration works**: QueryService.query() generates both embeddings when HYDE_ENABLED=True and merges them with configured weight
    4. **Fallback resilient**: If HyDE generation fails, query succeeds using original embedding (no user-facing errors)
    5. **Audit logging accurate**: query_audit table shows hyde_used=true/false and hyde_generation_ms for each query
    6. **Tests pass**: All new tests (hyde_enabled, hyde_disabled, hyde_fallback) pass with 100% success rate
    7. **Performance acceptable**: HyDE adds <500ms latency on average (measure with real queries)
    8. **Documentation complete**: HYDE_RETRIEVAL.md or equivalent exists with setup, tuning, and troubleshooting guidance
    9. **Air-gap compliance**: All HyDE calls route to local Ollama container (verified via network logs or tcpdump)
    10. **Toggle verified**: Switching HYDE_ENABLED from false→true→false produces expected behavior changes in /query responses and logs
  </verification>

  <handoff>
    - **Update agents/historylog.md**: Add entry titled "[YYYY-MM-DD] Builder • HyDE-lite Retrieval Implementation" summarizing:
      * Files created: rag_api/services/hyde.py, docs/HYDE_RETRIEVAL.md (or section in existing doc), migration script
      * Files modified: rag_api/config.py, rag_api/services/query.py, tests/test_rag_api.py, .env.rag template
      * HyDE prompt design decisions (system prompt text, model choice rationale)
      * Embedding merge strategy (weighted average formula, default HYDE_WEIGHT=0.5)
      * Test results (all tests passing, sample latency measurements)
      * Known limitations (adds latency, requires small LLM available, may hallucinate)
      * Follow-up work: benchmarking HyDE vs baseline on real legal queries, tuning HYDE_WEIGHT based on precision/recall metrics
    - **Update agents/tasks.md**: Mark "2025-11-18 — Add HyDE-lite retrieval augmentation" as COMPLETED with summary:
      * "Implemented HyDE-lite using granite4:tiny-h for synthetic answer generation. Query pipeline now supports toggling HyDE via HYDE_ENABLED flag. Tests confirm both HyDE and fallback paths work. Audit logs track hyde_used flag. Ready for baseline comparison testing."
    - **Move prompt artifact**: After successful implementation and user validation, move this file from agents/prompts/tasks/ to agents/prompts/completed/003-hyde-lite-retrieval.md
    - **User notification**: Inform user that HyDE-lite is implemented and ready for evaluation. Provide instructions for:
      1. Enabling HyDE: Set HYDE_ENABLED=true in .env.rag and restart RAG API
      2. Running comparison queries with/without HyDE to measure recall improvements
      3. Monitoring query_audit table for hyde_used and latency metrics
      4. Adjusting HYDE_WEIGHT if needed (start with 0.5, decrease if precision drops, increase if recall improves)
    - **Optional follow-up tasks** (add to agents/tasksbacklog.md if desired):
      * Benchmark HyDE-lite vs baseline on 50-100 real legal queries and report precision/recall/latency metrics
      * Experiment with alternative HYDE_MODEL options (qwen2.5-0.5b, qwen3-4b) and compare quality vs speed
      * Tune HyDE system prompt for legal domain (e.g., instruct model to use formal legal language in synthetic answers)
      * Implement multi-shot HyDE (generate 2-3 synthetic answers and merge all embeddings) for further recall gains
  </handoff>
</prompt>
