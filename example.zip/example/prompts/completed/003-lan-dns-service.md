<prompt id="003-lan-dns-service" branch="claude/create-prompt-task-01U4BCMxZb8UtAgW9bYPKGai" task="Add dedicated LAN DNS service for specter.local">
  <objective>
    Bundle a lightweight DNS server (CoreDNS or dnsmasq) so every device on the firm's LAN automatically resolves specter.local without manual /etc/hosts editing. This eliminates the manual certificate onboarding barrier described in HTTPS_LAN_SETUP.md, making the air-gapped deployment truly plug-and-play for attorneys accessing LibreChat from laptops, tablets, and phones across the network.
  </objective>

  <context>
    - Current HTTPS/TLS setup (prompt 001) requires clients to manually edit /etc/hosts files on every device
    - HTTPS_LAN_SETUP.md documents manual DNS configuration (Step 1 of Part 2: Client Device Setup)
    - Air-gapped constraint: DNS service must operate entirely within LAN, no external WAN dependencies
    - Infrastructure includes: docker-compose.nginx.yml for reverse proxy, compose_private network (bridge driver)
    - Recent Whisper DNS work (prompt 001 reference) removed internal: true from compose_private network for model downloads
    - Phase 2 roadmap goal: "ensure HTTPS / LAN TLS so browsers grant microphone permissions without flags"
    - Target users: non-technical attorneys who need seamless access from any LAN device
    - Existing compose stack includes: pgvector, mongo, ollama, rag, librechat, whisper, nginx
    - Network architecture: private network (compose_private) for backend services, public network for nginx
    - Task acceptance criteria: After enabling DNS service and pointing test client DNS at its static IP, https://specter.local resolves/loads without editing hosts files
  </context>

  <requirements>
    - Select DNS server implementation: CoreDNS (recommended for container deployments) or dnsmasq
    - Create new compose service file: infra/compose/docker-compose.dns.yml
    - Configure DNS server with static IP on LAN-accessible network:
      * Use macvlan or host networking to obtain routable LAN IP (not internal Docker bridge IP)
      * Provide configurable static IP via .env override (DNS_SERVER_IP with sane default)
      * Document how to choose IP outside DHCP pool to avoid conflicts
      * Default suggestion: 192.168.1.253 (commonly outside typical DHCP range 192.168.1.100-200)
    - DNS zone configuration:
      * Map specter.local → nginx container IP or LAN host IP serving HTTPS endpoint
      * Optional: wildcard *.specter.local → same target
      * Forward all other queries to upstream DNS (8.8.8.8, 1.1.1.1, or router DNS)
    - Health checks and logging:
      * Include Docker health check (query localhost for specter.local resolution)
      * Log DNS queries for debugging (configurable verbosity)
      * Provide troubleshooting hints in compose file comments
    - Documentation updates:
      * docs/STT_DICTATION.md: Update TLS/HTTPS section to mention DNS service option
      * docs/HTTPS_LAN_SETUP.md: Add new section "Option A: Automatic DNS (Recommended)" vs "Option B: Manual hosts file"
      * README.md: Add DNS service to deployment instructions and prerequisites
      * Include step-by-step: enable DNS service, point DHCP clients (or router) at DNS IP, verify resolution
    - Coexistence and teardown:
      * Document how to disable DNS service if another DNS server already serves the network
      * Explain router DHCP configuration: set DNS server to <DNS_SERVER_IP> for automatic client configuration
      * Warn about conflicts if multiple DNS servers respond to same queries (split-horizon DNS considerations)
    - LAN-only enforcement:
      * Ensure DNS service does not respond to external WAN queries
      * Document firewall rules if needed (bind to LAN interface only)
      * No internet-dependent configuration or model downloads required
    - .env variable support:
      * DNS_SERVER_IP: Static IP for DNS server (default: 192.168.1.253 or auto-detect LAN subnet)
      * DNS_UPSTREAM: Upstream DNS servers (default: 8.8.8.8,8.8.4.4 or router IP)
      * DNS_DOMAIN: Domain to serve (default: specter.local)
      * DNS_TARGET_IP: IP address that specter.local resolves to (default: nginx host IP or auto-detect)
  </requirements>

  <plan>
    - **Network Engineer**: Design DNS service networking approach
      1. Evaluate macvlan vs host networking for static IP assignment
         - macvlan: Container gets its own MAC address and IP on parent network (appears as separate device on LAN)
         - host networking: Container shares host network stack (simplest but less isolated)
         - Recommendation: Start with host networking for simplicity, document macvlan upgrade path
      2. Determine LAN subnet and choose default static IP
         - Scan current network: `hostname -I`, `ip addr`, or `ifconfig` to identify LAN interface
         - Choose IP outside typical DHCP range: 192.168.1.253, 192.168.0.253, 10.0.0.253, etc.
         - Document how to override via DNS_SERVER_IP in .env if default conflicts
      3. Design DNS forwarding strategy
         - Primary zone: specter.local → librechat/nginx endpoint
         - Fallback: forward all other queries to upstream DNS (Google DNS, Cloudflare, or router)
         - Ensure no DNS loops (don't forward specter.local queries upstream)

    - **DevOps Engineer**: Implement DNS compose service
      1. Choose DNS server: CoreDNS (recommended) or dnsmasq
         - CoreDNS advantages: Native containerization, YAML config, health check endpoint, CNCF project
         - dnsmasq advantages: Lightweight, simple config, well-known in network admin communities
         - Proceed with CoreDNS unless blockers emerge
      2. Create infra/compose/docker-compose.dns.yml:
         ```yaml
         services:
           coredns:
             image: coredns/coredns:latest
             container_name: specter-dns
             restart: unless-stopped
             network_mode: host  # Or macvlan configuration
             volumes:
               - ../../infra/dns/Corefile:/etc/coredns/Corefile:ro
             command: -conf /etc/coredns/Corefile
             healthcheck:
               test: ["CMD", "dig", "@127.0.0.1", "specter.local", "+short"]
               interval: 30s
               timeout: 5s
               retries: 3
         ```
      3. Create infra/dns/Corefile configuration:
         ```
         specter.local:53 {
             hosts {
                 ${DNS_TARGET_IP} specter.local
                 fallthrough
             }
             log
             errors
         }
         .:53 {
             forward . ${DNS_UPSTREAM}
             log
             errors
         }
         ```
      4. Add environment variable substitution or templating for .env integration
      5. Document deployment in compose file comments:
         - How to set DNS_SERVER_IP if default conflicts
         - How to verify DNS service is running: `docker ps | grep specter-dns`
         - How to test resolution: `dig @<DNS_SERVER_IP> specter.local`

    - **QA Engineer**: Test DNS resolution across devices and scenarios
      1. Start full stack including DNS service:
         ```bash
         docker compose \
           -f infra/compose/docker-compose.pgvector.yml \
           -f infra/compose/docker-compose.mongo.yml \
           -f infra/compose/docker-compose.ollama.yml \
           -f infra/compose/docker-compose.rag.yml \
           -f infra/compose/docker-compose.librechat.yml \
           -f infra/compose/docker-compose.whisper.yml \
           -f infra/compose/docker-compose.nginx.yml \
           -f infra/compose/docker-compose.dns.yml \
           up -d
         ```
      2. Verify DNS service health:
         - Check container status: `docker ps | grep specter-dns`
         - Check logs for errors: `docker logs specter-dns | tail -20`
         - Test from host: `dig @localhost specter.local` (if host networking) or `dig @<DNS_SERVER_IP> specter.local`
      3. Test DNS resolution from LAN client device (laptop, tablet, phone):
         - Configure device DNS settings:
           * Windows: Network adapter settings → IPv4 properties → Preferred DNS server: <DNS_SERVER_IP>
           * macOS: System Preferences → Network → Advanced → DNS → Add <DNS_SERVER_IP>
           * Linux: Edit /etc/resolv.conf: `nameserver <DNS_SERVER_IP>` or use NetworkManager
           * iOS: Wi-Fi settings → Configure DNS → Manual → Add Server: <DNS_SERVER_IP>
           * Android: Wi-Fi settings → Advanced → IP settings: Static → DNS 1: <DNS_SERVER_IP>
         - Test resolution: `nslookup specter.local` or `dig specter.local` (should return correct IP)
         - Test browser access: Navigate to `https://specter.local` (should load without hosts file entry)
         - Test microphone access: Click mic icon, verify browser prompts for permission (not blocked)
      4. Test fallback DNS (non-specter.local queries):
         - From client: `nslookup google.com` (should resolve via upstream DNS)
         - Verify internet access still works (if applicable) or LAN resources resolve correctly
      5. Test DNS service disable/enable:
         - Stop DNS service: `docker compose -f infra/compose/docker-compose.dns.yml down`
         - Verify specter.local no longer resolves from client (unless hosts file fallback exists)
         - Restart DNS service, verify resolution works again
      6. Test conflict scenarios:
         - Document behavior if another DNS server on network also responds
         - Test with multiple DNS servers configured on client (primary vs secondary)
      7. Document results per platform (Windows, macOS, Linux, iOS, Android, Chrome OS if available)

    - **Documentation Writer**: Update guides with DNS service instructions
      1. Create new section in docs/HTTPS_LAN_SETUP.md before "Part 2: Client Device Setup":
         ```markdown
         ## Part 1.5: DNS Service Setup (Optional - Recommended)

         For automatic DNS resolution across all LAN devices without editing hosts files.

         ### Enable DNS Service
         ```bash
         # Check current LAN subnet and choose available IP
         hostname -I  # Example output: 192.168.1.100

         # Create .env file with DNS configuration (if not exists)
         echo "DNS_SERVER_IP=192.168.1.253" >> .env
         echo "DNS_TARGET_IP=192.168.1.100" >> .env  # Your server's LAN IP
         echo "DNS_UPSTREAM=8.8.8.8,8.8.4.4" >> .env

         # Start DNS service
         docker compose -f infra/compose/docker-compose.dns.yml up -d

         # Verify DNS service
         docker logs specter-dns
         dig @192.168.1.253 specter.local  # Should return DNS_TARGET_IP
         ```

         ### Option A: Configure Router DHCP (Recommended - Automatic)
         1. Log in to your router admin panel (usually http://192.168.1.1 or http://192.168.0.1)
         2. Find DHCP settings (may be under LAN, Network, or Advanced)
         3. Set Primary DNS Server to: 192.168.1.253 (your DNS_SERVER_IP)
         4. Set Secondary DNS Server to: 8.8.8.8 (or leave as router default)
         5. Save and reboot router if needed
         6. Renew DHCP lease on client devices:
            - Windows: `ipconfig /release && ipconfig /renew`
            - macOS: System Preferences → Network → Advanced → TCP/IP → Renew DHCP Lease
            - Linux: `sudo dhclient -r && sudo dhclient`
            - Mobile: Disconnect and reconnect to Wi-Fi
         7. Verify DNS configuration: `nslookup specter.local` (should resolve automatically)

         ### Option B: Configure Individual Devices (Manual - Per Device)
         If you cannot modify router settings, configure DNS on each device individually:
         [... existing manual DNS configuration steps ...]

         ### Option C: Manual Hosts File (Legacy - Not Recommended)
         If DNS service is not available or conflicts with existing network DNS:
         [... move existing hosts file instructions here ...]
         ```
      2. Update docs/STT_DICTATION.md TLS/HTTPS section:
         - Add note: "For automatic DNS resolution, see DNS Service Setup in HTTPS_LAN_SETUP.md"
         - Update troubleshooting: "If specter.local doesn't resolve, check DNS service is running or add hosts file entry"
      3. Update README.md Quick Start or Deployment section:
         ```markdown
         ### Optional: Enable LAN DNS Service

         For automatic `specter.local` resolution across all LAN devices:

         ```bash
         # Configure DNS settings in .env
         echo "DNS_SERVER_IP=192.168.1.253" >> .env
         echo "DNS_TARGET_IP=$(hostname -I | awk '{print $1}')" >> .env

         # Start DNS service alongside other services
         docker compose -f infra/compose/docker-compose.dns.yml up -d

         # Configure router DHCP to use DNS_SERVER_IP as primary DNS
         # See docs/HTTPS_LAN_SETUP.md for detailed instructions
         ```
      4. Add troubleshooting section to HTTPS_LAN_SETUP.md:
         - DNS service not responding: Check container logs, verify static IP not conflicting
         - specter.local resolves to wrong IP: Check DNS_TARGET_IP in .env, verify nginx is running
         - Internet stops working after configuring DNS: Check DNS_UPSTREAM is correct, verify forwarding works
         - Mobile devices can't resolve: Ensure DNS_SERVER_IP is reachable from wireless network (not wired-only)
      5. Document how to disable/remove DNS service:
         ```bash
         # Stop DNS service
         docker compose -f infra/compose/docker-compose.dns.yml down

         # Revert router DHCP settings to default DNS servers
         # Clear client DNS cache:
         # - Windows: ipconfig /flushdns
         # - macOS: sudo dscacheutil -flushcache
         # - Linux: sudo systemd-resolve --flush-caches
         ```
  </plan>

  <commands>
    - **Determine LAN configuration:**
      - `hostname -I` — Show all IP addresses assigned to host
      - `ip addr show` — Detailed network interface information (Linux)
      - `ip route | grep default` — Identify default gateway/router IP

    - **Deploy DNS service:**
      - `docker compose -f infra/compose/docker-compose.dns.yml up -d` — Start DNS service
      - `docker ps | grep specter-dns` — Verify DNS container running
      - `docker logs specter-dns` — Check for startup errors or configuration issues

    - **Test DNS resolution:**
      - `dig @localhost specter.local +short` — Test from host (if host networking)
      - `dig @192.168.1.253 specter.local +short` — Test from any device on LAN
      - `nslookup specter.local 192.168.1.253` — Alternative DNS test tool
      - `dig @192.168.1.253 google.com +short` — Verify upstream forwarding works

    - **Test browser access:**
      - Navigate to `https://specter.local` from client device (should load without hosts file)
      - Verify green padlock (HTTPS certificate trusted)
      - Click microphone icon → verify browser prompts for permission

    - **Verify DHCP client DNS configuration:**
      - Windows: `ipconfig /all | findstr "DNS Servers"`
      - macOS: `scutil --dns | grep nameserver`
      - Linux: `cat /etc/resolv.conf` or `resolvectl status`
      - Mobile: Check Wi-Fi settings → Current network → DNS servers

    - **Troubleshooting:**
      - `docker exec specter-dns cat /etc/coredns/Corefile` — View DNS config
      - `docker logs specter-dns -f` — Watch live DNS query logs
      - `tcpdump -i any port 53` — Capture DNS traffic on host (requires root)
      - `sudo iptables -L -n -v | grep 53` — Check firewall rules for DNS port
  </commands>

  <verification>
    - **Success Criteria**:
      1. ✅ DNS service compose file created (infra/compose/docker-compose.dns.yml)
      2. ✅ CoreDNS or dnsmasq configuration file created (infra/dns/Corefile or dnsmasq.conf)
      3. ✅ .env variables documented: DNS_SERVER_IP, DNS_TARGET_IP, DNS_UPSTREAM, DNS_DOMAIN
      4. ✅ Container starts and shows healthy status (docker ps health check passing)
      5. ✅ DNS query from host resolves specter.local to correct IP (`dig @localhost specter.local`)
      6. ✅ DNS query from LAN client resolves specter.local (`dig @<DNS_SERVER_IP> specter.local`)
      7. ✅ Browser on LAN client loads https://specter.local without hosts file entry (green padlock)
      8. ✅ Upstream DNS forwarding works (google.com resolves, internet access maintained)
      9. ✅ Microphone access verified from LAN client (browser prompts for permission, recording works)
      10. ✅ Documentation updated: HTTPS_LAN_SETUP.md, STT_DICTATION.md, README.md
      11. ✅ Troubleshooting guide includes common DNS issues and resolution steps
      12. ✅ Disable/teardown instructions documented
      13. ✅ Tested on at least two device types (e.g., laptop + phone, Windows + macOS)

    - **Evidence to Capture**:
      - Terminal output: `docker ps | grep specter-dns` showing healthy container
      - Terminal output: `dig @<DNS_SERVER_IP> specter.local` showing correct IP resolution
      - Terminal output: `dig @<DNS_SERVER_IP> google.com` showing upstream forwarding works
      - Screenshot: Browser loading https://specter.local with green padlock (no hosts file configured)
      - Screenshot: Client device DNS settings showing DNS_SERVER_IP configured
      - Terminal output: `ipconfig /all` or `scutil --dns` showing client using DNS_SERVER_IP
      - Screenshot: Microphone permission prompt in LibreChat on client device
      - Docker logs: `docker logs specter-dns` showing successful DNS queries
      - File contents: infra/compose/docker-compose.dns.yml
      - File contents: infra/dns/Corefile (or dnsmasq.conf)
      - Documentation diffs: HTTPS_LAN_SETUP.md showing DNS service section added
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md` with:
      - Summary of DNS service implementation (CoreDNS vs dnsmasq, networking approach, static IP configuration)
      - Files created: docker-compose.dns.yml, Corefile/dnsmasq.conf, .env variable documentation
      - Files modified: HTTPS_LAN_SETUP.md, STT_DICTATION.md, README.md
      - Networking details: chosen IP address, subnet, macvlan vs host networking decision
      - Test results: platforms tested (Windows/macOS/Linux/mobile), resolution success, microphone access verified
      - Known limitations:
        * Requires router DHCP configuration for automatic client setup (or manual per-device DNS config)
        * Static IP must be outside DHCP pool to avoid conflicts
        * May conflict with existing network DNS servers if not configured as primary
        * Does not support DNSSEC validation (acceptable for air-gapped LAN deployment)
      - Follow-up items if any:
        * Future enhancement: Automatic IP detection and .env generation script
        * Future enhancement: mDNS/Avahi integration as alternative to static IP DNS server
        * Future enhancement: DHCP server bundled with DNS (dnsmasq supports both) for fully autonomous network
    - Update `agents/tasks.md`: Mark "Add dedicated LAN DNS service for specter.local" as COMPLETE with checkmark
    - If blockers or incomplete items remain, document in `agents/quickfix.md` with specific remediation steps
    - Notify user with summary: "DNS service implemented and tested. Clients configured to use <DNS_SERVER_IP> can now access https://specter.local automatically without hosts file editing. Microphone access verified on [list platforms]. See docs/HTTPS_LAN_SETUP.md Part 1.5 for deployment instructions."
  </handoff>
</prompt>

---

## Prompt Execution Record

**Completion Date:** 2025-11-18
**Branch:** `claude/create-prompt-task-01U4BCMxZb8UtAgW9bYPKGai`
**Builder:** Claude (Sonnet 4.5)
**Status:** IMPLEMENTATION COMPLETE - AWAITING QA

### Implementation Summary

All code and documentation deliverables completed successfully:
- ✅ CoreDNS compose service created (`infra/compose/docker-compose.dns.yml`)
- ✅ DNS zone configuration created (`infra/dns/Corefile`)
- ✅ Documentation updated (HTTPS_LAN_SETUP.md, STT_DICTATION.md, README.md)
- ✅ Host networking approach with comprehensive inline documentation
- ✅ Troubleshooting guides and teardown instructions

### QA Status: PENDING

**Blockers:**
- Docker not available in builder environment
- Full QA requires Docker-enabled host and actual LAN client devices

**Outstanding QA Validation:**
1. Container startup and health check on Docker-enabled host
2. DNS resolution testing from LAN clients (Windows, macOS, Linux, iOS, Android)
3. Router DHCP configuration walkthrough
4. Microphone access verification from LAN clients without hosts file
5. systemd-resolved conflict testing (Ubuntu/Debian)

**Verification Commands:** See `agents/historylog.md` entry "Builder • Implemented LAN DNS Service"

**Files Modified:** 8 files (706 insertions, 3 deletions)

**Commits:**
- `bf83d48` - feat: create prompt artifact for LAN DNS service implementation
- `483d8e4` - feat: implement LAN DNS service for automatic specter.local resolution
