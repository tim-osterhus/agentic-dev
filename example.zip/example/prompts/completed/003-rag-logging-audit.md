<prompt id="003-rag-logging-audit" branch="claude/rag-logging-audit-003" task="Log RAG vs non-RAG /chat responses">
  <objective>
    Instrument the `/chat` endpoint with structured logging that clearly tags each response as RAG-backed or fallback, capturing key metrics (request ID, tenant, document count, latency) to enable auditing of retrieval coverage and future performance benchmarking. This ensures operators can monitor how often the system relies on corpus evidence versus pure LLM responses, supporting quality assurance and troubleshooting workflows.
  </objective>

  <context>
    - Active task card: agents/tasks.md "2025-11-05 — Log RAG vs non-RAG `/chat` responses"
    - Current `/chat` endpoint: rag_api/main.py:214-335
    - Existing logging infrastructure: config.py defines LOG_FORMAT (json/text), LOG_LEVEL (INFO), AUDIT_ENABLED (True)
    - Current logging uses Python's logging module with configurable format (rag_api/main.py:27-32)
    - docs/LOGGING_AUDIT.md already exists and needs updates showing operators how to tail these new logs
    - Phase 2 roadmap priority: "Reinstate system prompts that enforce cite all claims behavior; show a clear warning when RAG corpus is unavailable" (agents/roadmap.md:20-21)
    - Air-gap deployment: All logging must work offline without external dependencies
    - `/chat` endpoint has two code paths:
      1. RAG-backed: Citations found (line 262-280) → LLM synthesis with context
      2. Fallback: No citations (line 263-268) → Returns "insufficient evidence" message
    - Request format supports both legacy (query) and LibreChat (messages array) formats
    - Stack uses Docker containers; logs accessed via `docker logs specter-rag-api`
  </context>

  <requirements>
    - Add structured logging (JSON or key-value format based on settings.LOG_FORMAT) at critical points in /chat endpoint
    - Log fields to capture:
      * request_id: Unique identifier for each request (UUID or timestamp-based)
      * query_text: The user's question (truncated if very long, or hash for privacy)
      * tenant_id: Tenant identifier if present in request (or "global")
      * num_docs_retrieved: Count of citations returned from QueryService
      * rag_used: Boolean flag (true if citations found and used, false if fallback path)
      * retrieval_latency_ms: Time taken for QueryService.query() call
      * llm_latency_ms: Time taken for LLM synthesis call (if applicable)
      * total_latency_ms: End-to-end /chat request duration
      * llm_model: Model name used for synthesis
      * top_score: Highest similarity score from retrieved citations (if any)
    - Preserve existing logging behavior (don't remove current log statements)
    - Respect settings.LOG_FORMAT: emit JSON when "json", key-value pairs when "text"
    - Ensure sensitive data (API keys, full document contents) never appear in logs
    - Update docs/LOGGING_AUDIT.md with:
      * Example log entries showing rag_used=true and rag_used=false cases
      * Commands for tailing logs: `docker logs specter-rag-api`, `docker logs -f specter-rag-api | grep rag_used`
      * Filtering examples: jq queries for JSON logs, grep patterns for text logs
      * Explanation of each logged field and how to interpret metrics
    - Update agents/historylog.md with implementation summary after completion
    - No breaking changes to /chat API contract (response format unchanged)
    - Logging must not significantly impact /chat latency (use non-blocking calls, avoid heavy serialization)
  </requirements>

  <plan>
    1. **Backend Engineer** (rag_api/main.py modifications):
       - Add `import uuid` and `import time` at top of main.py
       - Generate request_id at start of /chat handler (use uuid.uuid4() or request-scoped ID)
       - Capture start timestamp before QueryService.query() call
       - Measure retrieval_latency_ms after QueryService.query() returns
       - Count num_docs_retrieved from result.answers[0].citations length
       - Set rag_used flag based on whether citations exist (line 263 logic)
       - Capture LLM call start/end timestamps to measure llm_latency_ms
       - Calculate total_latency_ms at end of handler
       - Build structured log dict with all required fields
       - Emit log using logger.info() with JSON or key-value format based on settings.LOG_FORMAT
       - Handle both success and error paths (log even when exceptions occur, but in except block)

    2. **Logging Specialist** (structured log formatting):
       - Create helper function `log_chat_request(...)` that accepts all metrics and formats appropriately
       - For JSON format: Use json.dumps() to serialize dict
       - For text format: Build key=value pairs (e.g., "request_id=abc tenant=default rag_used=true")
       - Truncate query_text to 200 chars max to avoid log bloat
       - Handle None/missing values gracefully (e.g., tenant_id defaults to "global", llm_latency_ms=0 if LLM not called)
       - Add structured log at INFO level for successful requests
       - Add structured log at ERROR level for failed requests (include exception type)

    3. **Documentation Writer** (docs/LOGGING_AUDIT.md updates):
       - Add new section "RAG Coverage Audit Logs" after existing content
       - Show example JSON log entry with all fields populated (rag_used=true case)
       - Show example text format log entry (rag_used=false fallback case)
       - Document tailing commands:
         * `docker logs specter-rag-api -f` (follow all logs)
         * `docker logs specter-rag-api | grep rag_used` (filter audit logs)
         * `docker logs specter-rag-api | jq 'select(.rag_used == false)'` (JSON filtering)
       - Document analytics queries:
         * Count RAG vs fallback ratio: `docker logs specter-rag-api | grep rag_used | grep -c true` vs `grep -c false`
         * Average latency: jq aggregation examples for retrieval_latency_ms, llm_latency_ms
       - Explain field meanings: what rag_used=false indicates (no corpus evidence), when to investigate low num_docs_retrieved
       - Add troubleshooting: if rag_used always false → check corpus seeding, embeddings, query service
       - Reference agents/historylog.md for implementation details

    4. **QA Engineer** (verification steps - document in prompt, executor must run):
       - Start stack: `docker compose -f infra/compose/docker-compose.rag.yml up -d`
       - Tail logs: `docker logs specter-rag-api -f`
       - Send test /chat request with known corpus match (should show rag_used=true, num_docs_retrieved > 0)
       - Send test /chat request with nonsense query (should show rag_used=false, num_docs_retrieved=0)
       - Verify JSON format when LOG_FORMAT=json in .env.rag
       - Verify text format when LOG_FORMAT=text in .env.rag
       - Verify all required fields present in log output
       - Verify latency metrics are reasonable (retrieval < 1000ms, LLM < 5000ms for typical queries)
       - Check logs don't leak sensitive data (no API keys, no full document text)
       - Confirm existing /chat functionality unchanged (responses still include citations, answer format same)
  </plan>

  <commands>
    # Test RAG-backed response
    curl -X POST http://localhost:8000/chat \
      -H "Content-Type: application/json" \
      -d '{"query": "What is a will?"}'

    # Test fallback response (nonsense query)
    curl -X POST http://localhost:8000/chat \
      -H "Content-Type: application/json" \
      -d '{"query": "xyzabc123nonsense"}'

    # Tail logs and filter for audit entries
    docker logs specter-rag-api -f | grep rag_used

    # JSON format verification (if LOG_FORMAT=json)
    docker logs specter-rag-api | jq 'select(.rag_used != null)'

    # Count RAG vs fallback ratio
    docker logs specter-rag-api | grep rag_used=true | wc -l
    docker logs specter-rag-api | grep rag_used=false | wc -l

    # Verify latency metrics
    docker logs specter-rag-api | jq 'select(.total_latency_ms > 10000)' # Flag slow requests
  </commands>

  <verification>
    1. ✅ rag_api/main.py contains new structured logging code in /chat handler (line ~214-335)
    2. ✅ Log entries include all required fields: request_id, query_text, tenant_id, num_docs_retrieved, rag_used, retrieval_latency_ms, llm_latency_ms, total_latency_ms, llm_model, top_score
    3. ✅ Logs respect settings.LOG_FORMAT (JSON when "json", key-value when "text")
    4. ✅ `docker logs specter-rag-api` clearly shows rag_used=true for queries with citations
    5. ✅ `docker logs specter-rag-api` clearly shows rag_used=false for queries without citations
    6. ✅ docs/LOGGING_AUDIT.md updated with new section showing example logs and tailing commands
    7. ✅ agents/historylog.md updated with implementation summary
    8. ✅ Test commands above execute successfully and produce expected log output
    9. ✅ /chat API responses unchanged (existing tests still pass, citations still returned)
    10. ✅ No sensitive data (API keys, full documents, PII) visible in logs
    11. ✅ Latency metrics are reasonable (no significant performance regression introduced by logging)
    12. ✅ Both legacy format (query field) and LibreChat format (messages array) produce logs correctly
  </verification>

  <handoff>
    - Update agents/historylog.md with entry:
      * Title: "[YYYY-MM-DD] Backend Engineer • RAG Coverage Audit Logging (READY FOR QA)"
      * Summary: "Instrumented /chat endpoint with structured logging capturing rag_used flag, retrieval/LLM latency metrics, and document counts. Logs respect LOG_FORMAT setting and include request_id for tracing. Updated docs/LOGGING_AUDIT.md with tailing examples and field explanations."
      * Files modified: rag_api/main.py, docs/LOGGING_AUDIT.md
      * Verification: Include output of test commands showing rag_used=true and rag_used=false cases
      * Outstanding: Note if any QA verification blocked (e.g., Docker access) or ready for user testing
    - Mark agents/tasks.md task as completed with summary: "Added structured logs to /chat with rag_used=true/false tags, latency metrics, and doc counts. Documented in LOGGING_AUDIT.md."
    - Move this prompt artifact to agents/prompts/completed/ after QA verification passes
    - Notify user: "RAG logging instrumentation complete. Run `docker logs specter-rag-api | grep rag_used` to see audit trail. Check docs/LOGGING_AUDIT.md for analysis examples."
  </handoff>
</prompt>
