<prompt id="003-seed-smoke-test-baseline" branch="claude/move-smoke-test-task-019QcMJUTxUNfYuPE7s5YQH3" task="Seed baseline documents for smoke tests">
  <objective>
    Establish a deterministic set of baseline documents (global legal corpus + tenant-specific) with pre-generated embeddings that smoke tests can reliably query for predictable citations, enabling automated regression testing of the RAG pipeline without dependence on external data sources or non-deterministic corpus state after fresh stack deployments.
  </objective>

  <context>
    - Current state: `infra/initdb/002_rag_schema.sql` seeds two global_law documents (`mn_statute_524_2-502`, `mn_statute_524_3-203`) but with NULL embeddings, making them invisible to vector similarity queries until backfill runs
    - Tests in `tests/test_rag_api.py` already reference these doc_ids and expect working /query responses with citations (lines 58-86, 212-236)
    - Smoke test checklist (`scripts/SMOKE_TEST_CHECKLIST.md`) currently focuses on LibreChat integration but lacks references to specific document IDs for deterministic verification
    - Phase 2 roadmap goal: "seed baseline documents so regression smoke tests always have references" (agents/roadmap.md:24)
    - Database schema supports both global_law and tenant_<id> tables with 768-dimension vectors (nomic-embed-text embeddings)
    - RAG API /query endpoint requires embeddings to exist for similarity search; NULL embeddings are excluded from results
    - Fresh stack deployment (`docker compose down -v`) wipes all volumes including pgvector data, requiring re-seeding
    - Air-gapped deployment constraint: cannot rely on external embedding services; must use local Ollama (nomic-embed-text model)
    - Existing seed data lacks tenant-specific documents for testing global+tenant merge functionality (test_query_global_and_tenant_merge in test_rag_api.py:113-138)
  </context>

  <requirements>
    - Create or enhance SQL seed script that inserts at least 2 global_law documents and 1 tenant document with known, stable doc_ids
    - Generate embeddings for all seeded documents during initialization (cannot be NULL) using RAG API /embed endpoint or equivalent
    - Ensure seeded doc_ids, titles, and content are referenced in test assertions (tests/test_rag_api.py) for deterministic test outcomes
    - Update SMOKE_TEST_CHECKLIST.md with specific queries that should return the seeded documents (e.g., "requirements for a valid will" → `mn_statute_524_2-502`)
    - Document reset/re-seed procedure for when `docker compose down -v` wipes data (README.md or new SEEDING.md guide)
    - Seed script must be idempotent (safe to run multiple times without duplicating data)
    - Seed must work in air-gapped environment (no external API calls; uses containerized Ollama)
    - Support both global_law collection and at least one tenant collection (e.g., tenant_firm_example already created by schema)
    - Embeddings must use nomic-embed-text (768 dimensions) to match production configuration
    - Provide verification commands that confirm seeded documents are queryable (e.g., `curl` commands or pytest assertions)
  </requirements>

  <plan>
    - **Database Engineer**: Enhance SQL seed script with robust document insertion
      1. Review existing seed data in `infra/initdb/002_rag_schema.sql` (lines 142-160)
      2. Verify the two existing global_law seeds have appropriate content for legal queries (wills, probate)
      3. Add at least one more global_law document for coverage (e.g., trust or estate tax statute)
      4. Insert at least one document into tenant_firm_example collection with known doc_id (e.g., `firm_memo_estate_001`)
      5. Ensure all doc_ids, titles, content, snippets, sources, and tags are deterministic and documented
      6. Keep embeddings as NULL in SQL (will be filled by next step) or use placeholder logic
      7. Add SQL comments documenting which test queries should retrieve which documents

    - **Backend Engineer**: Create embedding generation seed script
      1. Write Python script `scripts/seed_embeddings.py` that:
         - Connects to pgvector database using environment variables (POSTGRES_HOST, POSTGRES_DB, POSTGRES_USER, POSTGRES_PASSWORD)
         - Queries global_law and tenant_* tables for documents with NULL embeddings
         - For each document, calls RAG API /embed endpoint (http://rag-api:8001/embed) with document content
         - Updates embedding column with returned vector
         - Logs progress (e.g., "Embedded doc_id=mn_statute_524_2-502 (768 dims)")
      2. Ensure script is idempotent (only embeds documents with NULL embeddings; safe to re-run)
      3. Add error handling for Ollama/RAG API unavailability (retry logic or clear error message)
      4. Make script executable: `chmod +x scripts/seed_embeddings.py`
      5. Add shebang for Python 3: `#!/usr/bin/env python3`
      6. Document dependencies (psycopg2, httpx, or requests) in script docstring

    - **Integration Engineer**: Wire seed script into stack startup
      1. Option A: Create docker-compose init container that runs seed_embeddings.py after RAG API is healthy
      2. Option B: Add seed_embeddings.py to RAG API startup sequence (run once on first boot)
      3. Option C: Document manual seeding procedure in README/SEEDING.md with clear commands
      4. Recommended approach: Manual procedure initially (Option C), automate later if needed
      5. Ensure seed script waits for Ollama to be ready (ollama:11434/api/tags returns 200)
      6. Verify nomic-embed-text model is pulled before attempting embeddings
      7. Add health check verification before seeding (RAG API /health returns "embeddings_provider": "ollama")

    - **QA Engineer**: Update tests to reference seeded document IDs
      1. Review `tests/test_rag_api.py` test_query_global_only (lines 58-86)
         - Add assertion that verifies at least one citation has doc_id="mn_statute_524_2-502" or "mn_statute_524_3-203"
         - Add comment documenting which seeded document the test expects to find
      2. Review test_deduplication (lines 205-236)
         - Already references `mn_statute_524_2-502`, confirm this is seeded in global_law
      3. Review test_query_global_and_tenant_merge (lines 114-138)
         - Update to query for content that matches the seeded tenant document
         - Assert that citations include both "global_law" and "tenant_firm_example" sources
      4. Add new test: test_seeded_documents_queryable
         - Query: "requirements for a valid will"
         - Assert: citation doc_id includes "mn_statute_524_2-502"
         - Query: "informal probate process"
         - Assert: citation doc_id includes "mn_statute_524_3-203"
         - Query: content matching tenant seed document
         - Assert: citation source is "tenant_firm_example"
      5. Run full test suite with `pytest tests/test_rag_api.py -v` and capture results

    - **Documentation Writer**: Document seeding procedure and smoke test queries
      1. Update `scripts/SMOKE_TEST_CHECKLIST.md`:
         - Add new section "Seeded Document Verification" before "Manual Testing Required"
         - List each seeded document (doc_id, title, expected query that retrieves it)
         - Example: "Query 'will execution requirements' should return mn_statute_524_2-502"
         - Add commands to verify seeded documents exist in database (psql queries)
      2. Create `docs/SEEDING.md` or update `README.md` with "Database Seeding" section:
         - Prerequisites: Stack running with pgvector, Ollama, RAG API
         - Step 1: Ensure Ollama has nomic-embed-text model (`docker exec specter-ollama ollama pull nomic-embed-text`)
         - Step 2: Run seed script (`docker exec specter-rag-api python /app/scripts/seed_embeddings.py`)
         - Step 3: Verify embeddings created (SQL query or /query test)
         - Document reset procedure: `docker compose down -v` → `docker compose up -d` → re-run seeding
         - Provide SQL query to check embedding status: `SELECT doc_id, title, (embedding IS NOT NULL) as has_embedding FROM global_law;`
      3. Add troubleshooting section:
         - "Seed script times out" → Increase Ollama timeout, check Ollama health
         - "/query returns empty results" → Verify embeddings exist (not NULL), check RAG API logs
         - "Embeddings are NULL after seeding" → Check RAG API /embed endpoint responds, verify nomic-embed-text model pulled
      4. Document expected seed data inventory (table format):
         - Collection | doc_id | title | query_keywords
         - global_law | mn_statute_524_2-502 | MN Statute 524.2-502 - Execution of Wills | will, execution, requirements
         - global_law | mn_statute_524_3-203 | MN Statute 524.3-203 - Informal Probate | probate, informal
         - tenant_firm_example | [doc_id TBD] | [title TBD] | [keywords TBD]
  </plan>

  <commands>
    - Check current seed data: `docker exec specter-pgvector psql -U specter -d specter_rag -c "SELECT doc_id, title, (embedding IS NOT NULL) as has_embedding FROM global_law;"`
    - Pull embedding model: `docker exec specter-ollama ollama pull nomic-embed-text`
    - Verify Ollama model: `docker exec specter-ollama ollama list | grep nomic-embed-text`
    - Run seed script (if implemented): `docker exec specter-rag-api python /app/scripts/seed_embeddings.py`
    - Verify embeddings created: `docker exec specter-pgvector psql -U specter -d specter_rag -c "SELECT doc_id, title, pg_column_size(embedding) as embedding_bytes FROM global_law WHERE embedding IS NOT NULL;"`
    - Test RAG API /embed endpoint: `curl -X POST http://localhost:8001/embed -H "Content-Type: application/json" -d '{"text": "test"}' | jq .dimension`
    - Query seeded document: `curl -X POST http://localhost:8001/query -H "Content-Type: application/json" -d '{"query": "requirements for a valid will", "top_k": 3}' | jq '.answers[0].citations[] | {doc_id, title}'`
    - Run pytest suite: `pytest tests/test_rag_api.py -v -k "test_query_global_only or test_seeded"`
    - Full test suite: `pytest tests/test_rag_api.py -v`
  </commands>

  <verification>
    - **Success Criteria**:
      1. ✅ At least 2 global_law documents seeded with stable doc_ids, titles, content in `infra/initdb/002_rag_schema.sql`
      2. ✅ At least 1 tenant document seeded in tenant_firm_example with stable doc_id
      3. ✅ Seed script (`scripts/seed_embeddings.py` or equivalent) generates embeddings for all seeded documents
      4. ✅ SQL query shows all seeded documents have non-NULL embeddings (embedding IS NOT NULL)
      5. ✅ RAG API /query returns seeded documents when queried with relevant keywords (e.g., "will execution" → mn_statute_524_2-502)
      6. ✅ `tests/test_rag_api.py` assertions reference specific seeded doc_ids and pass with 100% success rate
      7. ✅ `scripts/SMOKE_TEST_CHECKLIST.md` documents which queries return which seeded documents
      8. ✅ Documentation (README.md or SEEDING.md) includes reset/re-seed procedure with commands
      9. ✅ Seed script is idempotent (safe to run multiple times without errors or duplicates)
      10. ✅ Fresh stack deployment (`docker compose down -v && docker compose up -d` + seed script) produces queryable documents

    - **Evidence to Capture**:
      - Terminal output showing SQL query results: seeded doc_ids with has_embedding=true
      - Terminal output showing `/query` curl command returning expected doc_ids in citations
      - pytest output showing all tests passing (especially test_query_global_only, test_query_global_and_tenant_merge)
      - Screenshot or paste of updated SMOKE_TEST_CHECKLIST.md showing seeded document queries
      - Copy of seed_embeddings.py script with comments
      - Documentation excerpt showing reset/re-seed procedure
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md` with:
      - Summary of seeding implementation (SQL enhancements, seed script approach, automation level)
      - List of seeded documents (doc_ids, titles, collections)
      - Files created/modified (scripts/seed_embeddings.py, infra/initdb/002_rag_schema.sql, tests/test_rag_api.py, SMOKE_TEST_CHECKLIST.md, documentation)
      - Test results (pytest pass/fail counts, example /query outputs with doc_ids)
      - Reset procedure summary (commands for fresh deployment + re-seeding)
      - Known limitations (e.g., "Seed script requires manual execution after fresh deployment", "Ollama must be healthy before seeding")
      - Follow-up items if any (e.g., "Automate seed_embeddings.py in docker-compose init container", "Add more diverse legal documents for broader test coverage")
    - Update `agents/tasks.md`: Mark "2025-11-05 — Seed baseline documents for smoke tests" as COMPLETE with checkmark
    - If any blockers remain (e.g., Ollama unavailable, embedding generation fails), document them in `agents/quickfix.md` with specific remediation steps
    - Notify user with summary: "Baseline document seeding complete. [N] documents seeded across global_law and tenant collections. Smoke tests now query deterministic doc_ids: [list IDs]. See [documentation location] for reset/re-seed procedure."
  </handoff>
</prompt>
