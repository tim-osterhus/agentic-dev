<prompt id="004-gpu-reranker-infrastructure" branch="claude/move-gpu-reranker-task-013qvaWT8WJwYGxPXjVvF97f" task="Add GPU-aware reranker infrastructure with graceful fallback">
  <objective>
    Prepare the RAG API to run a GPU-accelerated cross-encoder reranker when CUDA is available, falling back gracefully to the current CPU-based MiniLM model on systems without GPU support. This lays the foundation for Phase 3 hardware upgrades (bge-reranker-v2-m3 on GPU) while maintaining backward compatibility with existing CPU-only deployments and ensuring the RAG pipeline never fails due to missing hardware.
  </objective>

  <context>
    - Current implementation: RAG API uses `cross-encoder/ms-marco-MiniLM-L-6-v2` for reranking (rag_api/services/query.py:176), loaded dynamically during `_rerank_results()` calls.
    - Config currently has: `RERANK_ENABLED` (bool), `RERANK_MODEL` (str), `RERANK_TOP_K` (int) in rag_api/config.py:33-35.
    - Roadmap (agents/roadmap.md Phase 3) targets `bge-reranker-v2-m3` on GPU for production, but hardware not yet finalized (24 GB 4090 vs M4 Pro decision pending).
    - Agent workflow: This is a foundational infrastructure task; actual model swap to bge-reranker-v2-m3 will happen in Phase 3 after hardware benchmarking.
    - Air-gap constraint: Model downloads must happen at container build/startup; no runtime downloads from HuggingFace in production.
    - Deployment environment: RAG API runs in Docker (specter-rag-api container), may or may not have nvidia-docker runtime available.
    - Related work: Whisper STT already uses GPU acceleration via docker-compose GPU deployment (infra/compose/docker-compose.whisper.yml:21-29 as reference pattern).
    - Testing constraint: Builder environment may lack Docker or GPU; implementation must be verifiable via code inspection and simulated device detection.
  </context>

  <requirements>
    - **Config/Env Vars:**
      - Add `RERANK_DEVICE` (str, options: "cpu", "gpu", "auto", default: "auto") to rag_api/config.py and rag_api/.env.rag.
      - Keep existing `RERANK_MODEL` (str) but document GPU vs CPU model recommendations in comments.
      - Optionally add `RERANK_MODEL_GPU` (str) for explicit GPU model override (e.g., bge-reranker-v2-m3 path for Phase 3).
    - **Startup Device Detection:**
      - At RAG API startup (rag_api/main.py or module init), detect CUDA availability using PyTorch (`torch.cuda.is_available()`) or sentence-transformers device detection.
      - Log detected device clearly: "Reranker device: cuda:0" or "Reranker device: cpu (CUDA not available)".
      - Respect `RERANK_DEVICE` config: if "cpu" → force CPU, if "gpu" → require CUDA (fail if absent), if "auto" → use CUDA if available, else CPU.
    - **Reranker Abstraction:**
      - Refactor `QueryService._rerank_results()` (rag_api/services/query.py:166-187) to use a preloaded reranker instance instead of loading `CrossEncoder(settings.RERANK_MODEL)` on every call.
      - Create a `RerankService` or `RerankerLoader` module (rag_api/services/reranker.py) that:
        - Loads the appropriate model at startup based on detected device.
        - Caches the model instance for reuse across requests.
        - Provides a `rerank(query: str, documents: List[str]) -> List[float]` method.
      - Ensure model loading happens once at startup, not per-request (performance optimization).
    - **GPU/CPU Model Handling:**
      - For CPU mode: Load `cross-encoder/ms-marco-MiniLM-L-6-v2` (current default, lightweight, works everywhere).
      - For GPU mode: Load heavier model (placeholder: `cross-encoder/ms-marco-MiniLM-L-12-v2` for testing, or `RERANK_MODEL_GPU` if set).
      - Document that Phase 3 will swap GPU model to `bge-reranker-v2-m3` after hardware benchmarking completes.
      - Handle model download failures gracefully: fall back to CPU model if GPU model unavailable.
    - **Docker Compose Integration:**
      - Update infra/compose/docker-compose.rag.yml to support optional GPU deployment (similar to whisper.yml pattern).
      - Add commented-out `deploy.resources.reservations.devices` section for GPU with inline guidance on when to enable.
      - Document in comments: GPU reranker requires nvidia-docker runtime and ~2-4 GB VRAM (estimate for bge-reranker-v2-m3).
    - **Error Handling:**
      - If RERANK_DEVICE=gpu but CUDA unavailable → log ERROR and fall back to CPU (do not crash RAG API).
      - If model loading fails entirely → disable reranking for that session and log WARNING (return original vector search results).
      - Ensure `/query` endpoint never fails due to reranker issues.
    - **Documentation:**
      - Update docs/INTEGRATION_LIBRECHAT.md or create docs/RERANKER_SETUP.md explaining:
        - How to enable GPU reranking (RERANK_DEVICE=gpu, docker-compose GPU deployment).
        - How to verify GPU usage (check logs for "Reranker device: cuda:0", monitor nvidia-smi).
        - How to revert to CPU mode (RERANK_DEVICE=cpu or comment out GPU deployment).
        - Future roadmap note: Phase 3 will introduce bge-reranker-v2-m3 as default GPU model.
      - Update README.md to mention GPU-aware reranking as optional enhancement.
    - **Constraints:**
      - No WAN dependencies: All model downloads must happen at container build/first startup, not runtime.
      - Backward compatibility: Existing CPU-only deployments must work unchanged (auto mode detects CPU, uses MiniLM).
      - No breaking changes: Existing RERANK_ENABLED, RERANK_MODEL, RERANK_TOP_K behavior must remain unchanged.
  </requirements>

  <plan>
    - **Step 1: Backend Engineer — Config & Environment Variables**
      - Add `RERANK_DEVICE` to rag_api/config.py (default: "auto", validate options: cpu/gpu/auto).
      - Add `RERANK_MODEL_GPU` to rag_api/config.py (optional override for GPU model, default: None).
      - Update rag_api/.env.rag with new variables and inline comments explaining options.
      - Add .env.example references if applicable.

    - **Step 2: ML Engineer — Reranker Service Abstraction**
      - Create rag_api/services/reranker.py with `RerankService` class:
        - `__init__(device: str, model_name: str)`: Load CrossEncoder with specified device.
        - `rerank(query: str, docs: List[str], top_k: int) -> List[Tuple[int, float]]`: Predict scores and return sorted indices+scores.
        - Singleton pattern or module-level instance to cache model across requests.
      - Add device detection logic: `torch.cuda.is_available()` or check `CUDA_VISIBLE_DEVICES` env var.
      - Log model loading: "Loading reranker: {model_name} on device: {device}".

    - **Step 3: Backend Engineer — Query Service Integration**
      - Refactor QueryService to use preloaded RerankService instance instead of inline CrossEncoder loading.
      - Update `_rerank_results()` in rag_api/services/query.py to call `reranker_service.rerank(query, docs, top_k)`.
      - Handle graceful fallback if reranker_service is None (skip reranking, log warning).
      - Preserve existing behavior: only rerank if `request.rerank and settings.RERANK_ENABLED`.

    - **Step 4: DevOps Engineer — Docker Compose GPU Configuration**
      - Update infra/compose/docker-compose.rag.yml:
        - Add commented `deploy.resources.reservations.devices` section (copy pattern from whisper.yml).
        - Document GPU memory estimate (~2-4 GB) and nvidia-docker runtime requirement.
        - Add inline comment: "Uncomment for GPU reranking; requires RERANK_DEVICE=gpu or auto".
      - Ensure container can start in both CPU and GPU modes without code changes.

    - **Step 5: DevOps Engineer — Startup Initialization & Logging**
      - Update rag_api/main.py (FastAPI app startup event) to:
        - Detect device based on RERANK_DEVICE config and CUDA availability.
        - Initialize RerankService with detected device and appropriate model.
        - Log startup message: "Reranker initialized: {model} on {device}".
      - Add error handling: if GPU requested but unavailable, log warning and fall back to CPU.

    - **Step 6: Documentation Writer — User/Admin Guides**
      - Create or update docs/RERANKER_SETUP.md:
        - "GPU-Aware Reranking Overview" section.
        - "Enabling GPU Reranking" (env vars + docker-compose changes).
        - "Verification Steps" (check logs, run /query, monitor nvidia-smi).
        - "Reverting to CPU Mode" (toggle RERANK_DEVICE or comment GPU deployment).
        - "Future Roadmap" (Phase 3 bge-reranker-v2-m3 upgrade).
      - Update README.md "Features" or "Retrieval Pipeline" section to mention GPU reranking support.
      - Update docs/INTEGRATION_LIBRECHAT.md if reranker config affects LibreChat integration.

    - **Step 7: QA Engineer — Testing & Validation (Manual/Simulated)**
      - **Static Analysis (No Docker Required):**
        - Verify rag_api/config.py contains RERANK_DEVICE and RERANK_MODEL_GPU variables.
        - Verify rag_api/services/reranker.py implements device detection and model loading.
        - Verify QueryService._rerank_results() uses RerankService instance.
        - Verify docker-compose.rag.yml has commented GPU deployment section.
      - **Simulated Device Detection (Python Script):**
        - Write test script that imports config/reranker module and prints detected device.
        - Run with RERANK_DEVICE=cpu → should print "cpu".
        - Run with RERANK_DEVICE=gpu on CPU-only machine → should print "cpu (fallback)".
        - Run with RERANK_DEVICE=auto → should print "cpu" or "cuda:0" based on environment.
      - **Docker Testing (If Available):**
        - Deploy RAG API container in CPU mode (default).
        - Check logs for "Reranker initialized: cross-encoder/ms-marco-MiniLM-L-6-v2 on cpu".
        - Test /query endpoint with rerank=true → should return results without errors.
        - (If GPU available): Enable GPU deployment, set RERANK_DEVICE=gpu, redeploy.
        - Check logs for "Reranker initialized: {model} on cuda:0".
        - Monitor nvidia-smi during /query call → should show specter-rag-api using GPU memory.
      - **Error Handling Tests:**
        - Set RERANK_DEVICE=gpu on CPU-only host → should fall back to CPU and log warning.
        - Corrupt model path → should disable reranking and log error (not crash API).
  </plan>

  <commands>
    - **Static Validation:**
      ```bash
      # Verify config changes
      grep -n "RERANK_DEVICE\|RERANK_MODEL_GPU" rag_api/config.py
      grep -n "RERANK_DEVICE\|RERANK_MODEL_GPU" rag_api/.env.rag

      # Verify reranker service created
      ls -lh rag_api/services/reranker.py

      # Verify query service refactored
      grep -n "RerankService\|reranker_service" rag_api/services/query.py

      # Verify docker-compose GPU section
      grep -A 10 "deploy:" infra/compose/docker-compose.rag.yml | grep -i gpu
      ```

    - **Simulated Device Detection Test:**
      ```bash
      # Test device detection logic (if Python available)
      cd rag_api
      python3 -c "
      import torch
      import os
      from config import settings

      device = settings.RERANK_DEVICE
      cuda_available = torch.cuda.is_available()

      if device == 'cpu':
          print('Device: cpu (forced)')
      elif device == 'gpu':
          print(f'Device: cuda:0' if cuda_available else 'Device: cpu (fallback - GPU requested but unavailable)')
      elif device == 'auto':
          print(f'Device: cuda:0' if cuda_available else 'Device: cpu (auto-detected)')
      "
      ```

    - **Docker Deployment Tests (Requires Docker):**
      ```bash
      # CPU mode deployment (default)
      docker compose -f infra/compose/docker-compose.rag.yml up -d --build
      docker logs specter-rag-api | grep -i reranker
      # Expected: "Reranker initialized: cross-encoder/ms-marco-MiniLM-L-6-v2 on cpu"

      # Test /query endpoint
      curl -X POST http://localhost:8001/query \
        -H "Content-Type: application/json" \
        -d '{"query": "legal precedent", "top_k": 5, "rerank": true}'
      # Expected: 200 OK with citations

      # GPU mode deployment (if nvidia-docker available)
      # Uncomment GPU deployment in docker-compose.rag.yml
      # Set RERANK_DEVICE=gpu in .env.rag
      docker compose -f infra/compose/docker-compose.rag.yml down
      docker compose -f infra/compose/docker-compose.rag.yml up -d --build
      docker logs specter-rag-api | grep -i reranker
      # Expected: "Reranker initialized: {model} on cuda:0"

      # Monitor GPU usage during query
      nvidia-smi --query-gpu=timestamp,name,utilization.gpu,utilization.memory,memory.used --format=csv -l 1 &
      curl -X POST http://localhost:8001/query -H "Content-Type: application/json" -d '{"query": "test", "top_k": 5, "rerank": true}'
      # Expected: specter-rag-api process using GPU memory during reranking
      ```

    - **Error Handling Validation:**
      ```bash
      # Test GPU fallback on CPU-only host
      # Set RERANK_DEVICE=gpu in .env.rag, deploy on CPU-only host
      docker compose -f infra/compose/docker-compose.rag.yml up -d --build
      docker logs specter-rag-api | grep -i "fallback\|warning\|cuda"
      # Expected: Warning log about GPU unavailable, fallback to CPU

      # Test API still works despite GPU unavailability
      curl -X POST http://localhost:8001/query -H "Content-Type: application/json" -d '{"query": "test", "rerank": true}'
      # Expected: 200 OK (reranking on CPU)
      ```
  </commands>

  <verification>
    - **Config & Code Structure:**
      - ✅ rag_api/config.py contains `RERANK_DEVICE: str = "auto"` with validation.
      - ✅ rag_api/config.py contains `RERANK_MODEL_GPU: Optional[str] = None`.
      - ✅ rag_api/.env.rag has `RERANK_DEVICE=auto` with inline comments explaining cpu/gpu/auto.
      - ✅ rag_api/services/reranker.py exists with RerankService class implementing device detection, model loading, and rerank method.
      - ✅ rag_api/services/query.py refactored to use RerankService instance instead of inline CrossEncoder loading.
      - ✅ rag_api/main.py startup event initializes RerankService and logs device/model.

    - **Docker Configuration:**
      - ✅ infra/compose/docker-compose.rag.yml has commented GPU deployment section with inline guidance.
      - ✅ Comments document GPU memory estimate and nvidia-docker runtime requirement.

    - **Logging & Observability:**
      - ✅ RAG API startup logs clearly show: "Reranker initialized: {model} on {device}".
      - ✅ If GPU requested but unavailable: Warning logged "CUDA not available, falling back to CPU".
      - ✅ If model loading fails: Error logged "Reranker initialization failed, reranking disabled".

    - **Functional Behavior:**
      - ✅ With RERANK_DEVICE=cpu: API uses CPU model, /query with rerank=true works.
      - ✅ With RERANK_DEVICE=auto on CPU-only host: API auto-detects CPU, uses MiniLM.
      - ✅ With RERANK_DEVICE=auto on GPU host: API auto-detects CUDA, uses GPU model.
      - ✅ With RERANK_DEVICE=gpu on CPU-only host: API logs warning and falls back to CPU (does not crash).
      - ⚠️ With RERANK_DEVICE=gpu on GPU host (if available): API uses CUDA, nvidia-smi shows GPU memory usage during /query reranking.

    - **Documentation:**
      - ✅ docs/RERANKER_SETUP.md (or equivalent) created with setup/verification/troubleshooting sections.
      - ✅ README.md updated to mention GPU-aware reranking feature.
      - ✅ Inline code comments explain device detection logic and Phase 3 roadmap.

    - **Backward Compatibility:**
      - ✅ Existing deployments without config changes continue to work (auto mode defaults to CPU on existing hardware).
      - ✅ RERANK_ENABLED=false still skips reranking entirely (no device detection overhead).
      - ✅ No breaking changes to /query API contract or response format.
  </verification>

  <handoff>
    - **Update agents/historylog.md:**
      - Add entry: "[2025-11-{DD}] Builder • GPU-Aware Reranker Infrastructure (READY FOR QA)"
      - Document: Prompt artifact executed, files created/modified, testing approach (static/simulated/Docker), verification status (✅/⚠️/❌).
      - Note any testing blockers (e.g., Docker unavailable, GPU hardware absent).
      - Include evidence: log output showing device detection, /query response samples.

    - **Update agents/tasks.md:**
      - Mark task "2025-11-18 — Add GPU-aware reranker infrastructure" as COMPLETE or READY FOR QA.
      - If blockers remain, document what requires manual user validation.

    - **Move prompt artifact:**
      - If fully validated (all ✅): Move to `agents/prompts/completed/004-gpu-reranker-infrastructure.md`.
      - If partial implementation (⚠️ items): Keep in tasks/ and note outstanding QA in historylog.

    - **Notify user/QA:**
      - Provide clear handoff message:
        - "GPU-aware reranker infrastructure implemented. Config/code ready. Docker testing requires nvidia-docker runtime (blocked in current environment). User must validate GPU mode on target hardware. CPU mode validated via static analysis and simulated device detection."
      - Include copy-paste commands for user to run on Docker-enabled host with/without GPU.
      - Document expected log output for both CPU and GPU scenarios.

    - **Phase 3 follow-up note:**
      - Add to historylog or roadmap: "Phase 3 task: Swap RERANK_MODEL_GPU to bge-reranker-v2-m3 after hardware benchmarking completes. Infrastructure now ready for seamless model swap via config change only."
  </handoff>
</prompt>
