<prompt id="004-hybrid-dns-mdns" branch="claude/hybrid-dns-mdns-004" task="Implement hybrid CoreDNS + mDNS discovery stack">
  <objective>
    Ship a hybrid DNS deployment combining CoreDNS (unicast DNS) and Avahi (multicast DNS-SD) so that `specter.local` resolves automatically on every LAN client without manual DNS configuration, router changes, or hosts file editing. This enables zero-configuration discovery for attorneys accessing LibreChat from macOS, iOS, Android, Linux desktops, and Windows devices, while preserving backward compatibility for headless servers and DHCP-configured environments.
  </objective>

  <context>
    - Prior work: CoreDNS-only LAN DNS service completed in prompt 003, validated and operational
    - CoreDNS provides unicast DNS resolution but requires manual DHCP/client configuration
    - mDNS (Avahi) provides zero-config multicast discovery for .local domains (Bonjour protocol)
    - DNS-SD enables service announcement (_https._tcp) so clients can discover endpoints automatically
    - macOS, iOS, Android natively support mDNS; Linux requires nss-mdns; Windows uses LLMNR (similar)
    - Both services must return identical answers to avoid split-brain conflicts
    - Air-gapped deployment: no WAN dependencies, no external API calls, no model downloads
    - Target users: non-technical attorneys expecting consumer-grade plug-and-play UX
    - Phase 2 roadmap goal: self-served LAN DNS for automatic specter.local resolution
    - Configuration files already prepared in agents/mDNS/: plan.md, avahi-daemon.conf, specter-https.service, docker-compose.hybrid-dns.yml
    - CoreDNS configuration exists in infra/dns/Corefile (maps specter.local to 21.0.0.174)
    - Avahi requires host networking mode (multicast 224.0.0.251 cannot traverse NAT)
    - Current LAN IP: 21.0.0.174 (from .env and historylog)
  </context>

  <requirements>
    - Integrate existing Avahi configuration files from agents/mDNS/ into operational deployment
    - Deploy hybrid stack via docker-compose.hybrid-dns.yml (both CoreDNS and Avahi services)
    - Ensure Avahi service uses host networking mode with NET_ADMIN/NET_RAW capabilities
    - Configure Avahi to advertise specter.local A record matching CoreDNS zone (21.0.0.174)
    - Configure DNS-SD service announcement for _https._tcp pointing to port 443
    - Verify both CoreDNS (unicast) and Avahi (multicast) return identical IP addresses
    - Maintain existing CoreDNS functionality: upstream forwarding, health checks, zone resolution
    - Document verification procedures using dig, dns-sd, avahi-resolve, and nslookup
    - Update onboarding documentation: docs/HTTPS_LAN_SETUP.md, docs/STT_DICTATION.md, README.md
    - Provide router/DHCP configuration guidance for admins choosing unicast-only, multicast-only, or hybrid deployment
    - Include troubleshooting for IPv6, interface selection, port conflicts, simultaneous Avahi instances
    - Ensure teardown/disable instructions for reverting to CoreDNS-only or hosts-file approaches
    - Test matrix covering macOS, Windows, Linux, iOS, Android (manual validation where hardware unavailable)
    - Air-gap compliance: no external dependencies, operates entirely on LAN
  </requirements>

  <plan>
    - **Infrastructure Engineer**: Prepare deployment environment
      1. Verify agents/mDNS/ directory structure and files:
         - agents/mDNS/plan.md (implementation guide)
         - agents/mDNS/avahi-daemon.conf (Avahi daemon configuration)
         - agents/mDNS/specter-https.service (DNS-SD service file for _https._tcp)
         - agents/mDNS/docker-compose.hybrid-dns.yml (compose stack definition)
      2. Review existing CoreDNS deployment: infra/compose/docker-compose.dns.yml, infra/dns/Corefile
      3. Confirm host IP detection: verify 21.0.0.174 is current LAN address (or update accordingly)
      4. Check for existing Avahi daemon on host: `systemctl status avahi-daemon` (Ubuntu/Debian hosts)
         - If active, document conflict resolution: stop host Avahi or adjust container bind mounts
      5. Ensure port 53 (DNS) is not conflicting with systemd-resolved or other services
      6. Verify Docker version supports host networking mode and capabilities (NET_ADMIN, NET_RAW)

    - **Configuration Specialist**: Validate and customize Avahi configuration
      1. Review agents/mDNS/avahi-daemon.conf:
         - Confirm `host-name=specter` matches desired .local hostname
         - Verify `allow-interfaces=` is set correctly (e.g., eth0, ens160, or auto-detect primary LAN interface)
         - Check `use-ipv4=yes` and `use-ipv6=yes` settings match network requirements
         - Validate `publish-aaaa-on-ipv4` and `publish-a-on-ipv6` settings
      2. Review agents/mDNS/specter-https.service:
         - Confirm service type `_https._tcp` is correct
         - Verify port=443 matches nginx HTTPS endpoint
         - Check TXT record metadata (optional: add description or additional context)
      3. If LAN IP has changed from 21.0.0.174, update:
         - agents/mDNS/docker-compose.hybrid-dns.yml environment variables (if any)
         - Corresponding DNS A record (CoreDNS should already be configured via infra/dns/Corefile)
      4. Document any site-specific customizations needed (interface names, IPv6 policy, etc.)

    - **Docker Engineer**: Deploy hybrid DNS stack
      1. Deploy using docker-compose.hybrid-dns.yml:
         ```bash
         docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d
         ```
      2. Verify both containers start successfully:
         ```bash
         docker ps --format '{{.Names}}\t{{.Status}}\t{{.Ports}}' | grep -E 'specter-dns|specter-mdns'
         ```
         Expected: specter-dns (healthy), specter-mdns (running in host network mode)
      3. Check container logs for errors:
         ```bash
         docker logs specter-dns | tail -20
         docker logs specter-mdns | tail -20
         ```
         Expected: CoreDNS loaded plugins, Avahi daemon started, no FATAL/ERROR entries
      4. Inspect Avahi service announcements inside container:
         ```bash
         docker exec specter-mdns avahi-browse -a -t
         ```
         Expected: _https._tcp service listed with specter.local
      5. Document container networking: specter-dns (depends on compose network mode), specter-mdns (host mode)

    - **QA Engineer - Unicast DNS Tests**: Validate CoreDNS resolution
      1. Test specter.local resolution from host:
         ```bash
         dig @127.0.0.1 specter.local +short
         ```
         Expected: Returns 21.0.0.174 (or configured IP)
      2. Test upstream forwarding:
         ```bash
         dig @127.0.0.1 google.com +short
         ```
         Expected: Returns valid Google IPs
      3. Test from LAN client (requires client with DNS set to server IP):
         ```bash
         nslookup specter.local <SERVER_IP>
         ```
         Expected: Returns 21.0.0.174
      4. Verify CoreDNS health check:
         ```bash
         curl -s http://localhost:8080/health
         ```
         Expected: HTTP 200 OK
      5. Document CoreDNS functionality status (PASS/FAIL for each test)

    - **QA Engineer - Multicast DNS Tests**: Validate Avahi resolution
      1. Test mDNS resolution from macOS/Linux host on same LAN:
         ```bash
         # macOS:
         dns-sd -G v4v6 specter.local

         # Linux (requires avahi-utils):
         avahi-resolve -n specter.local
         ```
         Expected: Returns 21.0.0.174 (same as CoreDNS)
      2. Test DNS-SD service discovery:
         ```bash
         # macOS:
         dns-sd -B _https._tcp

         # Linux:
         avahi-browse -a -t -r
         ```
         Expected: Lists specter._https._tcp service with port 443
      3. Test detailed service resolution:
         ```bash
         # macOS:
         dns-sd -L specter _https._tcp
         ```
         Expected: Shows hostname specter.local, port 443, TXT records
      4. Windows test (if available): Open PowerShell, run `Resolve-DnsName specter.local`
         Expected: Returns 21.0.0.174 (Windows LLMNR/mDNS integration)
      5. Document Avahi functionality status (PASS/FAIL for each test)

    - **QA Engineer - Browser/Client Tests**: Validate end-to-end UX
      1. Test matrix (manual validation where hardware available):

         **macOS (native mDNS support):**
         - Open Safari → https://specter.local (expect immediate resolution, valid HTTPS)
         - Chrome/Firefox should also resolve via mDNS

         **Windows 10/11:**
         - Open Chrome/Edge → https://specter.local (Windows may use LLMNR, mDNS, or fallback to unicast)
         - Test with and without explicit DNS configuration

         **Linux Desktop (Ubuntu/Fedora):**
         - Ensure nss-mdns installed: `apt install libnss-mdns` or `dnf install nss-mdns`
         - Firefox → https://specter.local
         - Verify /etc/nsswitch.conf contains `mdns4_minimal` in hosts line

         **iOS/iPadOS:**
         - Safari → https://specter.local (native mDNS, should work immediately)
         - Test microphone access for dictation

         **Android:**
         - Chrome → https://specter.local (Android Chrome supports mDNS since v85+)
         - Verify "Private DNS" set to Automatic in network settings

      2. For each successful client, document:
         - Device type, OS version, browser
         - Resolution method detected (mDNS, LLMNR, unicast DNS)
         - HTTPS certificate trust status (self-signed cert must be installed separately)
         - Microphone access (for dictation validation)

      3. For failed clients, document:
         - Error message (DNS resolution failure, cert warning, etc.)
         - Troubleshooting steps attempted
         - Recommended remediation (manual DNS config, hosts file, nss-mdns installation)

    - **Documentation Writer**: Update end-user and admin guides
      1. Update docs/HTTPS_LAN_SETUP.md:
         - Add new section: "Part 1.5: Hybrid DNS Setup (CoreDNS + mDNS)"
         - Explain three deployment options:
           - **Option A**: Hybrid stack (zero-config for most clients, DHCP for headless)
           - **Option B**: CoreDNS-only (requires router DHCP or manual client config)
           - **Option C**: Manual hosts file (legacy, original approach)
         - Document router DHCP configuration for clients requiring unicast DNS
         - Add troubleshooting section for mDNS-specific issues:
           - IPv6 conflicts, interface selection, nss-mdns installation (Linux)
           - Avahi conflicts with host system daemon
           - Windows LLMNR not resolving (firewall, service disabled)
         - Include verification commands (dig, dns-sd, avahi-resolve)
         - Provide teardown instructions: `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml down`

      2. Update docs/STT_DICTATION.md:
         - Add reference to hybrid DNS in TLS/HTTPS section
         - Update troubleshooting Check 0: "Verify specter.local resolves via DNS or mDNS"
         - Add note: "If using hybrid DNS stack, specter.local should resolve automatically on most devices"

      3. Update README.md:
         - Add "Hybrid DNS Deployment (Optional)" section before First-Time Setup
         - Quick start command:
           ```bash
           docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d
           ```
         - Link to agents/mDNS/plan.md for detailed engineering handoff
         - Link to HTTPS_LAN_SETUP.md Part 1.5 for user-facing instructions

      4. Ensure agents/mDNS/README.md exists and provides quick reference:
         - Purpose: zero-config .local resolution
         - Quick start command
         - Verification commands
         - Link to plan.md for full details

      5. Cross-reference all documentation: ensure no broken links, consistent terminology

    - **System Administrator**: Document deployment guidance
      1. Create router/DHCP configuration guide in HTTPS_LAN_SETUP.md:
         - Recommended approach: Set DHCP option 6 (DNS servers) to server IP for unicast fallback
         - Keep public DNS (8.8.8.8) as secondary to prevent outage if server offline
         - Note: mDNS clients (macOS, iOS, Android) will use multicast by default, DHCP is for headless/Windows
      2. Document three deployment paths for different admin preferences:
         - **No router access**: Use mDNS-only, document client compatibility
         - **Router access available**: Hybrid stack with DHCP option 6 set
         - **Corporate network / no mDNS allowed**: CoreDNS-only with DHCP mandatory
      3. Create support checklist (from agents/mDNS/plan.md section 9):
         - `docker ps` shows both specter-dns and specter-mdns healthy/running
         - `dig @127.0.0.1 specter.local +short` returns expected IP
         - `dns-sd -G v4v6 specter.local` returns same IP (macOS/Linux)
         - `dns-sd -B _https._tcp` lists specter service
         - At least one Windows and one macOS client loads https://specter.local
      4. Document site-specific customization locations:
         - avahi-daemon.conf: `allow-interfaces=`, `use-ipv6`, `host-name`
         - specter-https.service: TXT records, port (if nginx uses non-standard port)
         - docker-compose.hybrid-dns.yml: environment variables (if templated)

    - **Testing Matrix Coordinator**: Create validation report template
      1. Define test matrix structure:
         | Platform | OS Version | Browser | mDNS Test | Unicast Test | HTTPS Loads | Microphone Access | Status |
         |----------|------------|---------|-----------|--------------|-------------|-------------------|--------|
         | macOS    | 14.x       | Safari  | ...       | ...          | ...         | ...               | ...    |
         | Windows  | 11         | Chrome  | ...       | ...          | ...         | ...               | ...    |
         | Linux    | Ubuntu 22  | Firefox | ...       | ...          | ...         | ...               | ...    |
         | iOS      | 17.x       | Safari  | ...       | ...          | ...         | ...               | ...    |
         | Android  | 13         | Chrome  | ...       | ...          | ...         | ...               | ...    |

      2. For each platform, document:
         - Pre-requisites (nss-mdns on Linux, Bonjour Print Services on Windows if needed)
         - Expected behavior (immediate mDNS resolution, DHCP-based unicast, or manual config required)
         - Pass/Fail/Not Tested status

      3. Create fallback testing procedure for environment without LAN clients:
         - Document expected behavior based on protocol specs (RFC 6762, RFC 6763)
         - Reference agents/mDNS/plan.md sections 6.1-6.5 for platform-specific test procedures
         - Mark manual validation items clearly in historylog

      4. Include in handoff: "Full browser/device testing requires LAN clients; QA validated container deployment and localhost resolution"
  </plan>

  <commands>
    - Deploy hybrid DNS stack:
      ```bash
      docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d
      ```

    - Verify containers running:
      ```bash
      docker ps --format '{{.Names}}\t{{.Status}}\t{{.Ports}}' | grep -E 'specter-dns|specter-mdns'
      ```

    - Check logs for errors:
      ```bash
      docker logs specter-dns | tail -20
      docker logs specter-mdns | tail -20
      ```

    - Test CoreDNS (unicast) resolution:
      ```bash
      dig @127.0.0.1 specter.local +short
      dig @127.0.0.1 google.com +short
      ```

    - Test Avahi (multicast) resolution - macOS:
      ```bash
      dns-sd -G v4v6 specter.local
      dns-sd -B _https._tcp
      dns-sd -L specter _https._tcp
      ```

    - Test Avahi (multicast) resolution - Linux:
      ```bash
      avahi-resolve -n specter.local
      avahi-browse -a -t -r
      ```

    - List Avahi services inside container:
      ```bash
      docker exec specter-mdns avahi-browse -a -t
      ```

    - Verify YAML syntax before deployment:
      ```bash
      docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml config
      ```

    - Test from LAN client (requires client with network access):
      ```bash
      # Replace <SERVER_IP> with actual host IP (e.g., 21.0.0.174)
      nslookup specter.local <SERVER_IP>   # Unicast DNS test
      ping specter.local                   # mDNS test (if client supports)
      curl -I https://specter.local        # End-to-end HTTPS test
      ```

    - Teardown hybrid stack:
      ```bash
      docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml down
      ```

    - Check for Avahi conflicts on host:
      ```bash
      systemctl status avahi-daemon   # Ubuntu/Debian hosts
      ```
  </commands>

  <verification>
    - **Success Criteria**:
      1. ✅ docker-compose.hybrid-dns.yml deploys both specter-dns and specter-mdns containers
      2. ✅ specter-dns container reports healthy status (CoreDNS health check passing)
      3. ✅ specter-mdns container running in host network mode with NET_ADMIN/NET_RAW capabilities
      4. ✅ CoreDNS resolves specter.local to 21.0.0.174 (or configured IP): `dig @127.0.0.1 specter.local +short`
      5. ✅ CoreDNS forwards upstream queries successfully: `dig @127.0.0.1 google.com +short`
      6. ✅ Avahi resolves specter.local to same IP as CoreDNS: `dns-sd -G v4v6 specter.local` (macOS) or `avahi-resolve -n specter.local` (Linux)
      7. ✅ Avahi announces _https._tcp service: `dns-sd -B _https._tcp` lists specter service
      8. ✅ DNS-SD service details accessible: `dns-sd -L specter _https._tcp` shows port 443
      9. ✅ No errors in container logs (docker logs specter-dns, docker logs specter-mdns)
      10. ✅ Documentation updated: HTTPS_LAN_SETUP.md Part 1.5, STT_DICTATION.md, README.md
      11. ✅ agents/mDNS/README.md exists with quick start instructions
      12. ✅ Troubleshooting guide covers IPv6, interface selection, nss-mdns, Avahi conflicts
      13. ✅ Teardown instructions documented and tested
      14. ⚠️ Browser test on macOS client: https://specter.local loads (requires actual macOS device)
      15. ⚠️ Browser test on Windows client: https://specter.local loads (requires actual Windows device)
      16. ⚠️ Browser test on iOS/Android: https://specter.local loads (requires actual mobile device)
      17. ⚠️ Microphone access validated from LAN client (requires client device + LibreChat testing)
      18. ⚠️ Router DHCP configuration tested (requires router admin access)

    - **Evidence to Capture**:
      - Terminal output: `docker ps` showing both containers
      - Terminal output: `dig @127.0.0.1 specter.local +short` showing IP
      - Terminal output: `dns-sd -G v4v6 specter.local` showing IP (if macOS/Linux available)
      - Terminal output: `dns-sd -B _https._tcp` showing service announcement
      - Container logs: `docker logs specter-dns` (no errors)
      - Container logs: `docker logs specter-mdns` (Avahi daemon started)
      - Git diff: documentation changes in HTTPS_LAN_SETUP.md, STT_DICTATION.md, README.md
      - Test matrix: platforms tested with PASS/FAIL/NOT_TESTED status
      - Known limitations documented: which tests require manual validation with LAN clients

    - **Acceptable Gaps** (due to environment constraints):
      - Builder environment lacks Docker: container testing performed where possible, syntax validation mandatory
      - No LAN client devices available: document expected behavior per RFC specs and plan.md guidance
      - No router admin access: provide DHCP configuration instructions for future admin
      - Manual testing required: clearly mark items needing validation on Docker-enabled host with LAN clients
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md`:
      - Summary: "Implemented hybrid CoreDNS + mDNS (Avahi) discovery stack for zero-config specter.local resolution"
      - Prompt artifact executed: agents/prompts/tasks/004-hybrid-dns-mdns.md
      - Files created/modified:
        - Deployed: agents/mDNS/docker-compose.hybrid-dns.yml, agents/mDNS/avahi-daemon.conf, agents/mDNS/specter-https.service
        - Documentation: docs/HTTPS_LAN_SETUP.md Part 1.5, docs/STT_DICTATION.md, README.md, agents/mDNS/README.md
      - Networking approach:
        - CoreDNS: Existing service from prompt 003, provides unicast DNS
        - Avahi: New mDNS/DNS-SD service, host networking mode, advertises _https._tcp
        - Both services synchronized to return 21.0.0.174 for specter.local
      - Verification results:
        - ✅ Containers deployed and healthy (or document Docker unavailable)
        - ✅ Unicast DNS resolution validated via dig
        - ⚠️ Multicast DNS resolution validated via dns-sd/avahi-resolve (or mark manual validation required)
        - ⚠️ Browser/client testing (document which platforms tested, which require manual validation)
      - Known limitations:
        - Host networking mode required for Avahi (multicast cannot traverse NAT)
        - Linux clients require nss-mdns package for mDNS resolution
        - Windows LLMNR support varies by network configuration
        - Full cross-platform testing requires actual LAN client devices (not available in builder environment)
      - Outstanding QA validation:
        - Manual browser testing from macOS, Windows, Linux, iOS, Android clients
        - Router DHCP configuration walkthrough (requires physical router access)
        - Long-term stability testing (Avahi daemon restarts, CoreDNS cache behavior)
      - Acceptance criteria status: List each criterion with ✅ (completed), ⚠️ (manual validation required), or ❌ (blocked)

    - Update `agents/tasks.md`:
      - Mark "2025-11-18 — Implement hybrid CoreDNS + mDNS discovery stack" as COMPLETE
      - Add timestamp and link to historylog entry

    - Create `agents/mDNS/README.md` if not exists:
      - Quick reference for hybrid DNS stack
      - Purpose, quick start, verification commands
      - Link to plan.md and HTTPS_LAN_SETUP.md

    - If blockers encountered, document in `agents/quickfix.md`:
      - Specific error messages from container logs
      - Failed verification steps with diagnostic output
      - Remediation plan with concrete commands

    - Notify Builder/QA:
      - "✅ Hybrid DNS stack prompt artifact executed. CoreDNS + Avahi deployed for zero-config specter.local resolution."
      - "⚠️ Full browser/device testing requires LAN clients (macOS, Windows, iOS, Android). See historylog for validation status."
      - "📋 Next steps: QA validation on Docker-enabled host with LAN client devices. Follow agents/mDNS/plan.md sections 6.1-6.5 for platform-specific test procedures."
  </handoff>
</prompt>
