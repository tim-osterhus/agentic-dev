<prompt id="004-librechat-provider-bloat" branch="main" task="2025-11-22 — Fix LibreChat provider bloat & rag-api chat error">
  <objective>
    Restore the LibreChat UI to only show the intended Specter endpoints (specter-ollama + Specter RAG) and make the RAG selection work end-to-end so users see citations in chat responses instead of errors.
  </objective>
  <context>
    - Task card (agents/tasks.md): LibreChat model dropdown now shows extra providers (OpenAI, Assistants, Google, Bing, Plugins, Anthropic). Selecting the new RAG endpoint errors quickly (“Something went wrong…”); direct rag-api /chat and /v1/chat/completions curls return citations.
    - Recent change (Prompt 003): Added OpenAI-compatible proxy /v1/chat/completions in rag_api/main.py and a custom endpoint specter-rag in librechat/librechat.yaml (baseURL http://rag-api:8000/v1, fetch=false, model rag-api). LibreChat rebuilt/recreated; rag-api curls show citations. LibreChat healthcheck reports “starting” because curl is missing in the container.
    - Config mounts: librechat/librechat.yaml mounted read-only; librechat/.env.librechat sets RAG_API_URL=http://rag-api:8000 and disables OpenAI provider (comments). Stack uses docker compose services (specter-rag-api @8001 host, specter-librechat @3080, nginx optional).
    - Goal: Clean up providers to only specter-ollama + RAG, ensure UI → rag-api traffic hits /v1/chat/completions with proper headers/model mapping, and confirm citations visible in UI while rag-api logs show requests.
  </context>
  <requirements>
    - LibreChat config (librechat/librechat.yaml) must expose only specter-ollama and Specter RAG; disable/removal of OpenAI/Anthropic/Google/Bing/Plugins/etc. Ensure any implicit defaults are off (no Assistants/OpenAI providers).
    - RAG endpoint must call rag-api correctly: baseURL to /v1, model mapping to rag-api, fetch=false unless model list supplied manually, and headers/auth consistent with rag_api expectations. Adjust librechat/.env.librechat or rag_api/main.py proxy if schema/headers mismatch.
    - Fix LibreChat healthcheck if needed (curl missing) so container not stuck “starting” after rebuild.
    - Rebuild/recreate LibreChat (and nginx/rag-api if configs change) so running containers pick up new config.
    - Validation: Trigger LibreChat UI query using RAG selection while tailing docker logs specter-rag-api to confirm traffic and citations; compare to direct curls (/chat and /v1/chat/completions). Capture outcomes for historylog.
    - Update agents/historylog.md with commands, changes, results. Stop after builder cycle (no QA cycle).
  </requirements>
  <plan>
    - Planner Architect: Read configs (librechat/librechat.yaml, librechat/.env.librechat, infra/compose files) and current rag_api/main.py proxy to map what LibreChat expects vs. provided schema.
    - Backend/Infra: Adjust librechat/librechat.yaml to disable unwanted providers and ensure only specter-ollama + Specter RAG appear; fix healthcheck dependency (e.g., install curl or swap to wget) if needed; align env vars. Update rag_api/main.py proxy if request shape/headers or model mapping need normalization.
    - DevOps: Rebuild/recreate affected containers (specter-librechat, specter-rag-api if changed, nginx if routing changes) using compose; ensure stack up and health checks green enough to serve UI.
    - Frontend/Integration: From UI, select RAG endpoint and send a query while tailing docker logs specter-rag-api; confirm citations and no errors. Cross-check with direct curl(s).
    - Documentation & Enablement: Append builder summary to agents/historylog.md (commands, changes, validation). Archive prompt per run_prompt rules if fully executed.
  </plan>
  <commands>
    - docker compose -f infra/compose/docker-compose.pgvector.yml -f infra/compose/docker-compose.ollama.yml -f infra/compose/docker-compose.rag.yml -f infra/compose/docker-compose.mongo.yml -f infra/compose/docker-compose.librechat.yml -f infra/compose/docker-compose.nginx.yml up -d --build
    - docker logs -f specter-librechat
    - docker logs -f specter-rag-api
    - curl -s -X POST http://localhost:8001/v1/chat/completions -H "Content-Type: application/json" -d '{"model":"rag-api","messages":[{"role":"user","content":"Test RAG citation query"}]}'
    - (During UI test) Send a LibreChat message using the Specter RAG endpoint while tailing: docker logs -f specter-rag-api
  </commands>
  <verification>
    - LibreChat model/provider dropdown shows only Specter RAG and specter-ollama endpoints (no OpenAI/Anthropic/Google/Bing/Plugins/Assistants).
    - LibreChat RAG chat succeeds: UI shows answer plus citations/sources; no “Something went wrong” error.
    - docker logs specter-rag-api shows requests originating from LibreChat when RAG is selected (POST /v1/chat/completions or equivalent) with RAG_AUDIT entries.
    - Direct curl to /chat and /v1/chat/completions still returns citations.
    - Updated configs are active in running containers (librechat.yaml and env mounted; healthcheck no longer stuck if addressed).
  </verification>
  <handoff>
    - Append builder summary to agents/historylog.md referencing this prompt file (004-librechat-provider-bloat), noting commands run, container rebuilds, config changes, and validation outcomes. If incomplete, document blockers and leave prompt in tasks/.
    - If complete and ready for QA, move this file to agents/prompts/completed/ with a footer noting completion date, branch, and QA status per run_prompt.md; notify QA which prompt ID to load.
  </handoff>
</prompt>
---
Completed: 2025-11-22 • Branch: main • QA: pending
