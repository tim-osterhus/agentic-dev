<prompt id="004-whisper-dns-resolution" branch="feature/whisper-dns-resolution" task="Diagnose Whisper DNS failures in Docker (specter-whisper)">
  <objective>
    Ensure the specter-whisper container reliably resolves external hosts so it can auto-download the configured Whisper model and serve LAN dictation without manual intervention, eliminating DNS-related boot failures that currently block dictation in air-gapped customer deployments.
  </objective>
  <context>
    - `agents/tasks.md` (2025-11-18) describes reproducible DNS failures (`socket.gaierror [Errno -3]`) when specter-whisper downloads Whisper models and demands a fix plus documentation updates.
    - `agents/roadmap.md` stresses Phase 2 productization goals: keep the stack plug-and-play, air-gapped, and well-documented so attorneys can trust the dictation workflow.
    - `agents/historylog.md` entry [2025-11-18] claims explicit DNS servers and documentation were already added for prompt `002-whisper-dns-diagnosis`; verify whether repo state and runtime behavior actually satisfy acceptance (current compose file shows 8.8.8.8/8.8.4.4 but needs validation).
    - Fix must preserve isolation (custom `compose_private` network) and include fallback guidance for fully offline deployments where public DNS is unavailable.
  </context>
  <requirements>
    - Reproduce the DNS failure by running the full stack via `quickstart.ps1` (ensures whisper shares the same custom network as other services) and capture `docker logs specter-whisper` showing the `socket.gaierror`.
    - Inspect Docker networking: `docker network inspect compose_private`, container `/etc/resolv.conf`, and actual outbound DNS queries (e.g., `docker exec specter-whisper nslookup github.com`) to confirm root cause.
    - Implement a durable fix in `infra/compose/docker-compose.whisper.yml` (and any shared compose overlays) that keeps DNS resolution reliable without breaking air-gap expectations; document why the chosen DNS servers or networking mode solves the issue.
    - Update `docs/STT_DICTATION.md` (DNS troubleshooting section) and any admin guides (README, quickstart.ps1 comments, ops runbooks) with exact remediation steps, verification commands, and offline/manual-model-caching instructions.
    - Provide guidance for environments where Google DNS is blocked: alternate DNS (e.g., Cloudflare/corporate) or manual model preloading workflow so deployments without WAN access can still succeed. <todo>Confirm with stakeholders whether outbound DNS to 8.8.8.8/8.8.4.4 is acceptable in production or if alternatives must be default.</todo>
    - Acceptance per task card: specter-whisper starts cleanly, downloads the configured `ASR_MODEL`, emits no DNS errors, and documentation clearly states how to keep it working.
  </requirements>
  <plan>
    - DevOps Investigator: Use `quickstart.ps1` or equivalent compose stacks to reproduce the DNS failure, capture logs, and note timing/conditions (first boot vs. subsequent boots with cached models).
    - Network Engineer: From within the container, inspect `/etc/resolv.conf`, run `nslookup`, `dig`, and `curl` against `openaipublic.azureedge.net`, compare results when attached to different Docker networks or explicit DNS overrides.
    - Solution Architect: Decide on and implement the best remediation (explicit DNS servers, alternate network mode, docker daemon DNS config, or baked-in model cache), update compose files/scripts, and ensure GPU settings remain intact.
    - Documentation Writer & QA: Expand STT dictation docs with the fix, add verification/rollback steps, document manual caching for offline installs, rebuild the stack, and record evidence (logs, screenshots) that the container downloads the model without DNS failures.
  </plan>
  <commands>
    - `pwsh ./quickstart.ps1` (or the documented equivalent) to bring up the full compose stack so whisper shares the target network topology.
    - `docker logs -f specter-whisper | tee logs/specter-whisper.log` to capture DNS errors before/after the fix.
    - `docker exec -it specter-whisper cat /etc/resolv.conf` and `docker exec -it specter-whisper nslookup github.com` to inspect runtime DNS configuration.
    - `docker compose -f infra/compose/docker-compose.whisper.yml down -v && docker compose -f infra/compose/docker-compose.whisper.yml up -d --build whisper` to test the service in isolation and force model redownloads.
    - `docker exec -it specter-whisper ls -lh /root/.cache/whisper` to confirm the model cache populates after the fix.
  </commands>
  <verification>
    - Container boot logs show successful download of `ASR_MODEL=medium.en` with no `socket.gaierror` or DNS-related stack traces.
    - `docker exec specter-whisper nslookup github.com` (and the actual model host) returns valid IPs under the deployed configuration.
    - Manual dictation smoke test (POST to specter-whisper API or use client UI) returns transcriptions, proving the service responds after model download.
    - Documentation updates clearly describe the fix, alternative DNS values, and manual model caching steps so QA can reproduce results offline.
    - Provide captured log snippets or screenshots demonstrating the passing state for history/QA review.
  </verification>
  <handoff>
    - After implementation, append a dated entry to `agents/historylog.md` referencing `agents/prompts/tasks/004-whisper-dns-resolution.md`, summarizing actions, files touched, tests run, and any remaining manual QA steps.
    - If new quick mitigations or regressions surface, update `agents/quickfix.md` accordingly so future agents know what still needs attention.
    - Notify the Builder/QA team (per `agents/prompts/run_prompt.md` process) that prompt `004-whisper-dns-resolution` is ready to execute, and include any `<todo>` clarifications they must resolve before coding.
  </handoff>
</prompt>

---
Completed: 2025-11-18 on branch main (READY FOR QA)
