<prompt id="005-start-time-nameerror-fix" branch="claude/fix-start-time-error-01C66DojFYoZ1Uu72a7zanFN" task="Phase 1 NameError: start_time undefined in rag_api/services/query.py">
  <objective>
    Fix critical production blocker where `/chat` endpoint returns HTTP 500 with `NameError: name 'start_time' is not defined` when querying an empty corpus. This regression prevents validation of citation guardrails and blocks post-merge verification. The fix must initialize timing variables correctly and add regression coverage to prevent recurrence.
  </objective>

  <context>
    - Post-merge verification (agents/verify_post_merge.md Phase 1.3) discovered HTTP 500 error on empty corpus query
    - Error traceback: `rag_api/services/query.py:142` → `latency_ms = int((time.time() - start_time) * 1000)`
    - `NameError: name 'start_time' is not defined` indicates missing initialization
    - Recent latency logging refactor likely moved `start_time = time.time()` into a conditional branch that doesn't execute for zero-result queries
    - Query: `curl -s -X POST http://localhost:8001/chat -H "Content-Type: application/json" -d '{"query": "What is the airspeed velocity of an unladen swallow?"}'`
    - Expected response: HTTP 200 with `"Insufficient evidence. Please ingest:..."` message (citation guardrails implemented in prior task)
    - Actual response: `{"detail":"name 'start_time' is not defined"}`
    - This blocks all downstream QA verification including citation guardrail validation
  </context>

  <requirements>
    - Initialize `start_time = time.time()` at the top of `QueryService.query()` method (around line 43, immediately after method signature)
    - Ensure `start_time` is defined in all code paths before line 142 where `latency_ms` is calculated
    - Verify existing `hyde_start` timing variable (line 50) is independent and correctly scoped for HyDE-specific timing
    - Do not modify HyDE timing logic; only fix the missing overall query timing
    - Add regression test in `tests/test_chat_endpoint.py` (or new test module) that validates empty-corpus behavior:
      * HTTP 200 response (not 500)
      * `answer` field contains `"Insufficient evidence. Please ingest:"` (case-insensitive)
      * `citations` array is empty `[]`
    - Ensure test can run in CI/CD (no Docker dependencies in test itself; uses test fixtures/mocks)
    - Maintain existing latency logging structure (line 142-151) without altering audit log schema
    - Constraint: Do NOT execute tests in this environment (no Docker/Python runtime available)
  </requirements>

  <plan>
    1. **Backend Systems Engineer** - Fix the NameError
       - Read `rag_api/services/query.py` lines 28-75 to understand method signature and initialization block
       - Add `start_time = time.time()` immediately after line 43 (`async def query(self, request: QueryRequest) -> QueryResponse:`)
       - Verify placement is before any conditional branches (HyDE, hybrid search, etc.)
       - Confirm line 142 calculation will now work correctly: `latency_ms = int((time.time() - start_time) * 1000)`
       - Review lines 536-591 to ensure audit logging receives valid `latency_ms` parameter

    2. **QA & Test Engineer** - Add regression coverage
       - Check existing test structure in `tests/test_chat_endpoint.py`
       - Add new test function `test_chat_empty_corpus_no_nameerror()` or similar
       - Test should:
         * Mock/setup scenario with zero documents in corpus (no retrieval results)
         * Call `/chat` endpoint with arbitrary query
         * Assert HTTP 200 status code
         * Assert response JSON contains `"answer"` field
         * Assert `"insufficient evidence"` appears in answer (case-insensitive match)
         * Assert `"citations"` field is empty array
       - Add docstring explaining this is regression coverage for 2025-11-19 NameError bug
       - Do NOT execute pytest in this session (document test commands instead)

    3. **Documentation Specialist** - Update history and QA instructions
       - Append entry to `agents/historylog.md` summarizing:
         * Prompt ID: 005-start-time-nameerror-fix
         * Changes: initialized `start_time` in `rag_api/services/query.py:44`, added regression test in `tests/test_chat_endpoint.py`
         * Status: code changes complete, manual verification pending
         * Reference: `agents/quickfix.md` Phase 1 NameError section
       - Create QA instructions section in historylog entry listing commands to run locally:
         * Rebuild RAG API container: `docker compose -f infra/compose/docker-compose.rag.yml build --no-cache rag-api`
         * Restart stack: `docker compose -f infra/compose/docker-compose.pgvector.yml -f infra/compose/docker-compose.mongo.yml -f infra/compose/docker-compose.ollama.yml -f infra/compose/docker-compose.rag.yml up -d --force-recreate`
         * Test empty corpus query: `curl -s -X POST http://localhost:8001/chat -H "Content-Type: application/json" -d '{"query": "What is the airspeed velocity of an unladen swallow?"}'`
         * Run regression tests: `pytest tests/test_chat_endpoint.py -k empty_corpus -v` or `pytest tests/test_chat_endpoint.py -v`
         * Expected: HTTP 200 with "Insufficient evidence" message, all tests pass
  </plan>

  <commands>
    NOTE: Do NOT execute these commands in the web environment (no Docker/Python runtime).
    Document them for local QA agent execution:

    ```bash
    # Rebuild RAG API container with fix
    docker compose -f infra/compose/docker-compose.rag.yml build --no-cache rag-api

    # Restart full stack
    docker compose -f infra/compose/docker-compose.pgvector.yml \
                   -f infra/compose/docker-compose.mongo.yml \
                   -f infra/compose/docker-compose.ollama.yml \
                   -f infra/compose/docker-compose.rag.yml \
                   up -d --force-recreate

    # Wait for services to stabilize
    sleep 30

    # Test empty corpus query (should return HTTP 200 with guardrail message, NOT 500)
    curl -s -X POST http://localhost:8001/chat \
      -H "Content-Type: application/json" \
      -d '{"query": "What is the airspeed velocity of an unladen swallow?"}'

    # Expected output:
    # {"answer": "Insufficient evidence. Please ingest:\n- Relevant Minnesota statutes...", "citations": []}

    # Run regression tests
    pytest tests/test_chat_endpoint.py -v

    # Or run specific test
    pytest tests/test_chat_endpoint.py -k empty_corpus -v
    ```
  </commands>

  <verification>
    - Code review: `start_time` is initialized at line 44 of `rag_api/services/query.py` (immediately after method signature)
    - Code review: Line 142 latency calculation will not raise NameError
    - Code review: New test function exists in `tests/test_chat_endpoint.py` with appropriate assertions
    - Local QA (manual): curl test returns HTTP 200 (not 500) with "Insufficient evidence" message
    - Local QA (automated): `pytest tests/test_chat_endpoint.py -v` passes all tests including new regression test
    - Docker logs: `docker logs specter-rag-api` shows no NameError traces after fix deployment
    - Success criteria: Empty corpus query no longer crashes; returns expected guardrail response
  </verification>

  <handoff>
    1. Update `agents/historylog.md`:
       - Add entry with prompt ID, summary of changes, files modified, status
       - Include "Manual verification pending" note
       - List QA commands from `<commands>` section

    2. Do NOT modify `agents/quickfix.md`:
       - Quickfix document already describes the issue and verification plan
       - History log entry will reference it as the source of the issue

    3. Commit message format:
       ```
       fix(rag-api): initialize start_time to prevent NameError on empty corpus queries

       - Add start_time = time.time() at top of QueryService.query() method
       - Fixes NameError: name 'start_time' is not defined at query.py:142
       - Add regression test for empty-corpus guardrail path in test_chat_endpoint.py

       Resolves agents/quickfix.md Phase 1 NameError blocking post-merge verification.
       Ref: prompt 005-start-time-nameerror-fix
       ```

    4. Notify local QA agent:
       - Branch `claude/fix-start-time-error-01C66DojFYoZ1Uu72a7zanFN` is ready for pull
       - Run commands from `<commands>` section to validate fix
       - Verify HTTP 200 response with guardrail message (not HTTP 500 NameError)
       - Confirm pytest suite passes including new regression test
  </handoff>
</prompt>
