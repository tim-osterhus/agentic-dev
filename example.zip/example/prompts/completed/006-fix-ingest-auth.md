<prompt id="006-fix-ingest-auth" branch="claude/fix-ingest-auth-006" task="Fix /ingest unauthorized handling">
  <objective>
    Ensure the `/ingest` endpoint returns HTTP 403 (Forbidden) when `ADMIN_API_KEY` header is missing or invalid, preventing the current regression where unauthorized requests return HTTP 500 (RetryError). This fix restores critical security controls that prevent unauthorized document ingestion and protects the integrity of the legal document corpus.
  </objective>

  <context>
    - **Current Bug**: `pytest tests/test_rag_api.py::test_ingest_without_api_key -v` fails because `/ingest` returns HTTP 500 with RetryError instead of HTTP 403 when ADMIN_API_KEY is missing/invalid
    - **Root Cause**: Missing or improperly placed auth validation in the `/ingest` endpoint handler, allowing the request to proceed to the job queue/backfill logic which then fails with an unhandled exception
    - **Security Impact**: P1 regression - unauthorized users can trigger 500 errors and potentially DOS the system; proper 403 response is required for API security
    - **Test Coverage**: Regression test already exists (`test_ingest_without_api_key`) but currently fails; needs to pass after fix
    - **Reference Files**:
      - `/ingest` endpoint implementation: `rag_api/main.py` (likely around lines 100-200, search for `@app.post("/ingest")`)
      - Existing test: `tests/test_rag_api.py::test_ingest_without_api_key`
      - Config: `rag_api/config.py` (ADMIN_API_KEY setting)
      - Quickfix plan: `agents/quickfix.md` section "Ingest Without API Key Regression"
  </context>

  <requirements>
    - **Auth Check Placement**: Validate `ADMIN_API_KEY` at the very start of the `/ingest` endpoint handler (before any business logic)
    - **Header Extraction**: Extract API key from request header (likely `X-Admin-API-Key` or `Authorization`)
    - **Validation Logic**: Compare extracted key against `settings.ADMIN_API_KEY`
    - **Error Response**: Return `HTTPException(status_code=403, detail="Unauthorized: Invalid or missing admin API key")` when validation fails
    - **Clean Failure**: Ensure no downstream calls (job queue, backfill, network requests) occur when auth fails
    - **Test Updates**:
      - Ensure `test_ingest_without_api_key` asserts HTTP 403 response
      - Ensure test validates JSON error message format
      - Consider adding test for invalid (present but wrong) API key
    - **Backward Compatibility**: Valid API keys must continue to work unchanged
    - **Logging**: Log failed auth attempts at WARNING level (no sensitive data in logs)
  </requirements>

  <plan>
    1. **Backend Systems Engineer** — Locate and Fix `/ingest` Endpoint Auth
       - Find `/ingest` endpoint in `rag_api/main.py` (search for `@app.post("/ingest")`)
       - Identify current header extraction logic (if any)
       - Add auth validation at top of handler:
         ```python
         from fastapi import HTTPException, Header
         from typing import Optional

         @app.post("/ingest")
         async def ingest(
             ...,
             x_admin_api_key: Optional[str] = Header(None, alias="X-Admin-API-Key")
         ):
             # Auth check FIRST
             if not x_admin_api_key or x_admin_api_key != settings.ADMIN_API_KEY:
                 logger.warning("Unauthorized ingest attempt")
                 raise HTTPException(
                     status_code=403,
                     detail="Unauthorized: Invalid or missing admin API key"
                 )

             # Existing business logic follows...
         ```
       - Verify no network/queue calls occur before auth check
       - Test locally if Docker available

    2. **QA Test Engineer** — Update Regression Test
       - Open `tests/test_rag_api.py`
       - Find `test_ingest_without_api_key` test function
       - Update assertions to expect HTTP 403 (not 500):
         ```python
         assert response.status_code == 403
         assert "unauthorized" in response.json()["detail"].lower()
         ```
       - Add new test `test_ingest_with_invalid_api_key`:
         ```python
         def test_ingest_with_invalid_api_key():
             response = client.post(
                 "/ingest",
                 headers={"X-Admin-API-Key": "wrong_key"},
                 json={...}
             )
             assert response.status_code == 403
         ```
       - Ensure existing test with valid API key still passes

    3. **Security Reviewer** — Verify Auth Security
       - Confirm no timing attacks (use constant-time comparison if needed)
       - Verify no API key leakage in logs or error responses
       - Check that 403 response doesn't expose whether key exists vs. invalid
       - Ensure rate limiting considerations documented (future enhancement)

    4. **Documentation Writer** — Update Operator Docs (if needed)
       - If `docs/INTEGRATION_LIBRECHAT.md` or similar mentions `/ingest` endpoint, update security notes
       - Add note to README or API docs about required `X-Admin-API-Key` header for `/ingest`
       - Update quickfix.md to mark this item as RESOLVED after verification
  </plan>

  <commands>
    # 1. Identify current /ingest implementation
    grep -n "@app.post(\"/ingest\")" rag_api/main.py

    # 2. Check existing test
    grep -A 20 "def test_ingest_without_api_key" tests/test_rag_api.py

    # 3. After implementing fix, run regression test
    pytest tests/test_rag_api.py::test_ingest_without_api_key -v

    # 4. Run full ingest test suite
    pytest tests/test_rag_api.py -k ingest -v

    # 5. Manual API verification (requires Docker stack running)
    # Test unauthorized request (no header)
    curl -X POST http://localhost:8001/ingest \
      -H "Content-Type: application/json" \
      -d '{"documents": [{"title": "test", "content": "test"}]}'
    # Expected: {"detail":"Unauthorized: Invalid or missing admin API key"}

    # Test authorized request (valid header)
    curl -X POST http://localhost:8001/ingest \
      -H "Content-Type: application/json" \
      -H "X-Admin-API-Key: ${ADMIN_API_KEY}" \
      -d '{"documents": [{"title": "test", "content": "test"}]}'
    # Expected: HTTP 200/202 (job queued)

    # 6. Check logs for auth failures
    docker logs specter-rag-api | grep -i "unauthorized\|403"
  </commands>

  <verification>
    - ✅ **Regression test passes**: `pytest tests/test_rag_api.py::test_ingest_without_api_key -v` exits 0
    - ✅ **HTTP 403 on missing key**: `curl` without header returns `{"detail":"Unauthorized..."}` with status 403
    - ✅ **HTTP 403 on invalid key**: `curl` with wrong header value returns 403
    - ✅ **HTTP 200/202 on valid key**: `curl` with correct header succeeds (job queued or processed)
    - ✅ **No 500 errors**: No RetryError or unhandled exceptions in logs when auth fails
    - ✅ **Full test suite passes**: `pytest tests/test_rag_api.py -v` shows no regressions
    - ✅ **Auth check early**: Code inspection confirms validation happens before any business logic
    - ✅ **No sensitive data leaked**: Logs don't contain API key values, error messages are generic
    - ✅ **Quickfix updated**: `agents/quickfix.md` entry marked RESOLVED with date
  </verification>

  <handoff>
    1. **Update historylog.md** with implementation summary:
       - Note which file(s) modified (rag_api/main.py, tests/test_rag_api.py)
       - Confirm test pass rate (e.g., "2/2 ingest auth tests passing")
       - Reference this prompt: `agents/prompts/tasks/006-fix-ingest-auth.md`

    2. **Update quickfix.md**:
       - Mark "Ingest Without API Key Regression" as ✅ RESOLVED (2025-11-20)
       - Add resolution summary: "Auth check added at endpoint entry, returns 403 when API key missing/invalid"

    3. **Update tasks.md**:
       - Mark task "Fix `/ingest` unauthorized handling" as COMPLETE
       - Or move to historylog if task workflow requires archival

    4. **Notify user** with:
       - Confirmation: "✅ `/ingest` endpoint now returns HTTP 403 for unauthorized requests"
       - Test results: "pytest test_ingest_without_api_key PASSED"
       - Deployment note: "Rebuild RAG API container to activate: `docker compose -f infra/compose/docker-compose.rag.yml build --no-cache rag-api`"
       - Security reminder: "Ensure ADMIN_API_KEY is set to a strong random value in production"
  </handoff>
</prompt>
