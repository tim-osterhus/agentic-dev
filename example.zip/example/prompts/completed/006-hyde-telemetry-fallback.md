<prompt id="006-hyde-telemetry-fallback" branch="claude/hyde-telemetry-implementation-006" task="Implement HyDE telemetry + graceful fallback">
  <objective>
    Complete the HyDE-lite implementation by applying the database audit schema, fixing structured logging to populate the new columns, implementing graceful fallback when Ollama is unavailable, and enabling the HyDE pytest coverage. The HyDE service itself is already implemented (rag_api/services/hyde.py), but the telemetry infrastructure and resilience layer are incomplete, causing production issues where stopping Ollama yields HTTP 500 errors instead of falling back to baseline retrieval.
  </objective>

  <context>
    - HyDE service already exists at rag_api/services/hyde.py with async generation and retry logic (agents/historylog.md:64-89)
    - HyDE is integrated into QueryService.query() at rag_api/services/query.py:47-74 (tracks hyde_used and hyde_generation_ms locally)
    - Migration file exists at infra/initdb/003_add_hyde_audit_columns.sql but has NOT been applied to running database (agents/historylog.md:69, agents/quickfix.md:272)
    - Current audit logging puts hyde metadata inside JSON `filters` field (rag_api/services/query.py:561-566) instead of dedicated columns
    - INSERT statement at rag_api/services/query.py:569-573 does NOT include hyde_used or hyde_generation_ms columns
    - QA verification found: `\d query_audit` shows no hyde columns; HyDE graceful fallback fails with HTTP 500 when Ollama stopped; pytest HyDE tests permanently skipped with `@pytest.mark.skipif(True)` (agents/quickfix.md:269-287)
    - Required columns: `hyde_used BOOLEAN DEFAULT FALSE`, `hyde_generation_ms INTEGER DEFAULT 0` with index on hyde_used (infra/initdb/003_add_hyde_audit_columns.sql:8-20)
    - HyDE tests exist but are skipped: test_query_with_hyde_enabled (line 368), test_hyde_audit_logging (line 416), test_hyde_service_graceful_fallback (line 445) at tests/test_rag_api.py
    - Error pattern when Ollama unavailable: `RetryError[ConnectError]` returned as HTTP 500 instead of falling back (agents/quickfix.md:273-274, agents/historylog.md:81-82)
  </context>

  <requirements>
    - **Database Migration**: Apply infra/initdb/003_add_hyde_audit_columns.sql to specter database
      * Either run migration manually via docker exec, OR
      * Add to database initialization sequence so fresh deployments get it automatically, OR
      * Create Alembic migration if project uses Alembic (check for alembic.ini or migrations/ directory)
    - **Audit Logging Fix**: Update rag_api/services/query.py _log_query_audit() method:
      * Modify INSERT statement to include hyde_used and hyde_generation_ms columns (line 569-573)
      * Remove hyde fields from `filters_with_metadata` JSON blob (lines 561-566) since they now have dedicated columns
      * Ensure query_audit INSERT uses actual column values, not just JSON metadata
    - **Graceful Fallback**: Ensure query pipeline returns HTTP 200 when Ollama unavailable
      * HyDE service already has error handling (rag_api/services/hyde.py:99-116) returning None on failure
      * Verify QueryService.query() handles None response correctly (rag_api/services/query.py:52-73)
      * Add explicit httpx.ConnectError handling if needed to catch Ollama connection failures early
      * Ensure failure logs at WARNING level, not ERROR (already implemented at hyde.py:100-115)
    - **Test Enablement**: Fix pytest HyDE tests in tests/test_rag_api.py
      * Replace `@pytest.mark.skipif(True, ...)` with conditional skip based on env flag or remove skip entirely
      * Option A: `@pytest.mark.skipif(not os.getenv("HYDE_TESTS_ENABLED"), reason="...")`
      * Option B: Remove skip decorator and mock HyDEService so tests can run without Ollama
      * Ensure test_query_with_hyde_enabled (line 368), test_hyde_audit_logging (line 416), and test_hyde_service_graceful_fallback (line 445) can execute
    - **Verification Commands**: Document how to validate each fix (see <commands> section)
  </requirements>

  <plan>
    - **Database Engineer**: Apply HyDE audit migration
      1. Verify migration file contents at infra/initdb/003_add_hyde_audit_columns.sql
      2. Check if query_audit table already has hyde_used/hyde_generation_ms columns: `docker exec specter-pgvector psql -U specter -d specter -c "\d query_audit"`
      3. If columns missing, apply migration:
         - Option A (manual): `docker exec specter-pgvector psql -U specter -d specter -f /docker-entrypoint-initdb.d/003_add_hyde_audit_columns.sql`
         - Option B (docker restart): Ensure migration file is in initdb volume mount and recreate database volume
         - Option C (Alembic): Create alembic revision if project uses Alembic
      4. Verify columns exist after migration: `\d query_audit` should show hyde_used (boolean), hyde_generation_ms (integer), and query_audit_hyde_used_idx index

    - **Backend Engineer**: Fix audit logging to populate HyDE columns
      1. Read current _log_query_audit implementation at rag_api/services/query.py:537-590
      2. Update INSERT statement (line 569-573):
         - Add hyde_used and hyde_generation_ms to column list
         - Add :hyde_used and :hyde_generation_ms to VALUES placeholders
      3. Modify filters_with_metadata building (lines 561-566):
         - Remove hyde_used and hyde_generation_ms from JSON blob (they now go in dedicated columns)
         - Keep only hybrid_enabled in filters metadata (or remove entire hyde block from JSON)
      4. Update execute() parameters to bind hyde_used and hyde_generation_ms values
      5. Test locally: run query with HYDE_ENABLED=true, check query_audit table shows hyde_used=true in column (not just in filters JSON)

    - **Reliability Engineer**: Validate graceful fallback
      1. Review HyDE service error handling at rag_api/services/hyde.py:99-116 (already returns None on ConnectError/TimeoutException/HTTPStatusError)
      2. Trace QueryService.query() flow at rag_api/services/query.py:50-74:
         - Line 52: calls generate_hypothetical_answer (returns None on failure)
         - Line 57: checks `if synthetic_answer:` (should skip embedding if None)
         - Verify code falls through to line 73 (uses original query_embedding) when HyDE fails
      3. Add explicit httpx.ConnectError to caught exceptions if not already covered (check tenacity retry decorator at hyde.py:46-50)
      4. Manual test:
         - Start stack with HYDE_ENABLED=true
         - Stop Ollama: `docker stop specter-ollama`
         - Query RAG API: `curl -X POST http://localhost:8001/query -H 'Content-Type: application/json' -d '{"query": "trust creation", "top_k": 3}'`
         - Expected: HTTP 200 with citations (no 500 error)
         - Expected logs: WARNING message about HyDE failure, not ERROR
      5. If test fails, add more specific exception handling in hyde.py or query.py

    - **QA Engineer**: Enable and fix HyDE tests
      1. Locate skipped tests in tests/test_rag_api.py:
         - test_query_with_hyde_enabled (line 368)
         - test_hyde_audit_logging (line 416)
         - test_hyde_service_graceful_fallback (line 445)
      2. Choose test enablement strategy:
         - If Ollama available in CI: replace `skipif(True)` with `skipif(not HYDE_ENABLED_IN_CI)`
         - If Ollama not guaranteed: mock HyDEService.generate_hypothetical_answer() to return deterministic text
      3. Update test assertions to check new audit columns:
         - Query query_audit table for hyde_used column (not just filters JSON)
         - Assert hyde_generation_ms > 0 when HyDE succeeds
      4. Implement test_hyde_service_graceful_fallback fully (currently placeholder at line 445):
         - Mock httpx.AsyncClient to raise ConnectError
         - Call /query endpoint
         - Assert HTTP 200 response (not 500)
         - Assert hyde_used=false in audit log
      5. Run tests: `pytest tests/test_rag_api.py -k hyde -v`
      6. Update CI instructions in .github/workflows/ci.yml if needed (e.g., add HYDE_TESTS_ENABLED=true env var)

    - **DevOps Engineer**: Environment validation
      1. Verify migration applies cleanly on fresh database: `docker compose down -v && docker compose up -d`
      2. Check initdb scripts run in order: 001_pgvector.sql → 002_rag_schema.sql → 003_add_hyde_audit_columns.sql
      3. Confirm no migration conflicts or duplicate column errors in postgres logs
      4. Test container startup sequence: ensure RAG API starts even if Ollama not ready (graceful degradation)
      5. Document rollback procedure if migration needs to be reverted (DROP COLUMN commands)
  </plan>

  <commands>
    - **Apply Migration**:
      ```bash
      # Check if columns already exist
      docker exec specter-pgvector psql -U specter -d specter -c "\d query_audit"

      # Apply migration manually (if columns missing)
      docker exec specter-pgvector psql -U specter -d specter < infra/initdb/003_add_hyde_audit_columns.sql

      # OR copy file into container and run
      docker cp infra/initdb/003_add_hyde_audit_columns.sql specter-pgvector:/tmp/
      docker exec specter-pgvector psql -U specter -d specter -f /tmp/003_add_hyde_audit_columns.sql

      # Verify columns created
      docker exec specter-pgvector psql -U specter -d specter -c "SELECT column_name, data_type, column_default FROM information_schema.columns WHERE table_name = 'query_audit' AND column_name IN ('hyde_used', 'hyde_generation_ms');"
      ```

    - **Test Graceful Fallback**:
      ```bash
      # Enable HyDE in config (if not already)
      # Edit rag_api/.env.rag: HYDE_ENABLED=true

      # Rebuild RAG API to pick up code changes
      docker compose -f infra/compose/docker-compose.rag.yml build --no-cache rag-api
      docker compose -f infra/compose/docker-compose.rag.yml up -d

      # Test with Ollama running (should use HyDE)
      curl -s -X POST http://localhost:8001/query -H 'Content-Type: application/json' -d '{"query": "trust creation", "top_k": 3}' | jq .

      # Check logs show HyDE generation
      docker logs specter-rag-api 2>&1 | grep -i hyde | tail -5

      # Stop Ollama to simulate failure
      docker stop specter-ollama

      # Test fallback (should return 200, not 500)
      curl -s -X POST http://localhost:8001/query -H 'Content-Type: application/json' -d '{"query": "will requirements", "top_k": 3}' -w "\nHTTP Status: %{http_code}\n"

      # Check logs show WARNING about HyDE failure, not ERROR
      docker logs specter-rag-api 2>&1 | grep -i hyde | tail -10

      # Restart Ollama
      docker start specter-ollama
      ```

    - **Verify Audit Logging**:
      ```bash
      # Run query with HyDE enabled
      curl -s -X POST http://localhost:8001/query -H 'Content-Type: application/json' -d '{"query": "estate planning", "top_k": 3}'

      # Check query_audit table for HyDE columns (not just filters JSON)
      docker exec specter-pgvector psql -U specter -d specter -c "SELECT id, query_text, hyde_used, hyde_generation_ms, latency_ms FROM query_audit ORDER BY created_at DESC LIMIT 5;"

      # Verify hyde_used is in dedicated column (TRUE or FALSE), not embedded in filters JSONB
      docker exec specter-pgvector psql -U specter -d specter -c "SELECT hyde_used, hyde_generation_ms, filters FROM query_audit WHERE hyde_used = TRUE LIMIT 1;"
      ```

    - **Run Tests**:
      ```bash
      # Run all HyDE tests
      pytest tests/test_rag_api.py -k hyde -v -s

      # Run specific tests
      pytest tests/test_rag_api.py::test_query_with_hyde_enabled -v
      pytest tests/test_rag_api.py::test_hyde_audit_logging -v
      pytest tests/test_rag_api.py::test_hyde_service_graceful_fallback -v

      # Run full RAG API test suite
      pytest tests/test_rag_api.py -v
      ```

  </commands>

  <verification>
    1. **Migration applied**: `\d query_audit` shows hyde_used (boolean), hyde_generation_ms (integer) columns plus query_audit_hyde_used_idx index
    2. **Audit logging writes to columns**: After /query with HYDE_ENABLED=true, `SELECT hyde_used, hyde_generation_ms FROM query_audit ORDER BY created_at DESC LIMIT 1` returns TRUE and positive integer (not NULL)
    3. **Columns not in JSON blob**: `SELECT filters FROM query_audit WHERE hyde_used = TRUE LIMIT 1` should NOT contain hyde_used or hyde_generation_ms keys in JSONB (only hybrid_enabled or empty object)
    4. **Graceful fallback works**: Stopping specter-ollama and curling /query returns HTTP 200 with citations (not 500 error)
    5. **Fallback logs correctly**: Docker logs show WARNING level message about HyDE failure, hyde_used=false recorded in audit table
    6. **Tests enabled**: `pytest tests/test_rag_api.py -k hyde` executes tests without skips (or skips only if env flag not set, not hard-coded True)
    7. **Tests pass**: All HyDE tests (hyde_enabled, hyde_audit_logging, graceful_fallback) pass with 100% success rate
    8. **Fresh database works**: `docker compose down -v && docker compose up -d` creates query_audit table with hyde columns automatically (migration in initdb sequence)
    9. **No regression**: Existing /query functionality with HYDE_ENABLED=false still works (baseline behavior preserved)
    10. **Documentation updated**: quickfix.md HyDE section marked as resolved, or verification notes added to historylog.md
  </verification>

  <handoff>
    - **Update agents/historylog.md**: Add entry titled "[2025-11-19] Builder • HyDE Telemetry & Graceful Fallback Implementation" summarizing:
      * Migration applied: infra/initdb/003_add_hyde_audit_columns.sql added hyde_used and hyde_generation_ms columns to query_audit
      * Files modified: rag_api/services/query.py (_log_query_audit INSERT statement updated to populate new columns)
      * Graceful fallback validated: HyDE service already had error handling returning None on failures; QueryService correctly falls back to original query embedding
      * Tests enabled: Removed hard-coded skipif(True) from test_query_with_hyde_enabled, test_hyde_audit_logging, test_hyde_service_graceful_fallback
      * Manual verification results: Stopping Ollama returns HTTP 200 (not 500), logs show WARNING, audit table records hyde_used=false
      * Test results: All HyDE pytest tests passing (or note which tests still need mocking/fixtures)
      * Follow-up work: Baseline vs HyDE A/B testing now possible with structured audit data

    - **Update agents/quickfix.md**: Mark "HyDE Telemetry & Fallback" section (lines 267-287) as RESOLVED:
      * Status: ✅ RESOLVED (2025-11-19)
      * Resolution summary: Migration applied, audit logging fixed, graceful fallback verified, tests enabled
      * Verification commands executed (reference historylog entry for detailed results)

    - **Update agents/tasks.md**: Mark "2025-11-19 — Implement HyDE telemetry + graceful fallback" as COMPLETED with summary:
      * "Applied 003_add_hyde_audit_columns.sql migration, updated _log_query_audit to populate hyde_used and hyde_generation_ms columns, verified graceful fallback when Ollama unavailable (HTTP 200 instead of 500), enabled HyDE pytest coverage. Ready for production deployment and A/B testing."

    - **Move prompt artifact**: After successful implementation and user validation, move this file from agents/prompts/tasks/ to agents/prompts/completed/006-hyde-telemetry-fallback.md

    - **User notification**: Inform user that HyDE telemetry infrastructure is complete and resilient. Provide next steps:
      1. HyDE can now be safely enabled in production (set HYDE_ENABLED=true in .env.rag and restart RAG API)
      2. Audit data is structured and queryable for A/B testing (compare hyde_used=true vs hyde_used=false queries)
      3. Ollama unavailability will no longer break /query (graceful degradation to baseline retrieval)
      4. Run `pytest tests/test_rag_api.py -k hyde -v` to see all HyDE tests passing
      5. Monitor query_audit table to track HyDE usage rates and latency impact
  </handoff>
</prompt>
