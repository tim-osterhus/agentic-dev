<prompt id="006-pg-trgm-extension-install" branch="claude/move-pg-trgm-task-01K9KckPikM5NNU9XDX6nEnM" task="Enable pg_trgm + hybrid lexical+dense retrieval">
  <objective>
    Install the PostgreSQL pg_trgm extension and create GIN trigram indexes on the RAG corpus tables to unblock hybrid lexical+dense retrieval. The hybrid retrieval code was already implemented in a previous task (003-hybrid-lexical-dense-retrieval.md), but QA verification revealed that the database prerequisites (pg_trgm extension and GIN indexes) were never actually applied. This task closes that gap so lexical search can function and hybrid queries stop logging warnings.
  </objective>

  <context>
    - **Prior Work**: Hybrid retrieval implementation completed (QA verified code exists in rag_api/services/query.py with _search_collection_lexical(), _fuse_results_rrf(), and _fuse_results_weighted() methods)
    - **Current Blocker**: QA Verification from 2025-11-19 shows:
      * `\dx pg_trgm` returns zero rows (extension not installed)
      * `\di global_law*` shows only btree/HNSW indexes, no *_trgm_idx GIN indexes
      * Manual similarity queries fail: "function similarity(text, unknown) does not exist"
      * API logs emit "Lexical search in global_law failed (trigram indexes missing?)" on every hybrid query
    - **Database**: PostgreSQL 15+ (pgvector) running in specter-pgvector container, database name: specter (or specter_rag depending on config)
    - **Target Tables**: global_law (universal corpus), tenant_* (per-tenant collections)
    - **Migration Path**: Need to add pg_trgm to existing infra/initdb/ scripts so fresh deployments get it automatically, AND apply to existing running database
    - **Air-Gap Constraint**: pg_trgm is a standard PostgreSQL contrib extension (bundled with Postgres 15+), no external downloads needed
    - **Hybrid Search Config**: Already implemented with HYBRID_SEARCH_ENABLED, HYBRID_LEXICAL_WEIGHT, HYBRID_FUSION_METHOD in rag_api/config.py
  </context>

  <requirements>
    - Create migration file `infra/initdb/003_pg_trgm.sql` that:
      * Enables pg_trgm extension via `CREATE EXTENSION IF NOT EXISTS pg_trgm;`
      * Creates GIN trigram indexes on global_law(content), global_law(title), global_law(snippet) using `gin_trgm_ops` operator class
      * Includes SQL comments explaining index purpose (lexical search for hybrid retrieval)
      * Is idempotent (safe to run multiple times via IF NOT EXISTS / IF NOT EXISTS for indexes)
    - Update `infra/initdb/002_rag_schema.sql` function `create_tenant_collection()` to include trigram index creation for new tenant tables
    - Apply migration to existing running database (documented manual step or automated via entrypoint)
    - Verify extension and indexes present after migration
    - Confirm hybrid search warnings disappear from API logs
    - No breaking changes to existing vector-only search (backward compatibility when HYBRID_SEARCH_ENABLED=false)
    - Air-gap compliance: No external API calls, no model downloads, works offline
  </requirements>

  <plan>
    1. **Database Specialist**: Create migration file
       - Write `infra/initdb/003_pg_trgm.sql` with extension installation and GIN index creation
       - Include header comments: purpose, date, dependencies (requires 002_rag_schema.sql)
       - Add indexes for global_law: content_trgm_idx, title_trgm_idx, snippet_trgm_idx
       - Use `IF NOT EXISTS` for both extension and indexes (idempotency)
       - Document index sizes and performance impact in SQL comments

    2. **Database Specialist**: Update tenant collection function
       - Modify `create_tenant_collection()` in `infra/initdb/002_rag_schema.sql`
       - Add GIN trigram index creation step after embedding index creation
       - Ensure new tenant tables automatically get trigram support
       - Maintain backward compatibility (existing tenants need manual migration)

    3. **Database Specialist**: Apply migration to running database
       - Document manual migration command: `docker exec specter-pgvector psql -U specter -d specter -f /docker-entrypoint-initdb.d/003_pg_trgm.sql`
       - OR add to docker entrypoint so it auto-applies on container restart
       - Verify no errors during index creation (large tables may take time)
       - Consider adding progress logging or NOTICE statements in SQL

    4. **Backend Specialist**: Verify hybrid search activation
       - Restart specter-rag-api container after migration
       - Send test query with HYBRID_SEARCH_ENABLED=true
       - Inspect logs for "Hybrid search: vector=X, lexical=Y" info messages
       - Confirm no "trigram indexes missing" warnings
       - Verify _search_collection_lexical() executes without errors

    5. **QA Specialist**: Run verification suite
       - Execute database verification commands (see <commands> section)
       - Run pytest hybrid tests: `pytest tests/test_rag_api.py -k hybrid -v`
       - Manual exact citation test: query "524.2-502" and verify retrieval
       - Performance benchmark: compare hybrid vs vector-only latency
       - Document evidence in agents/historylog.md
  </plan>

  <commands>
    # Database Verification (run these after migration)

    # 1. Verify pg_trgm extension installed
    docker exec specter-pgvector psql -U specter -d specter -c "\dx pg_trgm"
    # Expected: Shows pg_trgm version, schema, description

    # 2. List all indexes on global_law table
    docker exec specter-pgvector psql -U specter -d specter -c "\di global_law*"
    # Expected: Shows global_law_content_trgm_idx, global_law_title_trgm_idx, global_law_snippet_trgm_idx (all GIN)

    # 3. Test trigram similarity function
    docker exec specter-pgvector psql -U specter -d specter -c "
      SELECT title, similarity(content, 'testator signature') AS score
      FROM global_law
      WHERE content % 'testator signature'
      ORDER BY score DESC LIMIT 3;
    "
    # Expected: Returns results with similarity scores (0.0-1.0 range), no "function does not exist" error

    # 4. Verify index sizes (informational)
    docker exec specter-pgvector psql -U specter -d specter -c "
      SELECT
        indexname,
        pg_size_pretty(pg_relation_size(schemaname||'.'||indexname)) AS index_size
      FROM pg_indexes
      WHERE tablename = 'global_law' AND indexname LIKE '%trgm%';
    "
    # Expected: Shows sizes (typically 20-30% of table size for GIN trigram indexes)

    # API Integration Tests

    # 5. Test hybrid query via API
    curl -X POST http://localhost:8001/query \
      -H "Content-Type: application/json" \
      -d '{"query": "testator signature requirements", "top_k": 5, "merge_global": true}'
    # Expected: Returns citations, no errors

    # 6. Check API logs for hybrid search confirmation
    docker logs specter-rag-api --tail 100 | grep -i "hybrid\|lexical\|trigram"
    # Expected: Shows "Hybrid search: vector=X, lexical=Y" or similar info logs, NO warnings about missing indexes

    # 7. Exact citation test (validates lexical boost)
    curl -X POST http://localhost:8001/query \
      -H "Content-Type: application/json" \
      -d '{"query": "524.2-502", "top_k": 3, "merge_global": true}'
    # Expected: Minnesota Statute 524.2-502 appears in top results (lexical search improves exact match recall)

    # Pytest Regression

    # 8. Run hybrid-specific tests
    pytest tests/test_rag_api.py -k hybrid -v
    # Expected: All hybrid tests pass (test_hybrid_search_enabled, test_exact_citation_matching, etc.)

    # 9. Full test suite (no regressions)
    pytest tests/test_rag_api.py -v
    # Expected: All tests pass (vector-only tests unaffected by trigram addition)
  </commands>

  <verification>
    - `\dx pg_trgm` shows pg_trgm extension installed in specter database
    - `\di global_law*` lists at least 3 GIN indexes: content_trgm_idx, title_trgm_idx, snippet_trgm_idx
    - Manual `similarity()` query executes without "function does not exist" error and returns results with scores 0.0-1.0
    - `docker logs specter-rag-api` shows "Hybrid search:" info logs when HYBRID_SEARCH_ENABLED=true (no "trigram indexes missing" warnings)
    - `/query` API endpoint returns 200 OK for test queries (both natural language and exact citations)
    - Exact citation query "524.2-502" retrieves Minnesota Statute 524.2-502 in top results
    - `pytest tests/test_rag_api.py -k hybrid -v` shows all hybrid tests passing
    - No regressions: vector-only queries (HYBRID_SEARCH_ENABLED=false) continue working unchanged
    - Migration file `infra/initdb/003_pg_trgm.sql` exists and is executable
    - `create_tenant_collection()` function includes GIN trigram index creation for new tenants
  </verification>

  <handoff>
    - Update `agents/historylog.md` with entry: "[YYYY-MM-DD] Database Specialist • pg_trgm Extension Installation"
      * Document migration steps executed
      * Include verification command outputs (extension version, index list, test query results)
      * Note any warnings or performance observations during index creation
      * Confirm hybrid retrieval warnings resolved
    - Update `agents/quickfix.md` to mark "Hybrid Retrieval Infrastructure" quickfix as RESOLVED
      * Change status from "❌ OPEN (P1)" to "✅ RESOLVED (YYYY-MM-DD)"
      * Reference this prompt and historylog entry
    - Move task from `agents/tasks.md` to completed section in `agents/historylog.md`
    - If fresh deployment instructions needed, update `docs/HYBRID_RETRIEVAL.md` (or README.md) with:
      * Note that pg_trgm is now included in initdb scripts (automatic for new deployments)
      * Document manual migration steps for existing databases
      * Add index size estimates and performance expectations
    - Create git commit with descriptive message referencing this prompt ID (006)
    - Push to branch: claude/move-pg-trgm-task-01K9KckPikM5NNU9XDX6nEnM
    - Notify user that database prerequisites are now in place and hybrid retrieval is fully operational
  </handoff>
</prompt>
