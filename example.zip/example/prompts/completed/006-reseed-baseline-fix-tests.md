<prompt id="006-reseed-baseline-fix-tests" branch="claude/reseed-baseline-fix-tests-006" task="Re-seed baseline documents & fix smoke tests">
  <objective>
    Fix the incomplete baseline document seeding that is blocking deterministic smoke tests. Previous implementation created the seeding infrastructure (scripts/seed_embeddings.py, updated SQL) but runtime verification shows the database is missing critical seed documents: only 2 of 3 global_law docs present (mn_statute_501c_0201 missing) and 0 tenant docs (firm_memo_estate_001 missing). This blocks pytest test_seeded_documents_queryable and prevents reliable regression testing of the RAG pipeline.
  </objective>

  <context>
    - Previous Builder session (2025-11-19) created seeding infrastructure: scripts/seed_embeddings.py, docs/SEEDING.md, updated infra/initdb/002_rag_schema.sql
    - QA approved code-level implementation but marked "READY FOR USER TESTING" due to Docker unavailability
    - Runtime verification (quickfix.md lines 240-264) reveals actual database state:
      * `docker exec specter-pgvector psql -c "SELECT doc_id FROM global_law"` returns only 2 rows (mn_statute_524_2-502, mn_statute_524_3-203)
      * Missing: mn_statute_501c_0201 (trust statute referenced in original seed plan)
      * `docker exec specter-pgvector psql -c "SELECT doc_id FROM tenant_firm_example"` returns 0 rows
      * Missing: firm_memo_estate_001 (tenant doc)
      * pg_column_size(embedding) = 3076 bytes instead of expected 3072 (needs investigation)
    - Test failure: `pytest tests/test_rag_api.py::test_seeded_documents_queryable` fails with assertion error (doc_ids list doesn't include mn_statute_501c_0201)
    - Existing infrastructure files:
      * scripts/seed_embeddings.py exists (wraps backfill_embeddings.py)
      * infra/initdb/002_rag_schema.sql has INSERT statements
      * tests/test_rag_api.py has test_seeded_documents_queryable
      * docs/SEEDING.md has comprehensive guide
    - Root cause hypothesis (from quickfix):
      * Database volume may predate migrations (SQL never ran)
      * create_tenant_collection may not have executed
      * Embeddings may be NULL even if rows exist
  </context>

  <requirements>
    - **Database Investigation**:
      * Verify current state: row counts, doc_ids, embedding NULL status, vector column size
      * Identify why SQL inserts didn't execute (transaction failure? volume mounts?)
      * Determine if create_tenant_collection() was called for tenant_firm_example
    - **SQL Fixes** (if needed):
      * Ensure infra/initdb/002_rag_schema.sql contains all 4 seed documents:
        - Global: mn_statute_524_2-502, mn_statute_524_3-203, mn_statute_501c_0201
        - Tenant: firm_memo_estate_001 (in tenant_firm_example collection)
      * Verify INSERT statements have correct syntax (ON CONFLICT handling, data types)
      * Add SQL comments mapping each doc_id to expected query (e.g., "-- Queryable via: 'trust creation requirements'")
    - **Manual Seeding Procedure** (if SQL didn't run):
      * Provide docker exec commands to manually INSERT missing documents
      * Include title, content, source, tags, metadata for each document
      * Use ON CONFLICT DO NOTHING to avoid duplicates
    - **Embedding Generation**:
      * Verify nomic-embed-text model available in Ollama
      * Run scripts/seed_embeddings.py or backfill_embeddings.py
      * Confirm all 4 documents have non-NULL embeddings (768-dim vectors)
      * Investigate 3076 vs 3072 byte discrepancy (document findings, may be acceptable overhead)
    - **Test Updates**:
      * Ensure test_seeded_documents_queryable checks for all 4 doc_ids (3 global + 1 tenant)
      * Update any hardcoded doc_id lists to match actual seed data
      * Verify test fixture setup (if any) doesn't conflict with seed data
    - **Verification**:
      * All SQL queries from quickfix.md return expected results
      * pytest test_seeded_documents_queryable passes
      * curl /query for "trust creation" returns mn_statute_501c_0201
      * curl /query tenant query returns firm_memo_estate_001
    - **Constraints**:
      * Air-gap compliant (use local Ollama, no external APIs)
      * Idempotent (safe to re-run seeding commands)
      * No docker compose down -v (preserve existing data if possible, just add missing seeds)
      * Work with running stack (don't require full teardown)
  </requirements>

  <plan>
    - **Phase 1: Database Investigation** (Backend/Database Engineer)
      1. Connect to running specter-pgvector container
      2. Query current state:
         ```sql
         SELECT doc_id, title, (embedding IS NOT NULL) as has_embedding FROM global_law ORDER BY doc_id;
         SELECT doc_id, title, (embedding IS NOT NULL) as has_embedding FROM tenant_firm_example ORDER BY doc_id;
         SELECT pg_column_size(embedding) FROM global_law WHERE embedding IS NOT NULL LIMIT 1;
         ```
      3. Check if tenant_firm_example table exists (may not be created yet)
      4. Review infra/initdb/002_rag_schema.sql INSERT statements
      5. Identify gaps: which documents are missing, which have NULL embeddings
      6. Document findings in terminal output (capture for historylog)

    - **Phase 2: Fix SQL or Manually Insert Missing Documents** (Database Engineer)
      * **Option A**: If SQL file is correct but never ran:
        - Manually execute missing INSERT statements via docker exec psql
        - Use ON CONFLICT DO NOTHING to avoid errors on existing rows
      * **Option B**: If SQL file is incomplete:
        - Update infra/initdb/002_rag_schema.sql with missing document INSERTs
        - Document that new deployments will have correct seeds (existing DB needs manual fix)
        - Still manually INSERT for current running database
      * **Option C**: If tenant_firm_example doesn't exist:
        - Call create_tenant_collection('firm_example') via SQL or API
        - Then INSERT firm_memo_estate_001
      * Provide exact SQL commands for manual execution in historylog/quickfix resolution

    - **Phase 3: Generate Embeddings** (Backend Engineer)
      1. Verify Ollama model: `docker exec specter-ollama ollama list | grep nomic-embed-text`
      2. If missing: `docker exec specter-ollama ollama pull nomic-embed-text`
      3. Run seeding: `docker exec specter-rag-api python /app/scripts/seed_embeddings.py`
      4. Verify embeddings generated:
         ```sql
         SELECT doc_id, (embedding IS NOT NULL) FROM global_law;
         SELECT doc_id, (embedding IS NOT NULL) FROM tenant_firm_example;
         ```
      5. All rows should show has_embedding=true
      6. Document embedding size discrepancy (3076 vs 3072) - likely PostgreSQL storage overhead, not a blocker

    - **Phase 4: Update Tests** (QA Engineer)
      1. Review tests/test_rag_api.py::test_seeded_documents_queryable
      2. Ensure doc_ids list includes all 4 documents:
         ```python
         expected_doc_ids = ['mn_statute_524_2-502', 'mn_statute_524_3-203', 'mn_statute_501c_0201', 'firm_memo_estate_001']
         ```
      3. Update test assertions if needed
      4. Run pytest to verify: `pytest tests/test_rag_api.py::test_seeded_documents_queryable -v`

    - **Phase 5: End-to-End Verification** (Integration Tester)
      1. **Database verification**:
         ```bash
         docker exec specter-pgvector psql -U specter -d specter -c "SELECT doc_id FROM global_law ORDER BY doc_id;"
         # Expected: 3 rows (mn_statute_524_2-502, mn_statute_524_3-203, mn_statute_501c_0201)

         docker exec specter-pgvector psql -U specter -d specter -c "SELECT doc_id FROM tenant_firm_example ORDER BY doc_id;"
         # Expected: 1+ rows (at least firm_memo_estate_001)
         ```
      2. **API query tests**:
         ```bash
         # Test global doc retrieval
         curl -X POST http://localhost:8001/query -H 'Content-Type: application/json' \
           -d '{"query": "trust creation requirements", "top_k": 3}'
         # Expected: mn_statute_501c_0201 in citations

         # Test tenant doc retrieval
         curl -X POST http://localhost:8001/query -H 'Content-Type: application/json' \
           -d '{"query": "firm estate procedures", "tenant_id": "firm_example", "top_k": 3}'
         # Expected: firm_memo_estate_001 in citations
         ```
      3. **Pytest validation**:
         ```bash
         pytest tests/test_rag_api.py::test_seeded_documents_queryable -v
         # Expected: PASSED

         pytest tests/test_rag_api.py::test_query_global_only -v
         pytest tests/test_rag_api.py::test_query_global_and_tenant_merge -v
         # Expected: Both PASSED
         ```
  </plan>

  <commands>
    # Investigation Commands
    docker ps | grep specter-pgvector  # Verify DB container running
    docker ps | grep specter-ollama    # Verify Ollama running
    docker ps | grep specter-rag-api   # Verify RAG API running

    docker exec specter-pgvector psql -U specter -d specter -c "\dt"  # List tables
    docker exec specter-pgvector psql -U specter -d specter -c "SELECT doc_id, title, (embedding IS NOT NULL) FROM global_law ORDER BY doc_id;"
    docker exec specter-pgvector psql -U specter -d specter -c "SELECT doc_id, title, (embedding IS NOT NULL) FROM tenant_firm_example ORDER BY doc_id;"
    docker exec specter-pgvector psql -U specter -d specter -c "SELECT pg_column_size(embedding) FROM global_law WHERE embedding IS NOT NULL LIMIT 1;"

    # Ollama Model Check
    docker exec specter-ollama ollama list
    docker exec specter-ollama ollama pull nomic-embed-text  # If needed

    # Manual Seeding (if SQL didn't run) - Example for missing trust statute
    # docker exec specter-pgvector psql -U specter -d specter <<EOF
    # INSERT INTO global_law (doc_id, title, content, source, tags, metadata)
    # VALUES (
    #   'mn_statute_501c_0201',
    #   'Minnesota Statute 501C.0201 - Trust Creation',
    #   '[Full statute text about trust creation requirements]',
    #   'Minnesota Statutes Annotated',
    #   ARRAY['trust', 'estate planning', 'minnesota'],
    #   '{"jurisdiction": "Minnesota", "category": "trust law", "year": "2023"}'::jsonb
    # ) ON CONFLICT (doc_id) DO NOTHING;
    # EOF

    # Embedding Generation
    docker exec specter-rag-api python /app/scripts/seed_embeddings.py

    # Verification
    docker exec specter-pgvector psql -U specter -d specter -c "SELECT doc_id, (embedding IS NOT NULL) FROM global_law;"
    docker exec specter-pgvector psql -U specter -d specter -c "SELECT doc_id, (embedding IS NOT NULL) FROM tenant_firm_example;"

    # API Tests
    curl -X POST http://localhost:8001/query -H 'Content-Type: application/json' -d '{"query": "trust creation", "top_k": 3}' | jq '.answers[0].citations[] | {doc_id, title}'
    curl -X POST http://localhost:8001/query -H 'Content-Type: application/json' -d '{"query": "firm estate procedures", "tenant_id": "firm_example", "top_k": 3}' | jq '.answers[0].citations[] | {doc_id, title}'

    # Pytest
    pytest tests/test_rag_api.py::test_seeded_documents_queryable -v
    pytest tests/test_rag_api.py -k "test_query_global" -v
  </commands>

  <verification>
    **Success Criteria (ALL must pass):**

    1. **Database State**:
       - `SELECT doc_id FROM global_law` returns exactly 3 rows:
         * mn_statute_524_2-502
         * mn_statute_524_3-203
         * mn_statute_501c_0201
       - `SELECT doc_id FROM tenant_firm_example` returns at least 1 row:
         * firm_memo_estate_001
       - All documents have `embedding IS NOT NULL`

    2. **Embedding Validation**:
       - `SELECT COUNT(*) FROM global_law WHERE embedding IS NULL` returns 0
       - `SELECT COUNT(*) FROM tenant_firm_example WHERE embedding IS NULL` returns 0
       - pg_column_size(embedding) returns 3072-3076 bytes (both acceptable, document actual value)

    3. **API Query Tests**:
       - Query "trust creation requirements" returns mn_statute_501c_0201 in top 3 citations
       - Query "will execution" returns mn_statute_524_2-502 in top 3 citations
       - Query "probate" returns mn_statute_524_3-203 in top 3 citations
       - Tenant query returns firm_memo_estate_001 when tenant_id="firm_example" specified

    4. **Pytest Suite**:
       - `test_seeded_documents_queryable` PASSES (checks all 4 doc_ids present in results)
       - `test_query_global_only` PASSES (verifies global document retrieval)
       - `test_query_global_and_tenant_merge` PASSES (verifies tenant + global merge)
       - No regressions: all other RAG API tests continue to pass

    5. **Evidence Artifacts** (capture in historylog):
       - Terminal output: SQL queries showing all 4 documents with embeddings
       - Terminal output: curl /query commands returning expected doc_ids
       - Terminal output: pytest showing PASSED status for all 3 tests
       - Screenshot or paste: SMOKE_TEST_CHECKLIST.md verification section (if updated)

    **Embedding Size Discrepancy Resolution**:
    - Document actual pg_column_size value observed (likely 3076)
    - Explain discrepancy: PostgreSQL adds 4-byte header to vector type (storage overhead)
    - Confirm 768 dimensions × 4 bytes/float = 3072 data bytes + 4 byte header = 3076 total
    - Update expectations.md or SEEDING.md to reflect 3076 as correct value
    - NOT a blocker: vector operations still work correctly
  </verification>

  <handoff>
    **After successful execution:**

    1. **Update agents/historylog.md**:
       - New entry: "[2025-11-20] Database Engineer • Re-seeded Baseline Documents (Runtime Fix)"
       - Include terminal output from all verification commands
       - Document which documents were missing and how they were fixed (manual INSERT vs SQL update)
       - Note embedding size finding (3076 bytes = correct with PostgreSQL header)
       - List all verification test results (SQL, API, pytest)

    2. **Update agents/quickfix.md**:
       - Change "Smoke Test Baseline Gaps" status from "❌ OPEN" to "✅ RESOLVED"
       - Add resolution notes:
         * Root cause: Database volume predated SQL migrations (seed statements never executed)
         * Fix: Manual INSERT via docker exec for missing documents
         * Embedding generation: Ran seed_embeddings.py successfully
         * Tests now pass: all 4 seeded documents queryable
       - Reference historylog entry for full verification output

    3. **Update agents/tasks.md**:
       - Mark task "2025-11-19 — Re-seed baseline documents & fix smoke tests" as COMPLETE
       - Or move to completed section with reference to historylog entry

    4. **Update docs/SEEDING.md** (if needed):
       - Add "Troubleshooting: Missing Seed Documents" section
       - Document manual INSERT procedure for future reference
       - Explain embedding size (3076 vs 3072) in FAQ or known issues
       - Link to relevant historylog entry

    5. **Update agents/expectations.md** (if needed):
       - Update embedding size expectation from 3072 to 3076 in "Embedding Validation" section
       - Note that 4-byte PostgreSQL header is normal and expected

    6. **Notify User**:
       - Provide summary: "Baseline documents re-seeded successfully. Database now contains 3 global + 1 tenant document with embeddings. All smoke tests passing."
       - List seeded documents with their queryable keywords:
         * mn_statute_524_2-502: "will execution requirements"
         * mn_statute_524_3-203: "informal probate process"
         * mn_statute_501c_0201: "trust creation requirements"
         * firm_memo_estate_001: "firm estate planning procedures"
       - Remind: Run `docker compose down -v` will erase seeds; re-run seed_embeddings.py after fresh deployment

    **If blockers encountered:**
    - Create new quickfix entry documenting blocker
    - Assign to appropriate specialist (Database Engineer, Backend Engineer)
    - DO NOT mark task complete until all verification criteria pass
  </handoff>
</prompt>
