<prompt id="006-vendor-avahi-image" branch="claude/move-avahi-task-01M5TB7Dca5KhwpZ6gAbSJT6" task="Vendor Avahi image / unblock hybrid DNS deployment">
  <objective>
    Make the Avahi mDNS container available for offline deployment so the hybrid DNS stack (CoreDNS + Avahi) can run without external registry access. This unblocks zero-configuration discovery of `specter.local` on macOS, iOS, Android, and Linux clients, a critical UX improvement for LAN-only installations where users cannot modify DHCP/router settings.
  </objective>

  <context>
    - The hybrid DNS deployment combines CoreDNS (unicast DNS) and Avahi (multicast DNS/DNS-SD) to provide automatic hostname resolution across diverse client platforms.
    - Current blocker: `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d` fails with "denied" error when pulling `ghcr.io/uglymagoo/avahi:latest` from GitHub Container Registry.
    - Air-gap constraint: Specter Legal targets LAN-only deployments with no WAN connectivity during runtime; all container images must be available locally or from accessible mirrors.
    - Avahi requires host networking mode and privileged capabilities (NET_ADMIN, NET_RAW) to send/receive multicast traffic on 224.0.0.251.
    - CoreDNS already works (verified in prior quickfix); only Avahi image access blocks full hybrid DNS validation.
    - Related files: `agents/mDNS/docker-compose.hybrid-dns.yml` (compose stack), `agents/mDNS/plan.md` (architecture docs), `agents/quickfix.md` (Hybrid DNS section, lines 313-330).
  </context>

  <requirements>
    - **Image availability**: Provide a working Avahi container image that can be loaded/built without GHCR access during deployment.
    - **Options** (choose one or provide alternatives for deployer):
      1. **Build from Dockerfile**: Create `agents/mDNS/Dockerfile.avahi` that builds Avahi from Alpine/Debian base and commit it to the repo.
      2. **Mirror to Docker Hub**: Pull the GHCR image (if accessible from build host), tag it, and push to a public or private Docker Hub repo under `specterexample/avahi` or similar.
      3. **Vendor tarball**: Pull image, save as tarball (`docker save`), commit to repo (or provide download link in docs), and document `docker load` steps.
    - **Constraints**:
      - Image must support the same runtime config as the GHCR original: Avahi daemon, D-Bus socket bind mounts, service file support.
      - No WAN dependencies during stack startup (pull must succeed from local cache or buildable from repo files).
      - Host networking and capabilities (NET_ADMIN, NET_RAW) must still work after any image changes.
    - **Documentation updates**:
      - Update `agents/mDNS/README.md` (or plan.md) with instructions for building/loading the vendored image.
      - Document verification commands (`dig`, `dns-sd`, `avahi-resolve`) and expected outputs.
      - Add troubleshooting notes for common Avahi issues (D-Bus socket conflicts, interface selection).
  </requirements>

  <plan>
    - **Step 1 (DevOps/Container Specialist)**: Investigate Avahi image options
      - Attempt to inspect `ghcr.io/uglymagoo/avahi:latest` manifest (if accessible from build host) to understand base image and entrypoint.
      - Evaluate Dockerfile approach: search for existing Avahi Dockerfiles (Alpine `avahi` package is ~2MB, Debian `avahi-daemon` is ~5MB), draft minimal Dockerfile.
      - Compare trade-offs: build time (adds ~30s to first deploy) vs tarball size (vendoring adds ~15MB to repo) vs registry dependency (requires Docker Hub account or self-hosted registry).
    - **Step 2 (Build Implementation)**: Choose and implement vendoring strategy
      - **If building from Dockerfile**:
        1. Create `agents/mDNS/Dockerfile.avahi` (Alpine-based: install `avahi` and `dbus` packages, expose D-Bus socket, set entrypoint to `avahi-daemon --no-chroot`).
        2. Update `docker-compose.hybrid-dns.yml` line 25 to `build: ./Dockerfile.avahi` instead of `image: ghcr.io/...`.
        3. Test build: `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml build avahi`.
      - **If mirroring to registry**:
        1. Pull GHCR image from accessible host: `docker pull ghcr.io/uglymagoo/avahi:latest`.
        2. Tag and push to accessible registry: `docker tag ... specterexample/avahi:1.0 && docker push ...`.
        3. Update compose file line 25 to new image reference.
      - **If vendoring tarball**:
        1. Save image: `docker save ghcr.io/uglymagoo/avahi:latest -o agents/mDNS/avahi.tar`.
        2. Add load instruction to README: `docker load -i agents/mDNS/avahi.tar`.
        3. Update compose file to reference local tag after load.
    - **Step 3 (QA/Verification Specialist)**: Validate hybrid DNS stack end-to-end
      - Bring up compose stack: `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d`.
      - Check container health: `docker ps | grep specter-mdns` (expect running/healthy).
      - Verify CoreDNS (unicast): `dig @127.0.0.1 specter.local +short` (expect configured IP, e.g., 192.168.4.57).
      - Verify Avahi (multicast): `dns-sd -G v4v6 specter.local` (macOS) or `avahi-resolve -n specter.local` (Linux) - expect same IP.
      - Verify DNS-SD announcement: `dns-sd -B _https._tcp` (expect `specter-https` service listed).
      - Test from client device (macOS/iOS): navigate to `https://specter.local`, confirm resolution without manual DNS config.
    - **Step 4 (Documentation Specialist)**: Update docs and capture verification evidence
      - Update `agents/mDNS/README.md` or `agents/mDNS/plan.md` with vendoring approach (build commands or load steps).
      - Add troubleshooting section: D-Bus socket errors, interface binding conflicts, firewall/multicast blocking.
      - Capture verification outputs (dig, dns-sd) and commit to `logs/` or reference in historylog.
      - Update `docs/STT_DICTATION.md` and `docs/HTTPS_LAN_SETUP.md` to reference hybrid DNS as recommended deployment method.
  </plan>

  <commands>
    - Build or load Avahi image (depends on chosen strategy):
      - `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml build avahi` (if Dockerfile approach)
      - `docker load -i agents/mDNS/avahi.tar` (if tarball approach)
    - Start hybrid DNS stack:
      - `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d`
    - Verification commands:
      - `docker ps | grep specter-mdns` (check container running)
      - `docker logs specter-mdns | head -30` (check for Avahi startup messages, no D-Bus errors)
      - `dig @127.0.0.1 specter.local +short` (verify CoreDNS returns expected IP)
      - `dns-sd -G v4v6 specter.local` (macOS) or `avahi-resolve -n specter.local` (Linux) - verify mDNS resolution
      - `dns-sd -B _https._tcp` (verify DNS-SD service announcement)
    - Teardown:
      - `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml down`
  </commands>

  <verification>
    - **Success criteria**:
      1. Avahi container starts successfully without pulling from GHCR (image available locally or built from repo).
      2. `docker ps` shows `specter-mdns` container running in host networking mode.
      3. `docker logs specter-mdns` shows Avahi daemon initialized with no D-Bus/socket errors.
      4. `dig @127.0.0.1 specter.local +short` returns the configured IP (matches CoreDNS zone).
      5. `dns-sd -G v4v6 specter.local` or `avahi-resolve -n specter.local` returns the same IP (mDNS working).
      6. `dns-sd -B _https._tcp` lists the `specter-https` service with correct port (443) and TXT records.
      7. From a macOS/iOS device on the same LAN, `https://specter.local` resolves and loads without manual DNS configuration.
    - **Evidence to capture**:
      - Screenshot or terminal output of `docker ps` showing both `specter-dns` and `specter-mdns` healthy.
      - Output of `dig`, `dns-sd`, `avahi-resolve` commands demonstrating successful resolution.
      - Confirmation that stack starts successfully after `docker compose down && docker compose up` cycle (no external registry dependency).
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md` summarizing vendoring approach (Dockerfile/mirror/tarball), verification results, and any site-specific configuration notes.
    - Update `agents/quickfix.md` "Hybrid DNS Stack Deployment" section to mark status as ✅ RESOLVED.
    - If Dockerfile approach used, commit `agents/mDNS/Dockerfile.avahi` and updated `docker-compose.hybrid-dns.yml`.
    - If tarball approach used, add `.gitattributes` entry for `agents/mDNS/avahi.tar` (LFS or ignore) and document download/load process in README.
    - If mirrored to registry, document the new image reference and access requirements in deployment docs.
    - Notify user/team that hybrid DNS stack is now deployable offline and provide link to updated `agents/mDNS/plan.md` for client testing procedures.
  </handoff>
</prompt>

---

## Completion Record

**Completed**: 2025-11-20
**Branch**: `claude/move-avahi-task-01M5TB7Dca5KhwpZ6gAbSJT6`
**Commit**: d3cd6aa
**QA Status**: ⚠️ Awaiting on-host verification (Docker not available in build environment)

### Implementation Summary

**Strategy Chosen**: Dockerfile approach (Option 1)

**Files Created/Modified**:
- `agents/mDNS/Dockerfile.avahi` - Alpine 3.19 base with avahi/dbus packages (~5MB)
- `agents/mDNS/docker-compose.hybrid-dns.yml` - Updated to build from local Dockerfile
- `agents/mDNS/README.md` - Added air-gap section + comprehensive troubleshooting
- `agents/quickfix.md` - Marked quickfix as RESOLVED
- `agents/historylog.md` - Added implementation entry

**Verification Commands** (to be run on Docker host):
```bash
# Build image locally (no GHCR access required)
docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml build avahi

# Deploy stack
docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d

# Verify Avahi container
docker ps | grep specter-mdns
docker logs specter-mdns --tail 50

# Test DNS resolution
dig @127.0.0.1 specter.local +short                # CoreDNS unicast
dns-sd -G v4v6 specter.local                       # mDNS multicast (macOS)
avahi-resolve -n specter.local                     # mDNS multicast (Linux)
dns-sd -B _https._tcp                              # DNS-SD service discovery
```

**Next Steps**:
- QA agent should verify on Docker-enabled host
- Test from macOS/iOS clients: `https://specter.local` should resolve without manual DNS config
- Document any site-specific configuration (interface names, IP addresses) in deployment notes

See `agents/historylog.md` for detailed implementation notes.
