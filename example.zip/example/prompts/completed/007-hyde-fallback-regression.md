<prompt id="007-hyde-fallback-regression" branch="claude/hyde-fallback-prompt-01W7SWaqeQayNNovEEfs8Gmw" task="Fix HyDE Fallback Regression">
  <objective>
    Fix the regression where stopping Ollama causes `/query` with HyDE enabled to return HTTP 500 (`RetryError[ConnectError]`) instead of gracefully falling back to baseline embeddings with HTTP 200 response and warning logs. This is a Phase 2 blocker preventing production deployment of HyDE functionality.
  </objective>

  <context>
    - HyDE service exists at rag_api/services/hyde.py with retry logic
    - HyDE is integrated into QueryService.query() at rag_api/services/query.py
    - Marathon QA (agents/historylog.md) captured stack traces showing RetryError[ConnectError] when specter-ollama is stopped
    - Current behavior: `/query` with `hyde_enabled=true` returns HTTP 500 when Ollama unavailable
    - Expected behavior: `/query` should return HTTP 200 with citations, falling back to baseline embeddings, with WARNING logs (not ERROR)
    - HyDE service has error handling (rag_api/services/hyde.py:99-116) but exceptions may be bubbling up instead of being caught
    - Test suite has test_hyde_service_graceful_fallback (tests/test_rag_api.py:445) but may be skipped or incomplete
    - This is distinct from the broader HyDE telemetry work in prompt 006; this quickfix focuses solely on the fallback regression
  </context>

  <requirements>
    - **Graceful Fallback Implementation**:
      * Harden QueryService.query() in rag_api/services/query.py to catch HyDE failures
      * Ensure HyDE service exceptions (httpx.ConnectError, TimeoutException, etc.) return None instead of propagating
      * When HyDE returns None, QueryService must fall back to baseline query_embedding without raising exceptions
      * All fallback paths must return HTTP 200 (never 500) with valid citations

    - **Audit Logging for Fallback**:
      * When HyDE fallback occurs, ensure `hyde_used=false` is logged in audit
      * Log warning messages at WARNING level (not ERROR) when HyDE unavailable
      * Capture that fallback occurred without generating user-facing errors

    - **Regression Tests**:
      * Add/enable test_query_hyde_fallback in tests/test_rag_api.py
      * Test must simulate Ollama unavailability (mock ConnectError or stop container)
      * Assert HTTP 200 response with valid citations
      * Assert hyde_used=false in audit logs
      * Assert WARNING logs present (no ERROR stack traces)

    - **Integration Testing**:
      * Manual curl test with Ollama stopped must return HTTP 200
      * Docker logs must show warnings, not stack traces
      * Verify behavior matches when Ollama is both running and stopped

    - **Constraints**:
      * Air-gapped environment (no external dependencies)
      * Must not break existing HyDE functionality when Ollama is available
      * Code changes only (no runtime testing in web environment per user instructions)
  </requirements>

  <plan>
    - **Phase 1: Code Analysis**
      1. Read rag_api/services/hyde.py to understand current error handling
      2. Read rag_api/services/query.py QueryService.query() method to trace HyDE integration
      3. Identify where exceptions might be bubbling up (retry decorators, async calls, etc.)
      4. Check if httpx.ConnectError is in the list of caught exceptions

    - **Phase 2: Implement Hardened Fallback**
      1. Update rag_api/services/hyde.py if needed:
         - Ensure all Ollama connection errors return None (not raise)
         - Add httpx.ConnectError to caught exceptions if missing
         - Log at WARNING level when fallback occurs
      2. Update rag_api/services/query.py QueryService.query():
         - Add try/except around HyDE generation call if not present
         - Ensure None response from HyDE triggers fallback to baseline embeddings
         - Verify fallback path logs hyde_used=false
         - Ensure no exceptions propagate to FastAPI handler (which would cause 500)

    - **Phase 3: Add/Fix Regression Tests**
      1. Read tests/test_rag_api.py to find test_hyde_service_graceful_fallback
      2. If test is skipped with @pytest.mark.skipif(True), remove or update condition
      3. Implement test logic:
         - Mock httpx.AsyncClient to raise ConnectError when calling Ollama
         - Call /query endpoint with query text
         - Assert response.status_code == 200
         - Assert response contains citations
         - Assert audit log shows hyde_used=false
      4. Add integration test comments showing manual verification steps

    - **Phase 4: Documentation Updates**
      1. Update any inline comments explaining fallback behavior
      2. Ensure error messages are user-friendly (no technical stack traces exposed)
      3. Document the graceful degradation pattern for future features
  </plan>

  <commands>
    - **Code Analysis**:
      ```bash
      # Read current HyDE service implementation
      cat rag_api/services/hyde.py

      # Read QueryService integration
      grep -A 30 "def query" rag_api/services/query.py

      # Find all exception handlers in HyDE service
      grep -n "except" rag_api/services/hyde.py
      ```

    - **Test Verification** (after implementation):
      ```bash
      # Run HyDE fallback test
      pytest tests/test_rag_api.py::test_hyde_service_graceful_fallback -v -s

      # Run all HyDE tests
      pytest tests/test_rag_api.py -k hyde -v

      # Run full test suite to ensure no regressions
      pytest tests/test_rag_api.py -v
      ```

    - **Manual Integration Test** (instructions for QA):
      ```bash
      # Start stack with HyDE enabled
      docker compose -f infra/compose/docker-compose.rag.yml up -d

      # Verify HyDE works with Ollama running
      curl -s -X POST http://localhost:8001/query \
        -H 'Content-Type: application/json' \
        -d '{"query": "estate plan workflow", "top_k": 3}' \
        | jq '.citations | length'
      # Expected: citations count (e.g., 3)

      # Stop Ollama to simulate unavailability
      docker stop specter-ollama

      # Test fallback - should return 200, not 500
      curl -s -X POST http://localhost:8001/query \
        -H 'Content-Type: application/json' \
        -d '{"query": "trust creation requirements", "top_k": 3}' \
        -w "\nHTTP Status: %{http_code}\n" \
        | jq .
      # Expected: HTTP Status: 200, citations present

      # Check logs for warnings (not errors/stack traces)
      docker logs specter-rag-api 2>&1 | tail -50 | grep -i hyde
      # Expected: WARNING messages about fallback, no ERROR or RetryError

      # Verify audit log shows fallback
      docker exec specter-pgvector psql -U specter -d specter \
        -c "SELECT query_text, hyde_used FROM query_audit ORDER BY created_at DESC LIMIT 2;"
      # Expected: hyde_used=false for the query made while Ollama was down

      # Restart Ollama
      docker start specter-ollama
      ```
  </commands>

  <verification>
    1. **Code Changes**:
       - rag_api/services/hyde.py catches httpx.ConnectError and returns None
       - rag_api/services/query.py QueryService.query() handles None from HyDE gracefully
       - No unhandled exceptions that could cause HTTP 500

    2. **Fallback Behavior**:
       - When Ollama stopped, /query returns HTTP 200 (not 500)
       - Response includes valid citations from baseline embedding search
       - No RetryError or ConnectError in response

    3. **Logging**:
       - WARNING level logs when HyDE fallback occurs
       - No ERROR level stack traces in logs
       - Audit log shows hyde_used=false for fallback queries

    4. **Tests Pass**:
       - pytest tests/test_rag_api.py::test_hyde_service_graceful_fallback passes
       - All HyDE-related tests pass (pytest -k hyde)
       - Full test suite passes with no new failures

    5. **No Regression**:
       - HyDE still works when Ollama is available
       - Baseline queries (without HyDE) unchanged
       - Existing tests continue to pass
  </verification>

  <handoff>
    - **Update agents/historylog.md**: Add entry titled "[2025-11-20] Builder • HyDE Fallback Regression Fix (Prompt 007)" including:
      * Prompt ID: 007-hyde-fallback-regression
      * Files modified: rag_api/services/hyde.py, rag_api/services/query.py, tests/test_rag_api.py
      * Root cause: httpx.ConnectError not caught/handled, causing exceptions to bubble up to FastAPI
      * Fix applied: Added/updated exception handling to return None and fall back to baseline embeddings
      * Test results: test_hyde_service_graceful_fallback now passes, HTTP 200 returned when Ollama down
      * Manual verification: Stopped Ollama, curled /query, received 200 with citations, logs show WARNING (not ERROR)
      * Audit logging: hyde_used=false recorded when fallback occurs

    - **Update agents/quickfix.md**: Mark "HyDE Fallback Regression" (lines 20-37) as RESOLVED:
      * Status: ✅ RESOLVED (2025-11-20)
      * Resolution: Hardened QueryService.query() exception handling; HyDE failures now return None and fall back gracefully
      * Verification: All required verification commands executed successfully (reference historylog for details)

    - **QA Testing Instructions** for local agent:
      ```
      # QA Agent: Execute these commands to validate the fix

      1. Start the RAG stack:
         docker compose -f infra/compose/docker-compose.rag.yml up -d

      2. Run pytest to verify tests pass:
         pytest tests/test_rag_api.py -k hyde -v
         pytest tests/test_rag_api.py::test_hyde_service_graceful_fallback -v -s

      3. Manual integration test:
         a. Test with Ollama running (verify HyDE works):
            curl -s -X POST http://localhost:8001/query \
              -H 'Content-Type: application/json' \
              -d '{"query": "estate planning", "top_k": 3}'

         b. Stop Ollama and test fallback:
            docker stop specter-ollama
            curl -s -X POST http://localhost:8001/query \
              -H 'Content-Type: application/json' \
              -d '{"query": "will requirements", "top_k": 3}' \
              -w "\nHTTP: %{http_code}\n"
            # MUST return HTTP 200 with citations

         c. Check logs (expect WARNING, no ERROR):
            docker logs specter-rag-api 2>&1 | tail -50 | grep -i hyde

         d. Verify audit logging:
            docker exec specter-pgvector psql -U specter -d specter \
              -c "SELECT hyde_used, query_text FROM query_audit ORDER BY created_at DESC LIMIT 3;"
            # Last query should show hyde_used=false

         e. Restart Ollama:
            docker start specter-ollama

      4. Verify no regressions:
         pytest tests/test_rag_api.py -v
         # All tests should pass

      Expected Results:
      - All tests pass
      - HTTP 200 responses even when Ollama stopped
      - WARNING logs (not ERROR) when fallback occurs
      - hyde_used=false in audit for fallback queries
      - No RetryError or stack traces in logs or responses
      ```
  </handoff>
</prompt>
