<prompt id="007-vendor-avahi-image" branch="claude/hybrid-dns-prompt-01EK5pMxLWtjEDaVUh9q1hMi" task="Vendor Avahi mDNS image for air-gapped hybrid DNS deployment">
  <objective>
    Resolve the Avahi container crash blocker preventing hybrid DNS stack deployment. The `specter-mdns` container fails immediately with `avahi-daemon: option requires an argument: f` because the GHCR image has an incomplete entrypoint. This quickfix vendors a local Dockerfile for Avahi that includes the correct configuration path argument, eliminating external registry dependencies and enabling fully air-gapped mDNS/DNS-SD service discovery for `specter.local`.
  </objective>

  <context>
    - Marathon QA (2025-11-19) discovered hybrid DNS deployment failure: `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d` builds successfully but `specter-mdns` container crashes in restart loop
    - Error: `avahi-daemon: option requires an argument: f` indicates entrypoint is incomplete (missing `-f /etc/avahi/avahi-daemon.conf`)
    - Current compose file references `ghcr.io/uglymagoo/avahi:latest` which is external dependency (violates air-gap requirement)
    - CoreDNS container (`specter-dns`) works correctly, only Avahi mDNS service is blocked
    - Configuration files already prepared: `agents/mDNS/avahi-daemon.conf`, `agents/mDNS/specter-https.service`, `agents/mDNS/docker-compose.hybrid-dns.yml`
    - Avahi requires host networking mode for multicast traffic (224.0.0.251) and capabilities NET_ADMIN/NET_RAW
    - Target deployment: Alpine-based minimal container (~5-10MB) with avahi-daemon running in foreground mode
    - Verification commands defined in quickfix.md: dig, dns-sd, docker logs checks
    - Blocker status: Phase 6 of QA marathon, preventing mDNS/DNS-SD validation for zero-config client resolution
    - Air-gap compliance mandatory: no external pulls during deployment, local image build only
  </context>

  <requirements>
    - Create `agents/mDNS/Dockerfile.avahi` with correct Avahi daemon entrypoint including config file path
    - Use Alpine Linux base (minimal footprint, ~5MB)
    - Install packages: avahi, avahi-tools, dbus (required for Avahi service announcements)
    - Entrypoint must include: `avahi-daemon --no-chroot -f` (foreground mode for Docker, no chroot for container env)
    - Note: config file path will be provided via volume mount from compose, so entrypoint relies on default location `/etc/avahi/avahi-daemon.conf`
    - Update `agents/mDNS/docker-compose.hybrid-dns.yml` to build from local Dockerfile instead of pulling from GHCR
    - Tag built image as `specter-avahi:local` for consistency
    - Preserve existing volume mounts: avahi-daemon.conf, specter-https.service, dbus sockets
    - Preserve existing capabilities: NET_ADMIN, NET_RAW (required for multicast)
    - Preserve host networking mode (multicast cannot traverse NAT)
    - Update `agents/mDNS/README.md` with build instructions, troubleshooting, air-gap deployment notes
    - Document verification procedure: container health, Avahi daemon logs, DNS resolution tests
    - Ensure backward compatibility: existing compose configuration should work with only image source change
    - No runtime testing in web environment (Docker unavailable), but validate syntax and document QA verification steps
  </requirements>

  <plan>
    - **Infrastructure & DevOps Specialist**: Create Avahi Dockerfile
      1. Review existing Avahi configuration files in `agents/mDNS/`:
         - `avahi-daemon.conf`: daemon configuration (hostname, interfaces, IPv4/IPv6 settings)
         - `specter-https.service`: DNS-SD service announcement for _https._tcp
         - `docker-compose.hybrid-dns.yml`: current compose configuration
      2. Create `agents/mDNS/Dockerfile.avahi`:
         - Base image: `FROM alpine:3.19` (stable, minimal, well-supported)
         - Install packages: `apk add avahi avahi-tools dbus` with cache cleanup
         - Create necessary directories: `/var/run/avahi-daemon`, `/var/run/dbus`
         - Document port exposure: `EXPOSE 5353/udp` (mDNS, though host networking makes this documentary)
         - Set entrypoint: `ENTRYPOINT ["avahi-daemon", "--no-chroot", "-f"]`
           - `--no-chroot`: required for containerized environments (avahi-daemon expects chroot by default)
           - `-f`: run in foreground so Docker can monitor the process and restart if needed
           - Config file path handled by default location + volume mount from compose
         - Add inline comments explaining each section for future maintainers
      3. Validate Dockerfile syntax and best practices:
         - Single RUN command for apk to minimize layers
         - Remove package cache after install (`rm -rf /var/cache/apk/*`)
         - Clear comments for entrypoint flags
         - Document that config files come from volume mounts
      4. Expected image size: ~5-10MB (Alpine base + Avahi packages)

    - **Docker Configuration Specialist**: Update compose file
      1. Modify `agents/mDNS/docker-compose.hybrid-dns.yml`:
         - Locate `avahi` service definition (currently using `image: ghcr.io/uglymagoo/avahi:latest`)
         - Replace `image:` directive with:
           ```yaml
           build:
             context: .
             dockerfile: Dockerfile.avahi
           image: specter-avahi:local
           ```
         - This builds from local Dockerfile and tags as `specter-avahi:local`
         - Preserve all existing configuration:
           - `container_name: specter-mdns`
           - `network_mode: host` (required for multicast)
           - `cap_add: [NET_ADMIN, NET_RAW]` (required for network operations)
           - `volumes:` mounts for avahi-daemon.conf, specter-https.service, dbus sockets
           - `restart: unless-stopped`
      2. Verify YAML syntax: ensure indentation and structure are valid
      3. Document build command in compose file comments or README
      4. Note: No environment variables or runtime changes needed, only image source

    - **Documentation Writer**: Update README and troubleshooting
      1. Update `agents/mDNS/README.md`:
         - Add section "Air-Gap Deployment / Offline Build" explaining Dockerfile approach
         - Document build command: `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml build avahi`
         - Document deployment command: `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d`
         - Add troubleshooting section:
           - Avahi daemon not starting: check `docker logs specter-mdns` for D-Bus errors
           - Container restart loop: verify config file mounted correctly, check entrypoint
           - mDNS not resolving: verify host networking mode, check firewall rules
           - Interface binding issues: review `allow-interfaces=` in avahi-daemon.conf
         - Include verification commands from quickfix.md
         - Reference existing plan.md for detailed architecture and design decisions
      2. If `agents/mDNS/README.md` doesn't exist, create it with:
         - Purpose: Hybrid DNS stack with CoreDNS (unicast) + Avahi (multicast mDNS)
         - Quick start: build and deploy commands
         - Verification: dig, dns-sd, docker logs
         - Files inventory: Dockerfile.avahi, docker-compose.hybrid-dns.yml, config files
         - Links to plan.md and main documentation
      3. Add note about air-gap compliance: local build eliminates GHCR dependency
      4. Cross-reference with `docs/HTTPS_LAN_SETUP.md` if it exists

    - **QA Test Engineer**: Define verification procedures (documentation only, no runtime tests)
      1. Document container build verification:
         ```bash
         docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml build avahi
         # Expected: Builds successfully without GHCR access
         # Expected: Image size ~5-10MB
         # Expected: Tagged as specter-avahi:local
         ```
      2. Document stack deployment verification:
         ```bash
         docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d
         docker ps | grep specter-mdns
         # Expected: Container running, not restarting
         # Expected: Network mode shows "host"
         ```
      3. Document Avahi daemon health check:
         ```bash
         docker logs specter-mdns --tail 50
         # Expected: "Server startup complete"
         # Expected: "Host name is specter.local" or similar
         # Expected: No "option requires an argument" errors
         # Expected: No D-Bus connection failures
         ```
      4. Document DNS resolution verification:
         ```bash
         # CoreDNS (unicast DNS)
         dig @127.0.0.1 specter.local +short
         # Expected: Returns configured IP (e.g., 21.0.0.174)

         # Avahi mDNS (requires macOS or Linux with avahi-utils)
         dns-sd -G v4v6 specter.local        # macOS
         avahi-resolve -n specter.local      # Linux
         # Expected: Same IP as CoreDNS

         # DNS-SD service discovery
         dns-sd -B _https._tcp               # macOS
         avahi-browse -a -t                  # Linux
         # Expected: Lists specter-https service
         ```
      5. Document process check inside container:
         ```bash
         docker exec specter-mdns ps aux
         # Expected: avahi-daemon process running
         # Expected: Possibly dbus-daemon process
         ```
      6. Create verification checklist for QA agent (local Docker host required):
         - [ ] Build completes without external registry access
         - [ ] Image tagged as specter-avahi:local (~5-10MB)
         - [ ] Container starts and stays running (not restart loop)
         - [ ] Logs show "Server startup complete", no errors
         - [ ] CoreDNS resolves specter.local (dig test)
         - [ ] Avahi resolves specter.local (dns-sd/avahi-resolve test, if tools available)
         - [ ] DNS-SD service announcement visible (dns-sd -B/_https._tcp)

    - **Backend Systems Engineer**: Validate existing configuration files
      1. Review `agents/mDNS/avahi-daemon.conf`:
         - Verify `host-name=` is set correctly (should be "specter" for specter.local)
         - Check `use-ipv4=yes` and `use-ipv6=` settings match network requirements
         - Validate `allow-interfaces=` (empty = all interfaces, or specify primary LAN interface)
         - Confirm `enable-dbus=yes` (required for DNS-SD service announcements)
      2. Review `agents/mDNS/specter-https.service`:
         - Verify service type: `_https._tcp`
         - Confirm port: `port=443` (matches nginx HTTPS)
         - Check TXT records if any (optional metadata)
      3. No changes expected unless configuration errors are found
      4. Document any site-specific customizations that may be needed (interface names, IPv6 policy)

    - **Documentation Writer**: Update quickfix.md
      1. Locate "Quick Fix Plan — Hybrid DNS Stack (Avahi)" section (lines ~40-57)
      2. Update status from `❌ OPEN (Phase 6 blocker)` to `✅ RESOLVED (2025-11-20)`
      3. Add resolution summary:
         - Created `agents/mDNS/Dockerfile.avahi` with correct entrypoint (`-f` flag included)
         - Updated `docker-compose.hybrid-dns.yml` to build from local Dockerfile (eliminating GHCR dependency)
         - Tagged image as `specter-avahi:local` for air-gap compliance
         - Enhanced `agents/mDNS/README.md` with build instructions and troubleshooting
      4. Add verification plan for QA (same commands as in quickfix, but note that QA must run on Docker host)
      5. Reference historylog entry and prompt artifact for traceability
  </plan>

  <commands>
    - Validate Dockerfile syntax (static analysis, no runtime):
      ```bash
      # Check file exists and has correct entrypoint
      grep -A 2 ENTRYPOINT agents/mDNS/Dockerfile.avahi
      # Expected: ENTRYPOINT ["avahi-daemon", "--no-chroot", "-f"]
      ```

    - Validate compose file syntax:
      ```bash
      # Note: This may fail if Docker unavailable, syntax check only
      docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml config 2>&1 | head -20
      # Expected: YAML output or "service must be a mapping" (acceptable if no Docker)
      ```

    - Verify file structure:
      ```bash
      ls -lh agents/mDNS/
      # Expected: Dockerfile.avahi, docker-compose.hybrid-dns.yml, avahi-daemon.conf, specter-https.service, plan.md, README.md
      ```

    - Check for GHCR references (should be removed):
      ```bash
      grep -n "ghcr.io" agents/mDNS/docker-compose.hybrid-dns.yml
      # Expected: No matches (or commented out)
      ```

    - Verify local build directive exists:
      ```bash
      grep -A 3 "build:" agents/mDNS/docker-compose.hybrid-dns.yml
      # Expected: Shows context and dockerfile path
      ```

    - Validation commands for QA (documented for later execution on Docker host):
      ```bash
      # Build verification
      docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml build avahi

      # Deployment verification
      docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d
      docker ps | grep specter-mdns
      docker logs specter-mdns --tail 50

      # DNS resolution verification
      dig @127.0.0.1 specter.local +short
      dns-sd -G v4v6 specter.local  # macOS
      dns-sd -B _https._tcp         # macOS
      ```
  </commands>

  <verification>
    - **Success Criteria** (code/docs level, runtime testing deferred):
      1. ✅ `agents/mDNS/Dockerfile.avahi` created with Alpine base, avahi packages, correct entrypoint
      2. ✅ Entrypoint includes `--no-chroot -f` flags for containerized foreground execution
      3. ✅ `agents/mDNS/docker-compose.hybrid-dns.yml` updated to build from local Dockerfile
      4. ✅ Compose file tags image as `specter-avahi:local`
      5. ✅ No references to `ghcr.io/uglymagoo/avahi` in compose file (eliminated external dependency)
      6. ✅ Existing volume mounts, capabilities, and host networking preserved in compose
      7. ✅ `agents/mDNS/README.md` updated with build instructions, verification commands, troubleshooting
      8. ✅ Air-gap deployment documented (no external registry required)
      9. ✅ `agents/quickfix.md` updated to ✅ RESOLVED with summary and verification plan
      10. ✅ Verification commands documented for QA agent to run on Docker-enabled host
      11. ⚠️ Runtime testing deferred: Docker unavailable in web environment, requires local QA execution
      12. ⚠️ Full hybrid DNS verification deferred: requires Docker host with CoreDNS + Avahi containers running

    - **Evidence to Capture** (code review only):
      - File presence: `ls -lh agents/mDNS/` shows Dockerfile.avahi, updated compose, README
      - Entrypoint verification: `grep ENTRYPOINT agents/mDNS/Dockerfile.avahi`
      - Compose build directive: `grep -A 3 "build:" agents/mDNS/docker-compose.hybrid-dns.yml`
      - GHCR removal: `grep ghcr agents/mDNS/docker-compose.hybrid-dns.yml` returns no matches
      - README update: documentation includes build commands and troubleshooting
      - Quickfix status: `grep "Hybrid DNS" agents/quickfix.md` shows ✅ RESOLVED

    - **Acceptable Gaps** (environment constraints):
      - No Docker runtime available: Cannot execute `docker build` or `docker compose up`
      - No LAN clients for mDNS testing: Cannot verify dns-sd resolution from macOS/iOS devices
      - Syntax validation only: Can validate YAML/Dockerfile structure but not actual container behavior
      - QA validation debt: Document runtime verification steps for QA agent to execute on Docker host
      - Expected QA workflow: QA agent runs on Docker-enabled host, follows verification checklist, validates container health and DNS resolution
  </verification>

  <handoff>
    - Append entry to `agents/historylog.md`:
      - Date: 2025-11-20
      - Agent: Builder (Infrastructure & DevOps + Documentation Specialists)
      - Status: ✅ COMPLETE (Code/Docs) - Runtime verification required on Docker host
      - Prompt artifact executed: `agents/prompts/tasks/007-vendor-avahi-image.md`
      - Summary: "Resolved hybrid DNS deployment blocker by vendoring Avahi image locally. Created Dockerfile.avahi with correct entrypoint, updated compose to eliminate GHCR dependency, enhanced documentation for air-gap deployment."
      - Files created:
        - `agents/mDNS/Dockerfile.avahi` (Alpine 3.19, avahi + dbus, entrypoint with --no-chroot -f)
      - Files modified:
        - `agents/mDNS/docker-compose.hybrid-dns.yml` (build from local Dockerfile, tag specter-avahi:local)
        - `agents/mDNS/README.md` (build instructions, troubleshooting, air-gap notes)
        - `agents/quickfix.md` (status updated to RESOLVED with verification plan)
      - Verification status:
        - ✅ Code changes complete: Dockerfile created, compose updated, docs enhanced
        - ⚠️ Runtime testing deferred: Docker unavailable in build environment
      - QA validation requirements (user must execute on Docker host):
        ```bash
        # 1. Build verification (air-gap compliance)
        docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml build avahi
        # Expect: Builds without GHCR access, ~5-10MB image, tagged specter-avahi:local

        # 2. Deployment verification
        docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d
        docker ps | grep specter-mdns
        # Expect: Container running (not restarting), host network mode

        # 3. Avahi daemon health
        docker logs specter-mdns --tail 50
        # Expect: "Server startup complete", no entrypoint errors, no D-Bus failures

        # 4. DNS resolution (CoreDNS)
        dig @127.0.0.1 specter.local +short
        # Expect: Returns configured IP (e.g., 21.0.0.174)

        # 5. mDNS resolution (macOS/Linux with avahi-utils)
        dns-sd -G v4v6 specter.local        # macOS
        avahi-resolve -n specter.local      # Linux
        # Expect: Same IP as CoreDNS

        # 6. DNS-SD service discovery
        dns-sd -B _https._tcp               # macOS
        avahi-browse -a -t                  # Linux
        # Expect: Lists specter-https service on port 443

        # 7. Client testing (browser from LAN device)
        # From macOS/iOS/Android client: https://specter.local
        # Expect: Resolves automatically without manual DNS config
        ```
      - Rationale:
        - Air-gap compliance: Eliminates external GHCR dependency, allows offline deployment
        - Entrypoint fix: Adds `-f` flag to resolve "option requires an argument" crash loop
        - Minimal footprint: Alpine base keeps image size ~5-10MB
        - Maintainability: Local Dockerfile is version-controlled and customizable
      - Known limitations:
        - Requires Docker host with multicast support (host networking mode)
        - Linux clients need nss-mdns for mDNS resolution
        - Full cross-platform testing requires LAN client devices
      - Next steps:
        - QA agent validates on Docker-enabled host following verification checklist above
        - Upon QA PASS, move prompt to `agents/prompts/completed/007-vendor-avahi-image.md`
        - Upon QA FAIL, document issues in quickfix.md and assign remediation

    - Update `agents/quickfix.md`:
      - Mark "Hybrid DNS Stack (Avahi)" as ✅ RESOLVED (2025-11-20)
      - Add resolution details and verification plan (see plan section above)

    - Create `agents/expectations.md` entry (for QA cycle):
      - Functional: Avahi container starts without errors, advertises specter.local via mDNS
      - Non-functional: Air-gap deployment works, image size <10MB, maintains backward compatibility
      - Verification: Build succeeds without GHCR, container healthy, DNS resolution works
      - Files: Dockerfile.avahi (new), compose (modified), README (modified), quickfix (resolved)
      - Tests: Build, deploy, logs, dig, dns-sd (deferred to QA on Docker host)

    - Notify QA agent:
      - "✅ Hybrid DNS Avahi quickfix complete. Dockerfile created, compose updated, docs enhanced."
      - "⚠️ Runtime testing required on Docker host. Follow verification checklist in historylog."
      - "📋 Prompt artifact: agents/prompts/tasks/007-vendor-avahi-image.md"
      - "🎯 Expected outcome: specter-mdns container runs without restart loop, mDNS resolution works"
  </handoff>
</prompt>
