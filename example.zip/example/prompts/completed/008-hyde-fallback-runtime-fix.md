<prompt id="008-hyde-fallback-runtime-fix" branch="claude/hyde-fallback-runtime-fix-01XHydeRuntime4Fix" task="HyDE Fallback Runtime Stabilization">
  <objective>
    Ensure the HyDE-enhanced `/query` endpoint gracefully degrades when Ollama is unavailable so attorneys never see HTTP 500 errors—queries must always return 200 with citations while emitting warning telemetry, restoring trust in Phase 2 functionality.
  </objective>

  <context>
    - Quickfix tracker (agents/quickfix.md §HyDE Fallback Regression) shows runtime failure despite merged code changes; HyDE still throws RetryError when specter-ollama stops.
    - Latest marathon QA (agents/historylog.md lines 713‑759) captured stack traces: stopping Ollama causes `/query` to return HTTP 500 with `services.embedding` `httpx.ConnectError`.
    - HyDE service lives in `rag_api/services/hyde.py`; QueryService integration is in `rag_api/services/query.py`.
    - Tests exist (`test_hyde_service_graceful_fallback`, HyDE-specific cases) but were skipped or ineffective.
    - Environment is air-gapped; only local services (FastAPI, pgvector, Ollama) are available; we must not introduce WAN dependencies.
  </context>

  <requirements>
    - Harden `QueryService.query()` (rag_api/services/query.py) so any HyDE failure (timeout, ConnectError, None response) falls back to the original embedding path without raising, ensuring HTTP 200 responses.
    - Update `HyDEService` in rag_api/services/hyde.py to catch httpx.ConnectError / Timeout / HTTPStatusError and return None while logging warnings (no ERROR stack traces).
    - When fallback happens, ensure audit logging writes `hyde_used=false`, `hyde_generation_ms=0`, and logs contain a single WARNING summarizing the fallback (agents expect this telemetry).
    - Add/repair automated tests:
      * A unit-level HyDE fallback test using mocks to simulate ConnectError.
      * Integration-style async test in `tests/test_rag_api.py` that mocks the embedding call or HyDE service to emulate Ollama offline (without stopping Docker during tests) asserting HTTP 200 + warnings.
    - Touch documentation (historylog entry + quickfix update) summarizing the fix and verification steps; keep docs ASCII.
    - No new dependencies; continue using httpx + tenacity already in repo.
  </requirements>

  <plan>
    - Backend Engineer:
      1. Inspect `HyDEService.generate_hypothetical_answer` try/except coverage; ensure `httpx.ConnectError`, `TimeoutException`, and general `httpx.HTTPError` are caught and yield `None`.
      2. Wrap the HyDE augmentation block inside `QueryService.query()` in a dedicated try/except; if HyDE returns `None` or raises, skip weighting logic, log warning (include exception message), and continue with baseline vector search.
      3. Guarantee `hyde_used`/`hyde_generation_ms` variables are set even when HyDE fails before initialization.
    - Test Engineer:
      1. In `tests/test_hyde_service.py`, add a test where httpx.AsyncClient.post raises `ConnectError` and assert `generate_hypothetical_answer` returns `None` without raising.
      2. In `tests/test_rag_api.py`, create/enable an async test that monkeypatches `HyDEService.generate_hypothetical_answer` to raise `ConnectError` (or return None) and asserts `/query` responds 200 with citations and `hyde_used` false in response metadata if exposed.
      3. Ensure HyDE test subset can be run via `pytest tests/test_rag_api.py -k hyde`.
    - Documentation Writer:
      1. Update `agents/quickfix.md` HyDE entry to note this builder effort and mark runtime testing pending.
      2. Add a `agents/historylog.md` entry describing code changes, the fallback behavior, and pending QA instructions.
  </plan>

  <commands>
    - Code touchpoints:
      ```bash
      sed -n '1,200p' rag_api/services/hyde.py
      sed -n '1,220p' rag_api/services/query.py
      ```
    - Tests to run after implementation:
      ```bash
      # Unit tests
      source .venv2/bin/activate
      pytest tests/test_hyde_service.py -k fallback -v

      # HyDE subset (includes integration test)
      pytest tests/test_rag_api.py -k hyde -v

      # Targeted API check (run after spinning stack with HYDE_ENABLED=true)
      curl -s -X POST http://localhost:8001/query \
        -H 'Content-Type: application/json' \
        -d '{"query":"estate plan workflow","hyde_enabled":true,"top_k":3}'
      docker stop specter-ollama
      curl -s -X POST http://localhost:8001/query \
        -H 'Content-Type: application/json' \
        -d '{"query":"estate plan workflow","hyde_enabled":true,"top_k":3}' \
        -w "\nHTTP %{http_code}\n"
      docker start specter-ollama
      docker logs specter-rag-api --tail 50 | grep -i hyde
      ```
  </commands>

  <verification>
    - `/query` with `hyde_enabled=true` returns HTTP 200 and citations both when specter-ollama is healthy and when it is stopped (fallback mode).
    - `docker logs specter-rag-api` shows WARNING messages about HyDE fallback but no ERROR stack traces or RetryError output.
    - Audit data (`SELECT hyde_used, hyde_generation_ms FROM query_audit ORDER BY created_at DESC LIMIT 1`) records `hyde_used=false` and `hyde_generation_ms=0` for fallback queries.
    - `pytest tests/test_hyde_service.py -k fallback` and `pytest tests/test_rag_api.py -k hyde` both pass locally.
  </verification>

  <handoff>
    - Update `agents/historylog.md` with the builder execution summary, commands run, and note that QA must rerun the HyDE fallback manual curl test after implementation.
    - Append to `agents/quickfix.md` HyDE entry describing the runtime fix attempt, remaining risks, and status (pending QA).
    - Leave clear instructions in the history log for local QA: which env vars to toggle (HYDE_ENABLED=true), which docker commands to run (`docker stop specter-ollama`, curl checks), and how to re-enable baseline mode afterward.
  </handoff>
</prompt>
