<prompt id="009-hybrid-dns-mdns-runtime-fix" branch="claude/hybrid-dns-fix-01MdnsRuntimeFix" task="Hybrid DNS Stack (Avahi) Runtime Fix">
  <objective>
    Deliver a fully offline hybrid DNS stack where the vendored Avahi container boots cleanly (no crash loop) so CoreDNS + mDNS resolution works for specter.local without external registries—a prerequisite for zero-config LAN deployments.
  </objective>

  <context>
    - `agents/quickfix.md` notes Avahi still restarts with `avahi-daemon: option requires an argument: f`; runtime validation never passed.
    - `agents/mDNS/Dockerfile.avahi` already exists but ENTRYPOINT lacks the config path.
    - `agents/mDNS/docker-compose.hybrid-dns.yml` needs the correct command args and volume mounts for `avahi-daemon.conf`/service files.
    - Marathon QA logs (2025-11-19) show `specter-dns` healthy but `specter-mdns` crash-looping; runtime fix must resolve this.
    - Environment is air-gapped; container builds must vendor all dependencies locally.
  </context>

  <requirements>
    - Update Dockerfile/compose so Avahi runs `avahi-daemon --no-chroot -f /etc/avahi/avahi-daemon.conf` and has the necessary config/service files mounted read-only.
    - Ensure docker-compose file keeps host networking/capabilities but references the new image tag (no GHCR pulls).
    - Document runtime verification commands (docker compose up, dig, dns-sd / avahi-resolve) and expected outputs in README/quickfix entries.
    - Do not run network tests; only describe how local QA should execute them.
  </requirements>

  <plan>
    - Backend/Infra Engineer:
      1. Update `agents/mDNS/Dockerfile.avahi` ENTRYPOINT to include config path.
      2. Adjust docker-compose service to guarantee the config/service files are mounted and the command passes `-f /etc/avahi/avahi-daemon.conf`.
    - Documentation Engineer:
      1. Refresh `agents/mDNS/README.md` with new build/run steps and troubleshooting guidance for Avahi logs.
      2. Describe expected outputs for `dig`, `dns-sd`, and `docker logs`.
    - Ops Coordinator:
      1. Update `agents/quickfix.md` and `agents/historylog.md` with prompt execution details + pending QA steps.
  </plan>

  <commands>
    - None to execute now; local QA will later run:
      ```bash
      docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d --build
      docker ps | grep specter-mdns
      docker logs specter-mdns --tail 50
      dig @127.0.0.1 specter.local +short
      dns-sd -G v4v6 specter.local
      dns-sd -B _https._tcp
      ```
  </commands>

  <verification>
    - Compose build succeeds offline (no GHCR pulls).
    - `specter-mdns` stays in “Up” state; logs show “Server startup complete”.
    - CoreDNS (`dig`) and Avahi (`dns-sd`/`avahi-resolve`) return consistent IPs.
    - Documentation clearly states the validation steps and expected outputs.
  </verification>

  <handoff>
    - Append builder summary to `agents/historylog.md` noting prompt ID and pending runtime QA.
    - Update `agents/quickfix.md` Hybrid DNS section with new instructions/status.
  </handoff>
</prompt>
