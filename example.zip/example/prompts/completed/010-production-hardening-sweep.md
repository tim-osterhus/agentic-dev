<prompt id="010-production-hardening-sweep" branch="claude/production-hardening-sweep" task="Production hardening sweep">
  <objective>
    Lock down LibreChat account creation, reclaim Docker disk space, and document log/disk audit steps so the stack is production-ready and operators have clear runbooks.
  </objective>
  <context>
    - Task card: agents/tasks.md (2025-11-19 Production hardening sweep) with acceptance requiring ALLOW_REGISTRATION=false, Docker disk cleanup, and log-audit guidance.
    - Quickfix entry: agents/quickfix.md “Production Hardening Sweep” lists required actions (disable registration, docker system df/prune, record Docker root/log sizes, add audit instructions).
    - Recent environment: air-gapped/restricted network; Docker available; LibreChat env file lives at librechat/.env.librechat; prior docs for logging exist in docs/LOGGING_AUDIT.md.
    - Historylog must capture manual verifications and reference the prompt ID; prompt runner must archive the artifact when done.
  </context>
  <requirements>
    - Set ALLOW_REGISTRATION=false in librechat/.env.librechat; note how admins should create accounts when registration is disabled (e.g., via admin seed or invite flow; document where to do this).
    - Run docker system df, evaluate size; if oversized, run docker system prune -af --volumes (or targeted prune) and capture before/after stats.
    - Record Docker root path (docker info --format '{{.DockerRootDir}}') and summarize log sizes per container (du -sh $ROOT/containers/*/*-json.log); note findings in docs/historylog.
    - Add/augment log-audit guidance (e.g., docs/LOGGING_AUDIT.md or agents/historylog.md) describing where to inspect container logs and disk usage.
    - Operate offline (no WAN pulls); keep changes minimal and documented for QA.
  </requirements>
  <plan>
    - Planner: Load this prompt via agents/prompts/run_prompt.md, confirm scope, and checkpoint plan.
    - Backend/Config specialist: Update librechat/.env.librechat to disable registration; add admin creation note in appropriate doc (README/librechat docs/historylog).
    - DevOps specialist: Run docker system df; decide on prune; record docker info root and log sizes; capture outputs for docs.
    - Documentation writer: Update docs/LOGGING_AUDIT.md or relevant doc with log/disk audit steps; append historylog entry referencing this prompt and manual checks.
    - Archivist: When complete, move prompt to agents/prompts/completed/ with completion note.
  </plan>
  <commands>
    - grep -n \"ALLOW_REGISTRATION\" librechat/.env.librechat
    - docker system df
    - docker system prune -af --volumes  # run only if cleanup is warranted; capture before/after
    - docker system df  # after prune for comparison
    - docker info --format '{{.DockerRootDir}}'
    - ROOT=$(docker info --format '{{.DockerRootDir}}'); du -sh \"$ROOT\"; du -sh \"$ROOT\"/containers/*/*-json.log
  </commands>
  <verification>
    - librechat/.env.librechat shows ALLOW_REGISTRATION=false.
    - docker system df output captured (and reduced if prune executed); docker root path recorded with log size summary.
    - Log-audit documentation updated with locations/commands; historylog entry includes manual verification notes and prompt ID.
  </verification>
  <handoff>
    - Append builder summary and commands/results to agents/historylog.md tagged with prompt path agents/prompts/tasks/010-production-hardening-sweep.md.
    - If incomplete, describe blockers in historylog and leave prompt in tasks/; if complete, move artifact to agents/prompts/completed/ with completion footer.
    - Flag QA to rerun docker df/root/log checks and confirm registration is disabled in LibreChat UI upon deployment.
  </handoff>
</prompt>

---
Completed 2025-11-19 on branch claude/production-hardening-sweep — Builder ready for QA.
