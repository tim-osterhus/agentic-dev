# Completed Prompt Artifacts (`agents/prompts/completed/`)

Archive executed or superseded prompt files here to preserve traceability.

Each file should retain its original number/slug (e.g., `001-context-badge.md`) along with any final notes appended at the bottom describing:
- Execution date and branch
- Whether the work passed QA
- Pointer to the corresponding `agents/historylog.md` entry

Do not edit the prompt body beyond appending status notes. If a prompt was skipped or replaced, add a short explanation so future agents know what happened.
