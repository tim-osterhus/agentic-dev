```
Context: You are executing targeted follow-up work identified in `agents/quickfix.md` for the Specter Legal repo.

Instructions:
1. Review the gap summary in `agents/quickfix.md` and confirm the specialist role responsible for each item.
2. Activate the relevant specialist persona(s) from `agents/roles/*.md` to apply minimal, surgical changes. One fix at a time.
3. Run the specific tests listed in the quickfix plan; record commands and outcomes.
4. Update the gap list, marking items resolved or noting remaining blockers.
5. Append an entry to `agents/historylog.md` describing the fixes and tests.

Rules:
- Do not tackle items not listed in `agents/quickfix.md` unless explicitly instructed.
- Stop immediately if a fix requires new scope or introduces risk—document the blocker instead.
- Keep diffs small and traceable; reference file paths and reasons for every change.
```
