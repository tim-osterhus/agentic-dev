<prompt id="001-hyde-mdns-regressions" branch="local/hyde-mdns-regressions" task="Run HyDE-enabled regressions + mDNS CLI verification">
  <objective>
    Verify HyDE-enabled tests and mDNS CLI outputs so Phase 2 (HyDE) and Phase 6 (Hybrid DNS) have complete runtime evidence before Phase 3 hardware handoff.
  </objective>
  <context>
    - Last marathon QA passed Phases 1–8 but HyDE-enabled tests were skipped (HYDE_TESTS_ENABLED missing) and dns-sd tooling was absent; dig/Avahi logs showed success.
    - Current state: pg_trgm/hybrid retrieval, ingest auth, HyDE fallback, production hardening all landed; registration disabled; Docker root/log audit done.
    - Goal of this task card (agents/tasksbacklog.md 2025-11-22): clear skips and capture mDNS CLI evidence.
  </context>
  <requirements>
    - Enable HyDE tests by setting HYDE_TESTS_ENABLED=1 for pytest invocations.
    - Start required services (pgvector, ollama, rag-api, mongo; LibreChat not needed for tests).
    - Install or use available dns-sd/avahi CLI to run Phase 6 commands (`dns-sd -G v4v6 specter.local`, `dns-sd -B _https._tcp` or equivalent).
    - Rerun dig check for specter.local and capture outputs.
    - Append results and commands run to agents/historylog.md; leave no new quickfix unless failures occur.
  </requirements>
  <plan>
    - Planner Architect: confirm env cleanliness (git status, docker access), identify needed tools for dns-sd.
    - Infra/DevOps Engineer: bring up minimal stack, ensure specter-mdns running; install dns-sd/avahi-utils if missing.
    - Backend/QA Engineer: run HyDE-enabled pytest subset and full sweep as specified; capture outputs.
    - Infra/DevOps Engineer: execute mDNS CLI commands (dns-sd/avahi-resolve) plus dig; record outputs.
    - Documentation Writer: update agents/historylog.md with commands/results; note any skips/failures and next steps.
  </plan>
  <commands>
    - Stack: `docker compose -f infra/compose/docker-compose.pgvector.yml -f infra/compose/mongo.yml -f infra/compose/ollama.yml -f infra/compose/rag.yml up -d`
    - HyDE tests: `HYDE_TESTS_ENABLED=1 pytest tests/test_rag_api.py -k hyde -v`
    - Full sweep: `HYDE_TESTS_ENABLED=1 pytest tests/test_rag_api.py tests/test_chat_endpoint.py -v > test_results.txt`
    - mDNS: `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d`; `dig @127.0.0.1 specter.local +short`; `dns-sd -G v4v6 specter.local`; `dns-sd -B _https._tcp` (or `avahi-resolve -n specter.local` / `avahi-browse -a -t` if dns-sd unavailable).
  </commands>
  <verification>
    - HyDE tests report PASSED (no skips) or any failures documented with logs.
    - test_results.txt generated with HYDE enabled; summary recorded in history log.
    - mDNS CLI outputs show specter.local resolving to expected IP and service browse returning `_https._tcp` entry; dig continues to resolve.
    - No new quickfix unless a failure/blocker persists.
  </verification>
  <handoff>
    - Append a concise entry to agents/historylog.md summarizing commands, results, and any blockers.
    - Leave prompt file in place until QA cycle completes; QA will reference this prompt.
  </handoff>
</prompt>
