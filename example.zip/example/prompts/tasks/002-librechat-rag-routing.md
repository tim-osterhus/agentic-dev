<prompt id="002-librechat-rag-routing" branch="claude/librechat-rag-routing-002" task="Diagnose LibreChat not hitting rag-api (no citations/logs)">
  <objective>
    Restore LibreChat → rag-api connectivity so UI queries reach the backend, emit logs, and return citations identical to direct API calls.
  </objective>
  <context>
    - Active task card (2025-11-22): LibreChat shows no citations/logs; must confirm wiring to rag-api and restore normal RAG responses.
    - Acceptance: UI queries produce citations; rag-api logs show matching chat/query requests; LibreChat configs correctly point to rag-api.
    - Stack uses docker compose services: specter-rag-api (port 8001 on host), specter-librechat (port 3080), nginx optional; configs mounted from librechat/.env.librechat and librechat/librechat.yaml.
    - Prior notes: Health checks showed LibreChat/nginx unhealthy; rag-api healthy; HYDE toggles exist in rag_api/.env.rag (default false).
  </context>
  <requirements>
    - Verify LibreChat config sources: librechat/.env.librechat and librechat/librechat.yaml; ensure base URLs point to rag-api (http://rag-api:8000 internally, http://localhost:8001 externally if needed).
    - Confirm running container mounts/use the intended configs (docker inspect binds; cat files inside container).
    - Validate network path: container names, ports, extra_hosts, and compose wiring; ensure no mismatch with nginx.
    - While issuing UI queries, tail rag-api logs to confirm requests reach backend; capture evidence.
    - Directly curl rag-api /chat and /query to confirm citations and compare with LibreChat behavior.
    - Restart/rebuild librechat (and nginx if involved) after config changes.
    - No external network calls; stay air-gapped.
  </requirements>
  <plan>
    - Planner Architect: Restate scope, list assumptions, choose checkpoints.
    - Infra/DevOps Engineer: Inspect compose wiring, ports, volumes; verify container mounts and envs.
    - Frontend & Integration Engineer: Audit LibreChat config files vs container runtime; fix base URLs/endpoints; rebuild/restart librechat/nginx if needed.
    - Backend Systems Engineer: Send test queries (/chat, /query) and watch rag-api logs; compare with UI; adjust as needed.
    - Documentation & Enablement Writer: Summarize findings and changes for historylog; leave prompt for QA if unfinished.
  </plan>
  <commands>
    - docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
    - docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d   # ensure DNS stack stays up if needed
    - docker inspect specter-librechat --format '{{json .HostConfig.Binds}}'
    - docker exec specter-librechat cat /app/.env
    - docker exec specter-librechat head -n 200 /app/librechat.yaml
    - cat librechat/.env.librechat
    - cat librechat/librechat.yaml
    - curl -s -X POST http://localhost:8001/query -H "Content-Type: application/json" -d '{"query":"trust creation","top_k":3}'
    - curl -s -X POST http://localhost:8001/chat -H "Content-Type: application/json" -d '{"messages":[{"role":"user","content":"trust creation"}]}' 
    - docker logs specter-rag-api --tail 200 | sed -n '1,120p'
    - Trigger a LibreChat UI query (manual or via API) and watch: docker logs -f specter-rag-api (capture snippet)
    - If configs change: docker compose -f infra/compose/docker-compose.librechat.yml up -d --build librechat
  </commands>
  <verification>
    - LibreChat UI query returns citations matching a direct /chat or /query curl.
    - docker logs specter-rag-api shows entries corresponding to LibreChat requests (timestamps/paths).
    - librechat/.env.librechat and librechat/librechat.yaml base URLs align with rag-api service; container reflects same.
    - If nginx is in path, confirm proxy targets rag-api correctly.
  </verification>
  <handoff>
    - Append Builder summary to agents/historylog.md referencing this prompt ID.
    - Leave prompt file in tasks/ (no QA run). If fully executed and ready for QA, note readiness in historylog and final message.
  </handoff>
</prompt>
