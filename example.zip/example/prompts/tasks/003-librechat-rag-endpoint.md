<prompt id="003-librechat-rag-endpoint" branch="claude/librechat-rag-endpoint-003" task="Fix LibreChat → rag-api routing so chat returns citations">
  <objective>
    Enable LibreChat to send chat/semantic requests to rag-api so UI queries generate citations and rag-api logs reflect the traffic, matching direct /chat and /query curls.
  </objective>
  <context>
    - Active task card (2025-11-22): LibreChat not hitting rag-api; no citations/logs.
    - Current config: librechat/.env.librechat sets RAG_API_URL=http://rag-api:8000; container env matches. librechat/librechat.yaml defines only custom specter-ollama (baseURL http://ollama:11434/v1) with no RAG/chat endpoint; logs show only config load and “RAG API reachable” check.
    - rag-api healthy; direct curls to /query and /chat return citations and produce RAG_AUDIT logs. No LibreChat requests seen in rag-api logs.
    - LibreChat container lacks curl; librechat/nginx healthchecks currently unhealthy but running.
  </context>
  <requirements>
    - Add a RAG-aware endpoint/tool in librechat/librechat.yaml (and any needed frontend/backend wiring) pointing at rag-api (http://rag-api:8000) so chat flows go through rag-api and return citations.
    - Ensure env/config inside the running librechat container reflects the updated YAML/endpoint.
    - Rebuild/restart librechat (and nginx if needed) after config changes; keep RAG_API_URL env aligned.
    - Validate by issuing a LibreChat query and tailing rag-api logs to confirm traffic and citations; compare with direct curls to /chat and /query.
    - Stay air-gapped; do not remove existing specter-ollama endpoint unless required.
  </requirements>
  <plan>
    - Planner Architect: Confirm scope and desired UX (citations visible, rag-api logs).
    - Infra/DevOps Engineer: Inspect compose wiring/ports, volume mounts, and ensure updated librechat.yaml binds into container; restart services as needed.
    - Frontend & Integration Engineer: Modify librechat/librechat.yaml (and minimal code if required) to introduce a rag-api-backed endpoint/tool; ensure model selection or default points to RAG path.
    - Backend Systems Engineer: Run direct curls to rag-api (/chat, /query) for baseline; issue LibreChat query and tail rag-api logs to verify requests arrive; adjust configs if not.
    - Documentation & Enablement Writer: Log commands, changes, and outcomes in agents/historylog.md; leave prompt in tasks (no QA).
  </plan>
  <commands>
    - docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
    - docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d
    - cat librechat/.env.librechat
    - cat librechat/librechat.yaml
    - docker inspect specter-librechat --format '{{json .HostConfig.Binds}}'
    - docker exec specter-librechat env | grep RAG_API_URL
    - (after edits) docker compose -f infra/compose/docker-compose.librechat.yml up -d --build librechat
    - (if needed) docker compose -f infra/compose/docker-compose.librechat.yml -f infra/compose/docker-compose.nginx.yml up -d nginx
    - curl -s -X POST http://localhost:8001/query -H "Content-Type: application/json" -d '{"query":"trust creation","top_k":3}'
    - curl -s -X POST http://localhost:8001/chat -H "Content-Type: application/json" -d '{"messages":[{"role":"user","content":"trust creation"}]}'
    - docker logs specter-rag-api --tail 200
    - Trigger LibreChat UI query (or API) and tail: docker logs -f specter-rag-api (capture snippet)
  </commands>
  <verification>
    - LibreChat UI query produces citations matching direct rag-api curl responses.
    - docker logs specter-rag-api show entries for LibreChat requests (chat/query).
    - librechat/librechat.yaml and container config reflect rag-api endpoint; RAG_API_URL env remains correct.
    - Services running/healthy after restart (librechat, rag-api; nginx if used).
  </verification>
  <handoff>
    - Append Builder summary to agents/historylog.md referencing this prompt ID; leave prompt in tasks (no QA run).
    - Note remaining gaps if citations/log routing still fails.
  </handoff>
</prompt>
