# Quick Fix Plan — Seed Baseline Documents (2025-11-19)

**Status:** ✅ RESOLVED (Verified 2025-11-19 QA Marathon #2)

**Observed (original issue):** Marathon QA previously showed `global_law` missing `mn_statute_501c_0201` and `tenant_firm_example` empty until rows were manually reinserted. `pytest tests/test_rag_api.py::test_seeded_documents_queryable` failed until those inserts/backfill ran by hand.

**Resolution Evidence (2025-11-19 QA Marathon #2):**
1. `docker exec specter-pgvector ... SELECT doc_id FROM global_law` now returns all three statutes (`mn_statute_501c_0201`, `mn_statute_524_2-502`, `mn_statute_524_3-203`) without manual inserts.
2. `docker exec specter-pgvector ... tenant_firm_example` includes `firm_memo_estate_001`; embeddings are non-null for all rows.
3. `pytest tests/test_rag_api.py::test_seeded_documents_queryable -v` passes (4.13 s).
4. `curl -s -X POST http://localhost:8001/query ... {"query":"trust creation"}` cites all seeded statutes and returns HTTP 200.
5. Documentation updated (`agents/superqaprompt.md`, `agents/verify_post_merge.md`) to lock in the verification steps.

---

# Quick Fix Plan — HyDE Fallback Regression (2025-11-19)

**Status:** ✅ RESOLVED (Runtime verified 2025-11-21)
**Builder:** Prompt 007 executed on 2025-11-20
**QA:** QA cycle executed on 2025-11-20
**Builder Branch:** `claude/hyde-fallback-prompt-01W7SWaqeQayNNovEEfs8Gmw`
**QA Branch:** `claude/qa-hyde-fallback-prompt-01FhKRDy4mk2fMA5ApTba5Uu`
**Commit:** 0aea0cd

**Observed:** Stopping `specter-ollama` still causes `/query` with HyDE enabled to return HTTP 500 (`RetryError[ConnectError]`) instead of a 200 with warning logs. Marathon QA captured stack traces in `agents/historylog.md`.

**Required Actions:**
1. ✅ Harden `QueryService.query()` so HyDE failures return `None` and fall back to baseline embeddings rather than bubbling the exception.
   - Added explicit `httpx.ConnectError` handler in `rag_api/services/hyde.py:99-104`
   - Added defensive try/except wrapper in `rag_api/services/query.py:50-82`
2. ✅ Ensure audit logging captures `hyde_used=false` and warning messages when fallback occurs.
   - Existing audit logging already captured `hyde_used=false` when HyDE returns None
   - All exception handlers log at WARNING level (not ERROR)
3. ✅ Add regression tests (`pytest tests/test_rag_api.py::test_query_hyde_fallback`, integration curl) that stop the Ollama container and expect HTTP 200 responses.
   - Implemented `test_hyde_service_graceful_fallback` in `tests/test_rag_api.py:464-520`
   - Created comprehensive unit test suite in `tests/test_hyde_service.py` with mocked httpx client
   - 6 unit tests covering all failure modes (ConnectError, Timeout, HTTPError, unexpected format, generic exception, success)

**QA Findings (2025-11-20):**
✅ **Code Review: PASSED** - All quickfix requirements met
- Exception handling implemented correctly in both HyDE service and QueryService
- Defense-in-depth pattern ensures no exceptions propagate to FastAPI (in theory)
- WARNING level logging appropriate for graceful degradation
- Comprehensive unit tests with mocking (6 tests)
- Integration test validates end-to-end behavior
- Documentation complete (historylog.md, expectations.md, prompt artifact)

**Runtime Validation (2025-11-21 QA):**
- `pytest tests/test_query_service.py -k fallback -v` → PASS (lexical fallback unit test).
- `pytest tests/test_rag_api.py -k hyde -v` → PASS (HyDE-disabled + fallback) with HyDE-enabled tests skipped pending env flag.
- Manual curl workflow with `HYDE_ENABLED=true`, rebuild rag-api:
  * Baseline `/query` returned HTTP 200 with citations.
  * After `docker stop specter-ollama`, the same `/query` still returned HTTP 200 (latency ~14 s) with citations.
  * `docker logs specter-rag-api --tail 80 | grep -i hyde` shows WARNINGs (“HyDE generation timed out…”, “Query embedding generation failed… HyDE skipped… lexical search only”) and no RetryError stack traces.
  * Restarted specter-ollama and reverted `.env.rag` to disable HyDE by default.
- Audit check (manual) confirmed fallback queries log `hyde_used=false`, `hyde_generation_ms=0`.

---

# Quick Fix Plan — Hybrid DNS Stack (Avahi) (2025-11-19)

**Status:** ❌ OPEN (reopened 2025-11-20)

**Observed (2025-11-21 QA Marathon):** After fixing the entrypoint argument, the `specter-mdns` container still enters a crash loop. Logs show a new error: `Invalid configuration key "disable-publishing" in group "server"`.

**Root Cause:** The version of Avahi (0.8) installed via the `alpine:3.19` base image does not support the `disable-publishing` key in `avahi-daemon.conf`. This option is obsolete and was replaced by `enable-publishing` in Avahi 0.7. The current configuration file is incompatible with the daemon version.

**Original Issue (Resolved):** `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d` now pulls CoreDNS, but `specter-mdns` crashes immediately with `avahi-daemon: option requires an argument: f` because the entrypoint lacks the config path. Without Avahi, mDNS/DNS-SD verification cannot proceed.

**Resolution (2025-11-20):**
Implemented air-gapped Avahi container deployment by creating local Dockerfile, eliminating external GHCR dependency. Changes:
1. Created `agents/mDNS/Dockerfile.avahi` with Alpine 3.19 base, avahi + dbus packages, correct entrypoint: `avahi-daemon --no-chroot -f /etc/avahi/avahi-daemon.conf`
2. Updated `agents/mDNS/docker-compose.hybrid-dns.yml` to build from local Dockerfile (tagged `specter-avahi:local`)
3. Enhanced `agents/mDNS/README.md` with air-gap deployment section, build instructions, comprehensive troubleshooting guide
4. Preserved all runtime configuration (host networking, capabilities, volume mounts)

**Verification Plan (Requires Docker Host):**
```bash
# Build verification (air-gap compliance)
docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml build avahi

# Deployment verification
docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d
docker ps | grep specter-mdns  # Expect: running, not restarting
docker logs specter-mdns --tail 50  # Expect: "Server startup complete"

# DNS resolution verification
dig @127.0.0.1 specter.local +short  # CoreDNS unicast
dns-sd -G v4v6 specter.local  # Avahi mDNS (macOS)
dns-sd -B _https._tcp  # DNS-SD service discovery
```

**Prompt Artifact:** `agents/prompts/tasks/007-vendor-avahi-image.md`
**Historylog Entry:** See 2025-11-20 Hybrid DNS Avahi Vendoring section

**QA Validation (2025-11-20):**
✅ **Code Review Complete** - All quickfix requirements satisfied:
- Dockerfile.avahi created with correct entrypoint (`--no-chroot -f` flags)
- docker-compose.hybrid-dns.yml builds from local Dockerfile (GHCR dependency eliminated)
- README.md enhanced with air-gap deployment instructions and troubleshooting
- Configuration files validated (avahi-daemon.conf, specter-https.service)
- All runtime configuration preserved (host networking, capabilities, volume mounts)

⏳ **Runtime Testing Deferred** - Requires Docker host with multicast support:
- Build verification (image size, air-gap compliance)
- Container deployment (no crash loop, daemon health check)
- DNS resolution (CoreDNS unicast + Avahi multicast consistency)
- DNS-SD service discovery (service announcement visible)
- Client integration testing (macOS/iOS browser navigation to https://specter.local)

❌ **Runtime Verification Attempt (2025-11-19 QA Marathon #2):**  
`docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d --build` still produces a crash loop (`specter-mdns Restarting (255)`, logs show `avahi-daemon: option requires an argument: f`). CoreDNS answers unicast queries, but Avahi never reaches “Server startup complete.” Entry point still lacks `/etc/avahi/avahi-daemon.conf`. Needs follow-up before closing this quickfix.

**2025-11-21 Builder Update (`claude/hybrid-dns-fix-01MdnsRuntimeFix`):**
- Updated `agents/mDNS/Dockerfile.avahi` ENTRYPOINT to run `avahi-daemon --no-chroot -f /etc/avahi/avahi-daemon.conf`.
- Documented revised manual verification commands (`docker logs specter-mdns` expectation) in `agents/mDNS/README.md`.
- Runtime verification still pending; follow the commands listed above to confirm `specter-mdns` remains healthy.

**2025-11-21 Validation:** Removed all legacy `publish-*` options, rebuilt the stack, and confirmed `specter-mdns` now logs “Server startup complete.” `dig @127.0.0.1 specter.local +short` resolves correctly. `dns-sd`/`avahi-resolve` utilities are not installed in this WSL environment, but the automated script `agents/mDNS/test-hybrid-dns.sh` passes (CoreDNS OK, Avahi stable). Quickfix marked ✅ RESOLVED; remaining optional checks require installing client tools or testing from a LAN device.

**QA Branch:** `claude/qa-hybrid-dns-prompt-015HucXPiuB1ZD4xrgSrMwmM`
**QA Expectations:** See `agents/expectations.md` - Hybrid DNS Stack (Avahi) Quickfix section
**Testing Time Estimate:** 30-45 minutes on Docker-enabled host with LAN client device

---

# Quick Fix Plan — Production Hardening Sweep (2025-11-19)

**Status:** ✅ RESOLVED (Runtime verified 2025-11-21)

**Observed:** LibreChat still has `ALLOW_REGISTRATION=true`, nginx override/env scaffolding is missing, Docker disk usage remains high (>35 GB images), and log-audit instructions are absent. This was intentionally deferred pending backend fixes but must be completed before shipping.

**Required Actions:**
1. Set `ALLOW_REGISTRATION=false` (document admin creation) and ensure nginx/LibreChat overrides exist so HTTPS and dictation work on LAN clients.
2. Run/document Docker cleanup (`docker system df`, prune, log results) and capture the actual Docker root (`docker info --format '{{.DockerRootDir}}'`), noting log sizes per container.
3. Update docs to describe how operators audit logs/disk before release.

**Verification:**
- `grep ALLOW_REGISTRATION librechat/.env.librechat` → `false`
- `docker system df` (confirm reduced usage or doc mitigation)
- `docker info --format '{{.DockerRootDir}}'` + `du -sh $ROOT/containers/*/`
- LibreChat/nginx health checks per `agents/verify_post_merge.md`

**2025-11-21 QA status:** LibreChat/nginx recreated with env showing `ALLOW_REGISTRATION=false`; POST `/api/auth/register` returns 403 (“Registration is not allowed.”) and admin login succeeds for `tim@offline.local` after resetting the password to `AdminTest123!`. Docker log audit initially blocked in WSL because `/var/lib/docker` was empty/not mounted.

**2025-11-22 Host log audit:** From Docker Desktop host: `docker run --rm -v /var/lib/docker:/docker alpine sh -c "du -sh /docker && du -sh /docker/containers/*/*-json.log"` → Docker root size 30.1G; container log sizes: 3.6M (76994c67…), 1.5M (501d167…), 20K (0f73713a…, 4ddc564b…), 16K (f97fe1f9…), 8K (636b5276…), others 4K. Quickfix closed with signup disabled, admin login verified, and log audit captured from host.
