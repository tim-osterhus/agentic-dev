# Specter Legal — Merge Resolution Guide

Use this playbook when multiple builder branches have finished and you need to merge them onto `main` locally while an agent assists with conflict resolution. The agent follows these steps exactly and asks the human operator before resolving each conflict.

---

## Inputs
- List of builder branches to merge (provided by the human when invoking the agent).
- Local repo with Git access.

## Workflow

1. **Sync remotes**
   ```
   git fetch --all --prune
   ```

2. **Prepare `main`**
   ```
   git checkout main
   git pull origin main
   ```

3. **For each branch in the provided list:**
   1. Ensure the branch is up to date locally:
      ```
      git checkout <branch>
      git pull origin <branch>
      ```
   2. Switch back to `main`:
      ```
      git checkout main
      ```
   3. Merge the branch:
      ```
      git merge <branch>
      ```
   4. If Git reports conflicts:
      - List conflicted files (`git status`).
      - For each file, open the conflict and display the relevant hunk to the human.
      - Ask: “How should this conflict in `<file>` be resolved? Keep HEAD, keep `<branch>`, or manually combine?”
      - Apply the human’s chosen resolution (edit the file accordingly).
      - Repeat until all conflicts in the file are resolved, then run `git add <file>`.
      - Continue until no conflicts remain (`git status` clean).
   5. When the merge succeeds:
      - Run `git status` to confirm staged changes.
      - Optionally run tests if requested.
      - Commit merge (if Git didn’t auto-commit):
        ```
        git commit
        ```
      - Push `main`:
        ```
        git push origin main
        ```

4. **Repeat** for the next branch until all branches are merged.

5. **Cleanup**
   - If desired, delete merged branches:
     ```
     git branch -d <branch>
     git push origin --delete <branch>
     ```
   - Update `agents/historylog.md` referencing which branches were merged.

## Important Rules
- Never resolve a conflict without explicit human direction.
- Show the conflict hunk before asking for guidance.
- Do not stash or discard changes unless the human requests it.
- If a branch cannot be merged cleanly even after conflict resolution (tests failing, etc.), stop and ask for further instructions.

This guide ensures merges are handled methodically, with the agent doing the mechanical work while the human retains final say on every conflict.
