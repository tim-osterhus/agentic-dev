## Specter Legal Roadmap v2

### North Star & Current Phase
- Deliver a plug-and-play, air-gapped research assistant that attorneys trust for citation-backed answers.
- Phase 1 (dev-box prototype) is complete; we are executing Phase 2 streamlining/hardening before scaling hardware (Phase 3) and corpus/test automation (Phase 4+).

### Phase 2 — Productization On Current Hardware
#### UI / UX Consolidation
- Keep only the essential LibreChat surfaces: single “Ollama” provider, “Attach Files” button, “File Search” tool, and optional Custom Prompt Mode.
- Remove/disable: Agent Marketplace, My Agents bin, Plugins/Code Interpreter/Web Search/Artifacts toggles (retain Custom Prompt Mode only), Agent Builder panel, redundant prompt inputs.
 - Add: disclaimer banner (“AI draft — attorney review required”), working Privacy/ToS pages with placeholder copy, right-sidebar document viewer for retrieved/generated files, real-time context monitor + “Summarize for new conversation” action, **self-served LAN DNS so users can hit `specter.local` without manual hosts edits**.
- Build a curated prompt library (non-technical friendly) and surface it in the Prompts panel; clarify how it relates to Custom Prompt Mode.

#### Voice, Input, and Collaboration
- Upgrade dictation to Whisper-medium-en running on GPU; ensure HTTPS / LAN TLS so browsers grant microphone permissions without flags.
  - **Documentation:** See [Dictation Hardware Requirements](../README.md#dictation-hardware-requirements) for GPU/CUDA specs and [STT Dictation Guide](../docs/STT_DICTATION.md#tlshttps-setup-for-microphone-access) for TLS setup instructions.
- Decide on Memories support (optional): document risks/benefits and implementation plan.

#### Model & Guardrails
- Reinstate system prompts that enforce “cite all claims” behavior; show a clear warning when RAG corpus is unavailable.
- Ensure `/chat` continues to hit the pgvector-backed retrieval before synthesizing answers (no regression to pure LLM responses).

#### Retrieval & Data
- Maintain universal corpus plus tenant-specific collections; seed baseline documents so regression smoke tests always have references.
- Add document viewer + citation jump links so users can inspect “raw” text inside the UI.

### Phase 3 — Hardware Tier Delivery
- Finalize target hardware (24 GB 4090 build vs M4 Pro Mac mini). Document upgrade path (extra GPU slot, storage footprint, cooling, etc.).
- Benchmark candidate stacks: Arctic-Embed-l-v2.0 (primary), Qwen3-30B-A3B FP8 for drafting, bge-reranker-v2-m3, Qwen3-4B HyDE. Keep alternative embeddings/models (Arctic-m, Qwen embeddings, mxbai) in reserve.
- Continue defaulting to containerized Ollama; revisit vLLM in Phase 5.

### Phase 4 — Corpus, Prompting, Testing, Compliance
- Build the full universal legal corpus, automate embeddings/backfill, and track best-known chunking/RAG parameters.
- Develop the prompt library + HyDE-lite workflow; wire context monitor to summarization prompts.
- Testing suites: 1) speed/concurrency/context degradation, 2) retrieval precision/accuracy, 3) safety/adversarial prompts. Automate orchestration + grading (LLM-based or deterministic) and support offline runs when confidential data is involved.
- Draft safety/security/compliance plans: data protection checklist, license attributions for every dependency, legal disclaimers.
- Plan for packaging/IP protection: installer story, retainers/updates, code obfuscation or licensing strategy.

### Phase 5 — Expansion & Integrations
- Explore vLLM continuous batching on higher-tier hardware, multi-GPU scheduling, and advanced routing.
- Investigate optional integrations (legal document repositories, scheduled imports) while safeguarding the air-gap.
- Add Memories (if opted-in), context-aware reminders, and richer analytics once core workflows stabilize.

### Sustaining Initiatives
- Plug-and-play deployment: minimal steps from bare server → running stack; document prerequisites (Docker, GPU drivers, HTTPS certs).
 - Include optional DNS helper service so LAN clients auto-resolve `specter.local`.
- Real-time context monitor + summarization to prevent stalled chats when context is nearly full.
- Optional document viewer and future integrations should remain modular to avoid bloating the base deployment.

### Out of Scope / Deferred Items
- Cloud/SaaS hosting and WAN-dependent features remain explicitly out of scope.
- Any non-legal verticals or multilingual expansion will be revisited only after the legal workflow is production ready.
