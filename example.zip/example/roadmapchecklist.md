- [ ] **Agent Workflow / Ops**
  - [ ] Promote one task at a time from `tasksbacklog.md` into `tasks.md`.
  - [ ] Keep `agents/historylog.md` and `quickfix.md` in sync with each cycle.

## Phase 2 — Productization (on current hardware)

### UI / UX
- [ ] Remove My Agents bin, Agent Marketplace, Plugins/Web Search/Code Interpreter/Artifacts toggles (keep Custom Prompt Mode only).
- [ ] Ensure only “Attach Files” + “File Search” appear under the composer tools.
- [ ] Add AI disclaimer banner; wire Privacy Policy / Terms links to placeholder pages.
- [ ] Implement right-sidebar document viewer for retrieved/generated docs.
- [ ] Add real-time context monitor + “Summarize for New Conversation” preset.
- [ ] Add real-time speed monitor that displays tokens/second for development purposes.
- [ ] Ship optional LAN DNS helper so `specter.local` resolves automatically without per-device host entries.

### Prompting & Library
- [ ] Design prompt library cards (non-technical friendly) and surface them in the Prompts panel.
- [ ] Decide how Custom Prompt Mode interacts with library selections (toggle vs template editor).

### Dictation & Permissions
- [x] Swap STT model to Whisper-medium-en (GPU inference); document hardware requirements. ([README.md#dictation-hardware-requirements](../README.md#dictation-hardware-requirements), [docs/STT_DICTATION.md](../docs/STT_DICTATION.md))
- [ ] Implement HTTPS/LAN TLS so browsers grant mic access without flags; provide onboarding steps for new devices. ([TLS setup documented](../docs/STT_DICTATION.md#tlshttps-setup-for-microphone-access))

### Memories (Optional)
- [ ] Evaluate benefits/risks; draft opt-in approach or disable by default.

### Guardrails & System Behavior
- [ ] Reinstate system prompts enforcing citation requirements; warn visibly when RAG corpus is unavailable.
- [ ] Ensure `/chat` always runs retrieval before synthesis; log when the LLM fallback is used (no RAG context).

### Retrieval / Data
- [ ] Seed baseline documents (global + tenant) so smoke tests always have citations.
- [ ] Embed new uploads via containerized Ollama by default; maintain host fallback instructions.

### LibreChat / Provider Cleanup
- [ ] Confirm only “Ollama” provider remains and points to `http://ollama:11434/v1`.
- [ ] Restart LibreChat / clear caches and prove traffic hits the container (stop host daemon to verify).

## Phase 3 — Hardware Tier Delivery

- [ ] Finalize hardware decision (4090 build vs Mac mini M4 Pro) and document BOM.
- [ ] Benchmark model stack: Arctic-Embed-l, Qwen3-30B FP8, bge-reranker-v2-m3, Qwen3-4B HyDE.
- [ ] Record alternative embeddings/models to evaluate (Arctic-m, Qwen embeddings, mxbai, Qwen3-14B).
- [ ] Keep Ollama as default runtime; capture prerequisites for future vLLM experiments.

## Phase 4 — Corpus, Prompting, Testing, Compliance

### Corpus & Prompting
- [ ] Assemble universal legal corpus; automate embeddings/backfill with chosen chunking/RAG params.
- [ ] Finalize prompt library + HyDE-lite scripts; tie them into context monitor workflow.

### Automated Testing
- [ ] Build speed/concurrency suite (single button, monitors context usage and throughput).
- [ ] Build retrieval accuracy suite (legal tasks, context stress tests).
- [ ] Build safety/adversarial suite; document LLM grader vs deterministic scoring approach.
- [ ] Support offline grading for confidential datasets.

### Compliance & Packaging
- [ ] Draft safety/security checklist (data handling, auditing, access controls).
- [ ] Collect licenses for all dependencies; add attributions and legal disclaimers to the repo.
- [ ] Plan packaging/IP strategy (installer flow, update mechanics, obfuscation/licensing questions).

## Phase 5 — Expansion

- [ ] Prototype vLLM deployment + Redis queue integration once higher-tier hardware lands.
- [ ] Explore document-import integrations (external legal DBs) while preserving air-gap guarantees.
- [ ] Consider Memories/analytics enhancements after core workflows ship.

## Testing & Ops Enhancements (cross-phase)

- [ ] Create full-stack smoke checklist (compose up, curl /chat, LibreChat UI, doc viewer, dictation).
- [ ] Automate `./scripts/test_chat_formats.sh` and add CI hooks.
- [ ] Add real-time monitoring dashboards (context usage, queue depth, container health).
