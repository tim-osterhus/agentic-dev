# Builder Runbook

Follow this when you open Claude/Codex to implement a task from `agents/tasks.md`.

## 1. Prep
- Ensure `agents/tasks.md` contains the latest request/context.
- Optionally create a scratch directory under `agents/sessions/` for notes.

## 2. Launch the Builder Prompt
- In PowerShell from the repo root, start your model normally.
- Paste the entry instructions from `agents/_entrypoint.md` or simply say:
  "Read agents/tasks.md and follow agents/prompts/builder_cycle.md exactly."

## 3. During the Run
- Expect the assistant to announce each specialist role as it switches.
- Watch for checkpoints, diffs, and blockers. If scope creeps, remind it to return to the Planner Architect.
- Encourage small commits/patches and explicit test logs.

## 4. After the Run
- Review the assistant’s summary and proposed historylog text.
- Verify actual git diffs and tests.
- If satisfied, paste the entry into `agents/historylog.md` (or have the assistant do it) and move to QA.
- If blockers remain, decide whether to adjust `agents/tasks.md` or gather missing info before retrying.

## 5. Hand-off to QA
- Once code changes are in place, run the QA prompt (`agents/prompts/qa_cycle.md`) with the other model if possible.
