# History Log Guidance

Every meaningful change should leave a breadcrumb in `agents/historylog.md`. Use this format:

```
## [YYYY-MM-DD] BuilderCycle • Short Task Title
- Summary: One or two sentences describing the change and its intent.
- Specialist roles activated: Planner Architect → (list engineers) → Documentation Writer.
- Tests: command(s) and pass/fail result. Mention if skipped and why.
- Follow-ups: bullet list of remaining work, owners, or risks.
```

For QA confirmations, use `QACycle`; for follow-up fix passes, use `QuickFix`.

## Tips
- Keep entries chronological (newest at top). Use copy/paste to move older content down if needed.
- If no files changed, add a note explaining the investigation and outcome (e.g., “No action—already fixed upstream”).
- When multiple iterations happen the same day, append `#1`, `#2` to the task title for clarity.
- If the Reviewer applies fixes, reference the original role cycle entry so readers can follow the chain.
