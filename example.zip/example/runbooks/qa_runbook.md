# QA Runbook

Use this after the builder cycle completes and diffs are ready for validation.

## 1. Prep
- Confirm the builder finished and logged a summary in `agents/historylog.md`.
- Skim `agents/tasks.md` to refresh the request and constraints.

## 2. Launch the QA Prompt
- Open your model and instruct it: "Follow agents/prompts/qa_cycle.md for the current task."
- Ensure the assistant knows to write `agents/expectations.md` before inspecting diffs.

## 3. During the Run
- Expect two phases: Expectations creation, then validation.
- Provide any missing context (e.g., test creds) if asked.
- Stop the assistant if it tries to modify code; QA should only observe and report unless running prescribed tests.

## 4. Outcomes
- Review `agents/expectations.md` to understand the target state.
- If `agents/quickfix.md` is produced, it should also be logged in `agents/historylog.md`.
- Update humans or re-run the builder prompt with the quickfix plan as input.

## 5. Iterate
- After fixes are applied, re-run the QA prompt to confirm alignment until expectations are satisfied.
