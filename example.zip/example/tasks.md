# Active Task Card

Paste the last task from tasksbacklog.md here when you start working on it. Include the full description, constraints, and verification steps. When it's completed, archive it in historylog.md and pull the next one.

## 2025-11-22 — Fix LibreChat provider bloat & rag-api chat error
- **Goal:** Remove unwanted providers from the LibreChat UI and fix the rag-api chat endpoint so selecting the RAG option works without errors and returns citations.
- **Problem (current state):**
  - LibreChat model dropdown now shows extra providers (OpenAI, Assistants, Google, Bing, Plugins, Anthropic) that should not appear.
  - Selecting the new `rag-api` endpoint in the UI returns a fast error: “Something went wrong... An error occurred while processing your request. Please contact the Admin.” (~2s). rag-api direct curls still work.
  - Recent changes: prompt 003 added rag-api/v1 proxy in `rag_api/main.py` and a `specter-rag` endpoint in `librechat/librechat.yaml`; LibreChat rebuild/recreate done. rag-api direct /v1/chat/completions and /chat return citations; LibreChat healthcheck shows “starting” (container lacks curl).
- **Details/Constraints:**
  - Clean up LibreChat config to only expose the intended Specter endpoints (specter-ollama + RAG) and remove unwanted providers.
  - Fix the UI → rag-api request path so the RAG option works end-to-end (no error, citations visible).
  - Validate with a UI query while tailing rag-api logs; ensure citations appear and rag-api receives traffic.
  - Rebuild/restart services as needed (librechat, nginx, rag-api).
- **Acceptance:**
  - LibreChat dropdown shows only intended endpoints (specter-ollama + RAG) with no extra providers.
  - UI queries using the RAG option succeed and show citations; rag-api logs reflect the UI requests.
  - Config files (`librechat/librechat.yaml`, related env) and rag-api proxy are consistent and loaded by running containers.
