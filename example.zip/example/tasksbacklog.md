# Tasks Inbox

Follow the below template when inputting new tasks.

## YYYY-MM-DD — Example
- Describe the goal here.
- Include relevant snippets, URLs (if offline accessible), or notes.
- Mention constraints, expected deliverables, and tests to run.

Paste new requests, context dumps, or checklists below this line. Keep the next task to add to queue at the top and separate runs with a level-2 heading.

## 2025-11-21 — Run HyDE-enabled regressions + mDNS CLI verification
- **Goal:** Clear remaining skips and capture CLI evidence for mDNS to fully close Phase 2/6 verification.
- **Details:** Run pytest with `HYDE_TESTS_ENABLED=1` to clear HyDE skips; install `dns-sd`/`avahi-utils` (or equivalent) and rerun Phase 6 commands to log `dns-sd -G/-B` outputs. Append results to `agents/historylog.md`.
- **Acceptance:** HyDE tests green (no skips) with logs captured; mDNS CLI verification recorded alongside existing dig/Avahi logs.

## 2025-11-21 — Repository freeze & prompt housekeeping for Phase 3
- **Goal:** Make the repo “hand-off ready” before hardware swap.
- **Details:** Ensure `agents/tasks.md` only contains the active task; archive or move any completed prompt artifacts; confirm `agents/quickfix.md` is empty; note status in `agents/historylog.md`.
- **Acceptance:** Agents folder clean (no stale prompts/quickfixes), single active task card, freeze noted in history log.

## 2025-11-21 — Phase 3 GPU hardware flight plan
- **Goal:** Write a concise checklist for bringing up Phase 3 hardware with larger models.
- **Details:** Cover driver + `nvidia-container-toolkit` install, Docker/Compose versions, `nvidia-smi` smoke, `OLLAMA_MAX_LOADED_MODELS`/`OLLAMA_KEEP_ALIVE` tuning, reranker device toggle, rebuild steps, and re-running `agents/verify_post_merge.md` after model swaps.
- **Acceptance:** Checklist committed to docs/agents (one file) with actionable commands and environment toggles.

## 2025-11-21 — Full corpus ingest/embedding handoff plan
- **Goal:** Document how to seed and embed the full corpus on new hardware.
- **Details:** Outline DB seed/backfill steps, batch sizing for `backfill_embeddings.py`, verification queries for `global_law`/tenant counts, and pytest/`/query` checks post-embed; include optional `docker save/load` for preloading models.
- **Acceptance:** Written runbook added to docs/agents; ready for Phase 3 execution without code changes.

## 2025-11-21 — Final full regression sweep with HyDE enabled
- **Goal:** Capture one clean test run with HyDE on to serve as the Phase 2 baseline before Phase 3 hardware move.
- **Details:** Start stack, set `HYDE_TESTS_ENABLED=1`, run `pytest tests/test_rag_api.py tests/test_chat_endpoint.py -v > test_results.txt`, and summarize results in `agents/historylog.md`.
- **Acceptance:** `test_results.txt` reflects full pass (or documented failures), and history log records the HyDE-enabled run.

## 2025-11-18 — Expand `/query` test coverage for new retrieval features
- **Goal:** Extend `tests/test_rag_api.py` (and related fixtures) to cover guardrail logging, HyDE-lite, and hybrid search toggles.
- **Details:**
  - Add fixtures representing seeded documents and simulated HyDE outputs.
  - Ensure tests assert the logging fields (`rag_used`) and behavior when toggles are on/off.
  - Update CI instructions to run the expanded suite.
- **Acceptance:** `pytest tests/test_rag_api.py -k query` passes locally, covering both classic and enhanced retrieval paths, and the history log notes the new test coverage.



-------------------------------------------------------------------------------

Tasks that are in progress are MANUALLY put below this line.




-------------------------------------------------------------------------------

Tasks waiting to be implemented should be inserted below this line.



## 2025-11-05 — Define Custom Prompt Mode interaction
- **Goal:** Document and code how selecting a prompt populates Custom Prompt Mode (pre-fill vs locked) so UX is predictable.
- **Acceptance:** Add notes to README or docs plus working behavior in UI.

## 2025-11-05 — Add right-sidebar document viewer
- **Goal:** Create a sidebar component that displays the raw text for the currently selected citation/document.
- **Acceptance:** User can toggle the pane, see citation text, and it updates with chat interactions.

## 2025-11-05 — Add token speed monitor
- **Goal:** Show an indicator of average token generation speed per outputted message.
- **Acceptance:** An accurate figure of the average token generation speed should appear at the bottom of each message from the model.



-------------------------------------------------------------------------------

Finished tasks go below this line.



## 2025-11-19 — Production hardening sweep (see `agents/quickfix.md` “Production Hardening Items”)
- **Goal:** Apply the operational fixes (disable registration, prune Docker usage, document log inspection).
- **Details:** Set `ALLOW_REGISTRATION=false`, run/document `docker system df` + cleanup, locate Docker logs and add audit instructions as outlined in the quickfix.
- **Acceptance:** LibreChat config shows registration disabled, disk usage targets are documented/met, and log-audit guidance exists in docs/historylog.

## 2025-11-19 — Re-seed baseline documents & fix smoke tests (see `agents/quickfix.md` “Smoke Test Baseline Gaps”)
- **Goal:** Restore the expected global and tenant seed docs so `/query` and `tests/test_rag_api.py::test_seeded_documents_queryable` pass deterministically.
- **Details:** Reapply the seed SQL from `infra/initdb/002_rag_schema.sql`, ensure tenant_firm_example contains `firm_memo_estate_001`, confirm vector column size (3072 bytes), rerun `scripts/seed_embeddings.py` / `backfill_embeddings.py`, and follow the verification steps in the quickfix entry.
- **Acceptance:** `docker exec … SELECT doc_id…` returns all required seeds, `/query` for trust creation works, and the targeted pytest cases pass.

## 2025-11-19 — Implement HyDE telemetry + graceful fallback (see `agents/quickfix.md` “HyDE Telemetry & Fallback”)
- **Goal:** Add HyDE audit columns, structured logging, and a graceful fallback when HyDE/Ollama is unavailable.
- **Details:** Apply the migration to extend `query_audit`, log `hyde_used` / timing metrics, enforce fallback when HyDE generation fails, and enable the HyDE pytest coverage noted in the quickfix.
- **Acceptance:** `/query` logs HyDE metrics, stopping Ollama no longer yields HTTP 500, and the HyDE tests run without skips.

## 2025-11-19 — Enable pg_trgm + hybrid lexical+dense retrieval (see `agents/quickfix.md` “Hybrid Retrieval pg_trgm”)
- **Goal:** Install the `pg_trgm` extension, create trigram indexes, and ensure hybrid retrieval runs without warnings.
- **Details:** Extend Postgres init/migrations to add pg_trgm, update `rag_api/services/query.py` to fuse lexical and dense search per the quickfix plan, and document how to toggle the feature.
- **Acceptance:** `\dx` shows pg_trgm, `/query` logs are clean, and the hybrid-specific tests pass.

## 2025-11-19 — Vendor Avahi image / unblock hybrid DNS deployment (see `agents/quickfix.md` “Hybrid DNS”)
- **Goal:** Make the Avahi container available offline so `agents/mDNS/docker-compose.hybrid-dns.yml` can run.
- **Details:** Mirror or vendor the Avahi image (or build locally) so the compose stack no longer pulls from GHCR, update docs with verification commands (`dig`, `dns-sd`), and ensure the stack starts successfully.
- **Acceptance:** Running the hybrid DNS compose file succeeds without GHCR access and all verification commands pass.

## 2025-11-19 — Fix `/ingest` unauthorized handling (see `agents/quickfix.md` “Ingest Without API Key Regression”)
- **Goal:** Ensure `/ingest` returns 403 when `ADMIN_API_KEY` is missing/invalid and add regression coverage.
- **Details:** Implement the auth check at the start of the endpoint, handle errors cleanly, and update pytest coverage per the quickfix instructions.
- **Acceptance:** Curl without the header returns 403 JSON error and `tests/test_rag_api.py::test_ingest_without_api_key` passes.

  ## 2025-11-18 — Implement hybrid CoreDNS + mDNS discovery stack
- **Goal:** Ship the hybrid DNS deployment (CoreDNS for unicast, Avahi for multicast DNS-SD) so `specter.local` resolves automatically across the LAN and `_https._tcp` announcements broadcast the LibreChat endpoint.
- **Details:**
  - Integrate the configs from `agents/mDNS/plan.md`: CoreDNS hosts block, Avahi daemon config, `_https` service file, and `docker-compose.hybrid-dns.yml` (Avahi on host networking).
  - Ensure the compose stack starts both `specter-dns` (CoreDNS) and `specter-mdns` (Avahi), exposing UDP/TCP 53 and advertising `_https._tcp` pointing to nginx.
  - Document verification steps (dig, dns-sd, avahi-resolve) plus router/DHCP guidance so admins can mix unicast/multicast as needed.
  - Update onboarding docs (`docs/STT_DICTATION.md`, `docs/HTTPS_LAN_SETUP.md`, README) referencing the hybrid stack and linking to `agents/mDNS/plan.md`.
- **Acceptance:** After running `docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d`, `dig specter.local`, `dns-sd -G specter.local`, and `dns-sd -B _https._tcp` all resolve/announce the expected info; docs clearly explain setup and teardown.

  ## 2025-11-18 — Add dedicated LAN DNS service for `specter.local`
- **Goal:** Bundle a lightweight DNS server (e.g., CoreDNS or dnsmasq) so every LAN device resolves `specter.local` automatically without editing hosts files, while keeping the deployment LAN-only.
- **Details:**
  - Create a new compose service (or stack) that runs the DNS server with a configurable static IP obtained via macvlan/host networking, mapping `specter.local` (and optional aliases) to the LibreChat/nginx endpoint.
  - Provide sane defaults (documented to avoid typical DHCP pools) plus `.env` overrides so admins can pick an IP without router reconfiguration; include health checks/log hints.
  - Update documentation (`docs/STT_DICTATION.md`, `docs/HTTPS_LAN_SETUP.md`, `README.md`) describing how to enable the DNS service, point DHCP clients (or the router) at it, and verify resolution—all while staying LAN-only.
  - Ensure the DNS service coexists with existing compose stacks and include teardown instructions (disable service if another DNS already serves the network).
- **Acceptance:** After enabling the DNS service and pointing a test client’s DNS at its static IP, `https://specter.local` resolves/loads without editing hosts; documentation clearly explains setup, IP selection, and conflict avoidance.

  ## 2025-11-18 — In-app HTTPS certificate onboarding for dictation
- **Goal:** When a user tries to enable dictation from a non-localhost device, show an in-app modal guiding them through downloading and trusting the local TLS certificate so they can grant microphone access without leaving LibreChat.
- **Details:**
  - Detect insecure contexts or failed mic permission attempts (e.g., via `navigator.mediaDevices.getUserMedia` errors or fetch checks to `/cert-check`) and trigger the modal.
  - Provide a “Download Certificate” button pointing to the bundled self-signed cert (e.g., `/certs/specter.crt`) plus OS/browser tabs with concise instructions (repurpose content from `docs/HTTPS_LAN_SETUP.md`).
  - Offer a “Verify & Continue” button that re-runs the mic permission check and dismisses the modal once the browser trusts the cert.
  - Log completion in `agents/historylog.md` and mention how admins can update the instruction text if cert paths change.
- **Acceptance:** On a fresh device without the cert, clicking the mic icon opens the onboarding modal; after following the steps, the modal confirms success and dictation works. Users on already-trusted devices skip the modal entirely.

  ## 2025-11-05 — Reinstate citation-enforcing system prompt
- **Goal:** Restore the guardrail prompt that forces citations and warns when RAG is unavailable, ensuring `/chat` never returns uncited prose.
- **Details:**
  - Revisit the previous system prompt (see `agents/historylog.md` entries around citation guardrails) and wire it into both `/chat` routes.
  - Ensure fallback messaging explicitly says “insufficient evidence” when retrieval returns no hits.
  - Update docs (`docs/INTEGRATION_LIBRECHAT.md`, `README.md`) so operators know how to customize the prompt while keeping the guardrails.
- **Acceptance:** `/chat` responses always include citation metadata; if RAG inputs are empty, the user sees a warning banner plus “needs research” language.

  ## 2025-11-05 — Log RAG vs non-RAG `/chat` responses
- **Goal:** Emit structured logs tagging each `/chat` response as RAG-backed vs fallback so we can audit retrieval coverage.
- **Details:**
  - Add structured logging (JSON or key-value) inside `/chat` showing request id, tenant, number of retrieved docs, and whether the final response used RAG context.
  - Include latency metrics for retrieval vs generation to help future benchmarking.
  - Document how to tail these logs in `agents/historylog.md` / `docs/LOGGING_AUDIT.md`.
- **Acceptance:** `docker logs specter-rag-api` (or uvicorn log files) clearly show `rag_used=true/false` entries for each `/chat`.

  ## 2025-11-05 — Seed baseline documents for smoke tests
- **Goal:** Insert a few known documents (global + tenant) so smoke tests always have deterministic citations.
- **Details:**
  - Write a seed script (or SQL fixture) that inserts at least two `global_law` docs and one tenant doc with known IDs/titles.
  - Update `tests/test_rag_api.py` and `scripts/SMOKE_TEST_CHECKLIST.md` to reference those IDs.
  - Document reset instructions so the seed can be reapplied after `docker compose down -v`.
- **Acceptance:** Running `/query` against a fresh stack returns the seeded documents with predictable citations noted in README/checklist.

  ## 2025-11-18 — Add HyDE-lite retrieval augmentation
- **Goal:** Implement HyDE-lite (Hallucinated Hypothetical Document Embeddings) by generating a draft answer via a small local model and combining its embedding with the user query to improve recall.
- **Details:**
  - Choose a lightweight Ollama model (e.g., Qwen2.5-0.5B) and expose config flags (`HYDE_ENABLED`, `HYDE_MODEL`).
  - Add logic in `rag_api/services/query.py` to call the HyDE generator, embed the hallucinated text, and merge vectors (average or weighted sum).
  - Extend `/query` tests with a mock/stub to prove the HyDE path runs.
- **Acceptance:** With HyDE enabled, `/query` logs show the synthetic query step, tests pass, and HyDE can be toggled off for baseline comparisons.

  ## 2025-11-18 — Add hybrid lexical+dense retrieval option
- **Goal:** Complement pgvector search with optional `pg_trgm` lexical scoring and reciprocal-rank fusion to boost recall on short snippets.
- **Details:**
  - Enable the `pg_trgm` extension in init scripts if not already present.
  - Add configuration to turn hybrid search on/off and choose weighting.
  - Update `rag_api/services/query.py` to run lexical scoring in parallel with vector search, then fuse results (RRf or weighted sum).
  - Document CPU impact and testing steps.
- **Acceptance:** When hybrid mode is enabled, `/query` responses include matches that would be missed by dense-only search; feature can be toggled in config.

  ## 2025-11-18 — Add GPU-aware reranker infrastructure with graceful fallback
- **Goal:** Prepare the RAG API to run a GPU-accelerated cross-encoder reranker when available, falling back to the current MiniLM model on CPU-only setups.
- **Details:**
  - Introduce config/env vars for `RERANK_DEVICE` (cpu/gpu/auto) and `RERANK_MODEL`.
  - Detect CUDA availability at startup; load a heavy reranker (placeholder path for `bge-reranker-v2-m3`) when GPU is present, otherwise load the existing MiniLM weights.
  - Abstract the reranker call so future model swaps only require config changes.
  - Document how to enable the GPU path today (even with a lighter model) and how to revert to CPU mode.
- **Acceptance:** RAG API starts successfully in both CPU and GPU modes (simulated if hardware absent), `/query` uses the appropriate reranker, and README/docs explain the toggle.
