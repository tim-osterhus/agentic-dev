# Post-Merge Verification Guide

**Purpose:** End-to-end verification of merged feature branches (seed data, HyDE, hybrid retrieval, DNS, ingest auth, regression)
**Audience:** Local CLI agent with Docker/test access
**Reference Docs:** `agents/qa_superdoc.md`, `agents/quickfix.md`, `agents/historylog.md`
**Last Updated:** 2025-11-20

---

## Pre-Flight

1. **Repo & Submodules**
   ```bash
   git checkout main
   git pull origin main
   git submodule update --init --recursive
   git status
   ```
2. **Docker Baseline**
   ```bash
   docker compose -f infra/compose/docker-compose.pgvector.yml \
                  -f infra/compose/docker-compose.mongo.yml \
                  -f infra/compose/docker-compose.ollama.yml \
                  -f infra/compose/docker-compose.rag.yml \
                  -f infra/compose/docker-compose.librechat.yml \
                  -f infra/compose/docker-compose.whisper.yml \
                  -f infra/compose/docker-compose.nginx.yml \
                  -f infra/compose/docker-compose.dns.yml down
   docker system df
   ```
3. **Environment Files**
   ```bash
   ls rag_api/.env.rag
   ls librechat/.env.librechat
   grep ADMIN_API_KEY rag_api/.env.rag
   grep ALLOW_REGISTRATION librechat/.env.librechat
   ```
   > Note: Production hardening (ALLOW_REGISTRATION=false) is Phase 9; OK if true for initial phases.

---

## Phase 1 – Seed Data & Smoke Tests

1. **Check Seeds**
   ```bash
   docker exec specter-pgvector psql -U specter -d specter -c \
     "SELECT doc_id FROM global_law ORDER BY doc_id;"
   docker exec specter-pgvector psql -U specter -d specter -c \
     "SELECT doc_id FROM tenant_firm_example;"
   ```
   > Expect `global_law` to list all three seed docs (`mn_statute_501c_0201`, `mn_statute_524_2-502`, `mn_statute_524_3-203`) and `tenant_firm_example` to include `firm_memo_estate_001` without manual intervention.
2. **Fix (if missing)**
   ```bash
   docker exec specter-pgvector psql -U specter -d specter -f /docker-entrypoint-initdb.d/002_rag_schema.sql
   docker exec specter-rag-api python backfill_embeddings.py --collection global_law
   docker exec specter-rag-api python backfill_embeddings.py --collection tenant_firm_example
   ```
   > Only run these remediation commands if Step 1 is missing rows. If seeding still requires manual inserts after the builder fix, record a FAIL + quickfix reference before proceeding.
3. **Targeted Tests**
   ```bash
   pytest tests/test_rag_api.py::test_seeded_documents_queryable -v
   curl -s -X POST http://localhost:8001/query -H "Content-Type: application/json" \
        -d '{"query":"trust creation","top_k":3}'
   ```
4. **Log Results**
   ```bash
   echo "[$(date +%Y-%m-%d)] Phase 1 - Seeds: PASS | global/tenant rows verified | pytest result ..." >> agents/historylog.md
   ```

---

## Phase 2 – HyDE Telemetry & Fallback

1. **Schema & Logs**
   ```bash
   docker exec specter-pgvector psql -U specter -d specter -c "\d query_audit" | grep hyde
   grep -n "hyde" rag_api/main.py
   ```
2. **HyDE Enabled**
   ```bash
   docker compose -f infra/compose/docker-compose.pgvector.yml \
                  -f infra/compose/docker-compose.mongo.yml \
                  -f infra/compose/docker-compose.ollama.yml \
                  -f infra/compose/docker-compose.rag.yml up -d --build rag-api
   curl -s -X POST http://localhost:8001/query -H "Content-Type: application/json" \
        -d '{"query":"estate plan workflow","hyde_enabled":true}'
   docker logs specter-rag-api | tail -50 | grep hyde
   ```
3. **Graceful Fallback**
   ```bash
   docker stop specter-ollama
   curl -s -X POST http://localhost:8001/query -H "Content-Type: application/json" \
        -d '{"query":"estate plan workflow","hyde_enabled":true}'
   docker start specter-ollama
   ```
   *Expect HTTP 200 + warning log; no RetryError.*
4. **HyDE Tests**
   ```bash
   pytest tests/test_rag_api.py::test_query_hyde_enabled -v
   pytest tests/test_rag_api.py::test_query_hyde_fallback -v
   ```
5. **Log Outcomes**
   ```bash
   echo "[$(date +%Y-%m-%d)] Phase 2 - HyDE: PASS/FAIL ... details" >> agents/historylog.md
   if fail: open quickfix entry + stop
   ```

---

## Phase 3 – Hybrid Retrieval (pg_trgm)

1. **Extension & Indexes**
   ```bash
   docker exec specter-pgvector psql -U specter -d specter -c "\dx pg_trgm"
   docker exec specter-pgvector psql -U specter -d specter -c "\di global_law*" | grep trgm
   ```
2. **Hybrid Query**
   ```bash
   curl -s -X POST http://localhost:8001/query -H "Content-Type: application/json" \
        -d '{"query":"Minnesota succession statute 524.2-502","hybrid_enabled":true,"top_k":3}'
   docker logs specter-rag-api | tail -50 | grep "Hybrid"
   ```
3. **Tests**
   ```bash
   pytest tests/test_rag_api.py -k hybrid -v
   ```
4. **Log**
   ```bash
   echo "[$(date +%Y-%m-%d)] Phase 3 - Hybrid Retrieval: PASS/FAIL ..." >> agents/historylog.md
   ```

---

## Phase 4 – `/ingest` Auth Guard

1. **Curl without API Key**
   ```bash
   curl -s -X POST http://localhost:8001/ingest \
        -H "Content-Type: application/json" \
        -d '{"doc_id":"test","title":"Should fail"}'
   ```
   *Expect 403 JSON.*
2. **Tests**
   ```bash
   pytest tests/test_rag_api.py::test_ingest_without_api_key -v
   ```
3. **Log**
   ```bash
   echo "[$(date +%Y-%m-%d)] Phase 4 - Ingest Auth: PASS/FAIL ..." >> agents/historylog.md
   ```

---

## Phase 5 – Whisper & HTTPS/LAN Checks

1. **Whisper Service**
   ```bash
   docker compose -f infra/compose/docker-compose.whisper.yml up -d whisper
   docker exec specter-whisper nslookup openaipublic.azureedge.net
   curl -s -F audio_file=@tests/fixtures/sine.wav http://localhost:9000/asr
   ```
2. **nginx TLS**
   ```bash
   docker compose -f infra/compose/docker-compose.nginx.yml up -d nginx
   curl -k -I https://specter.local/certs/specter.crt
   ```
3. **Log** results + cert instructions.

---

## Phase 6 – Hybrid DNS (CoreDNS + Avahi)

1. **DNS Stack**
   ```bash
   docker compose -f agents/mDNS/docker-compose.hybrid-dns.yml up -d
   docker ps --format 'table {{.Names}}\t{{.Status}}' | grep specter-mdns
   docker logs specter-dns | tail -20
   docker logs specter-mdns | tail -20
   ```
   > Healthy Avahi logs should include `avahi-daemon ... starting up` followed by `Server startup complete`. Continuous `option requires an argument: f` errors mean the entrypoint/config path is still broken.
2. **Validation**
   ```bash
   dig @127.0.0.1 specter.local +short
   dns-sd -G v4v6 specter.local
   dns-sd -B _https._tcp
   ```
   *If the Avahi container keeps restarting or returns no logs, stop the phase, capture logs, and update quickfix.*

---

## Phase 7 – GPU Reranker (Optional)

1. **Config Toggle**
   ```bash
   grep RERANK rag_api/.env.rag
   ```
2. **Smoke Test**
   ```bash
   curl -s -X POST http://localhost:8001/query -H "Content-Type: application/json" \
        -d '{"query":"executor duties","rerank_enabled":true}'
   docker logs specter-rag-api | tail -50 | grep rerank
   ```

---

## Phase 8 – Regression Suite

1. **Targeted Tests**
   ```bash
   python3 -m pytest tests/test_rag_api.py tests/test_chat_endpoint.py -v > test_results.txt 2>&1
   tail test_results.txt
   ```
2. **Capture Failures**
   ```bash
   if grep -i FAIL test_results.txt; then
     echo "Regression failures logged in test_results.txt" >> agents/historylog.md
     # Open quickfix entries per failure
   fi
   ```

---

## Phase 9 – Production Hardening (TODO)

- Set `ALLOW_REGISTRATION=false` in `librechat/.env.librechat`.
- Document admin creation steps.
- Run `docker system df` and prune images/cache if needed; log actual numbers.
- Identify Docker log directory: `docker info --format '{{.DockerRootDir}}'`; capture `du -sh` per container log.
- Leave notes in `agents/historylog.md` but do not change settings until instructed.

---

## Phase 10 – Wrap-Up

1. **History Log Summary**
   ```bash
   cat <<EOF >> agents/historylog.md

## [$(date +%Y-%m-%d)] Post-Merge Verification Results
- Phase 1: [PASS/FAIL] ...
- Phase 2: ...
EOF
   ```
2. **Quickfix Updates**
   - Close entries resolved in this run.
   - Append new blockers as needed.
3. **Archive Artifacts**
   ```bash
   mkdir -p agents/temp/qa_consolidation_archive_$(date +%Y%m%d)
   mv agents/temp/qa_consolidation/* agents/temp/qa_consolidation_archive_$(date +%Y%m%d)/
   ```

> If any phase fails critically, stop immediately, update `agents/historylog.md`, and re-open the relevant quickfix card. Resume from that phase after the fix lands.
