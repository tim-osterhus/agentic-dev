# Specter Legal Agentic Workflow (Prompt Artifact Edition)

This runbook coordinates every phase of the Specter Legal workflow now that prompt artifacts, builder/QA web agents, and CLI runner roles share the same repo.

---

## 1. Intake & Task Card Prep
1. Review `agents/tasksbacklog.md` (or `tasksbacklogtemp.md` for decomposition work).
2. Paste the next task into `agents/tasks.md`, replacing any example text so only one active task remains.
3. Commit and push the updated task card to the current builder branch (`claude/...` or `feature/<slug>`). Every downstream agent pulls this branch.

## 2. Decide on Prompt Artifacts
1. Determine if the task needs structured planning (multi-file changes, new feature, cross-role coordination). If not, skip to Step 3.
2. When needed, run the **Prompt Engineer** persona using `agents/prompts/create_prompt.md`.
   - Gather context from `agents/tasks.md`, roadmap docs, `historylog.md`, `quickfix.md`, etc.
   - Author a numbered prompt file (e.g., `001-context-badge.md`) in `agents/prompts/tasks/`.
   - Record the filename and purpose inside `agents/historylog.md` and the builder’s working notes.
3. Only one active prompt per task; archive older ones if superseded.

## 3. Builder Cycle (Claude Web — Builder Branch)
1. Open the builder Claude session, switch to the builder branch, and pull latest.
2. If a prompt artifact exists:
   - Tell Claude: “Load `<prompt-id>` using `agents/prompts/run_prompt.md`, then follow `agents/_entrypoint.md` + `agents/prompts/builder_cycle.md`.”
   - The `<plan>` portion of the prompt becomes the authoritative checklist.
3. If no prompt exists:
   - Prompt Claude with the classic instructions: read `_entrypoint.md`, follow `builder_cycle.md`, work from `agents/tasks.md`.
4. Require the builder to update `agents/historylog.md`, keep diffs scoped, and run any smoke tests listed in the prompt/plan.
5. Once the builder’s implementation (for that prompt) is complete, move the prompt file to `agents/prompts/completed/` and append a footer noting completion date, branch, and QA-ready status.

## 4. QA Cycle (Claude Web — QA Branch)
1. Start a new Claude session (QA role). It will auto-create a branch such as `claude/qa-cycle-...`.
2. Instructions:
   - Pull the builder branch.
   - If a prompt artifact was used, tell QA to read the same `<prompt-id>` as additional context, then follow `agents/prompts/qa_cycle.md`.
3. QA writes `agents/expectations.md`, validates the repo, records tests, and produces `agents/quickfix.md` if gaps exist.
4. QA pushes its changes to the QA branch and reports the branch name.

## 5. Coordination Merge (CLI Runner — Coordination Mode)
1. Locally fetch both builder and QA branches (`git fetch origin <builder> <qa>`).
2. Checkout the builder branch and rebase/pull to latest.
3. Merge QA artifacts into the builder branch (usually `git merge --no-ff origin/<qa-branch>`).
4. Resolve conflicts carefully in `historylog.md`, `quickfix.md`, `expectations.md`, and any prompt files.
5. Commit (if needed) with a message like `coordination: merge QA artifacts` and push the builder branch.
6. Confirm `agents/prompts/tasks/` only contains prompts still in progress.

## 6. Remediation Loop (if QA found gaps)
1. If QA created/updated `agents/quickfix.md` or marked the task PARTIAL, rerun the Builder cycle on the same branch.
2. Builder loads the latest prompt (or creates a new numbered prompt if scope changed) and implements the remediation.
3. Repeat QA → coordination until QA marks the task PASS and `quickfix.md` is removed (when no longer needed).

## 7. Runner Standard Run & Validation (CLI Runner)
1. After QA passes, run the standard CLI runner workflow on the builder branch:
   - `git fetch --all`
   - `git pull --rebase origin <builder-branch>`
   - Execute required tests (pytest, npm, docker smoke, etc.).
2. Capture test output for the history log.
3. Ensure any prompt files tied to the task are archived in `agents/prompts/completed/` with final notes.

## 8. Merge to Main & Cleanup
1. `git checkout main`, pull latest, and merge the builder branch (or open a PR and merge via GitHub).
2. Push `main` and delete the feature/builder branch if no longer needed.
3. Reset `agents/tasks.md` (or stage the next backlog item) and log a closing entry in `agents/historylog.md` referencing the prompt ID and QA outcome.
4. Archive the QA auto branch remotely if it’s no longer needed.

## 9. Ongoing Hygiene
- Keep exactly one active Task Card and at most one active prompt per task.
- Ensure every `historylog.md` entry references the prompt ID when applicable.
- Periodically prune `agents/prompts/completed/` only if older prompts are archived elsewhere; otherwise retain them for traceability.
- Use `agents/coordinate.md` whenever QA artifacts must be merged into the builder branch.

---

### Roles & Modes Quick Reference
- **Prompt Engineer (meta-role)** → `agents/prompts/create_prompt.md`
- **Prompt Runner / Builder** → `agents/prompts/run_prompt.md` + `agents/prompts/builder_cycle.md`
- **QA Agent** → `agents/prompts/qa_cycle.md`
- **CLI Runner (coordination mode)** → merge QA branch into builder branch.
- **CLI Runner (standard mode)** → sync, test, prep merge.

Maintain this sequence to keep web-based agents and CLI workflows aligned while benefiting from reusable prompt artifacts.
